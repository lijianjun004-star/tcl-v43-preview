let localIdSequence = 0;

// Storage keys and local IDs, never authentication tokens. Keep working in runtimes without WebCrypto.
export function uid() {
  if (typeof globalThis.crypto?.randomUUID === 'function') return globalThis.crypto.randomUUID();
  if (typeof globalThis.crypto?.getRandomValues === 'function') {
    const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 15) | 64;
    bytes[8] = (bytes[8] & 63) | 128;
    const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }
  return `local-${Date.now().toString(36)}-${(++localIdSequence).toString(36)}-${Math.random().toString(36).slice(2)}`;
}

export const seconds = ms => Math.max(0, ms) / 1000;
export const formatTime = ms => {
  const n = Math.floor(seconds(ms));
  return `${String(Math.floor(n / 60)).padStart(2, '0')}:${String(n % 60).padStart(2, '0')}`;
};

// Deterministic Mulberry32 PRNG for reproducible Fisher-Yates shuffle unit tests
export function createSeededRandom(seed = 123456789) {
  let a = typeof seed === 'string'
    ? Array.from(seed).reduce((acc, ch) => Math.imul(acc ^ ch.charCodeAt(0), 16777619), 2166136261) >>> 0
    : (Number(seed) >>> 0) || 1;
  return function seededRandom() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// V4.3 mandatory draw rule:
// - Only valid oral_qa questions with non-empty reference_answer are eligible
// - 1..4 valid questions: draw all of them (shuffled via Fisher-Yates)
// - >=5 valid questions: draw 5 unique questions via Fisher-Yates without replacement
// - Never use legacy slice(0, count) without shuffle
export function fisherYatesDraw(questions, maxCount = 5, random = Math.random) {
  const valid = (questions || []).filter(q => {
    const qText = String(q.question_text ?? q.content ?? '').trim();
    const rAns = String(q.reference_answer ?? q.reference ?? '').trim();
    const statusOk = !q.status || q.status === 'ready';
    const typeOk = !q.question_type || q.question_type === 'oral_qa';
    return Boolean(qText && rAns && statusOk && typeOk);
  }).map(q => ({
    ...q,
    question_id: q.question_id || q.id || uid(),
    question_text: String(q.question_text ?? q.content ?? '').trim(),
    reference_answer: String(q.reference_answer ?? q.reference ?? '').trim(),
    question_type: q.question_type || 'oral_qa',
    status: q.status || 'ready'
  }));

  if (valid.length < 1) {
    throw new Error('当前题目集中没有可用的「口头问答题」（至少需 1 道含参考答案的口头问答题才可开始正式练播）');
  }

  const pool = [...valid];
  for (let i = pool.length - 1; i > 0; i--) {
    const r = Number(random());
    const clamped = Number.isFinite(r) && r >= 0 && r < 1 ? r : 0;
    const j = Math.floor(clamped * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }

  const targetCount = Math.min(maxCount, pool.length);
  return pool.slice(0, targetCount).map((q, idx) => ({
    ...q,
    ordinal: idx + 1
  }));
}

export function parseTXT(text, product = '通用', stage = '综合') {
  if (new TextEncoder().encode(text).length > 1024 * 1024) throw new Error('TXT 不得超过 1 MB');
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (lines.length > 5000) throw new Error('一次最多导入 5000 条');
  return lines.map((line, i) => {
    const cut = line.indexOf('|');
    const name = cut > 0 ? line.slice(0, cut).trim() : `观众${i + 1}`;
    const content = cut > 0 ? line.slice(cut + 1).trim() : line;
    if (!content || content.length > 500 || name.length > 30) throw new Error(`第 ${i + 1} 行无内容或过长（昵称 30 字、内容 500 字以内）`);
    return { id: uid(), name, content, product, stage };
  });
}

export function selectQuestions(bank, settings, random = Math.random) {
  const list = bank.filter(q => (!settings?.product || q.product === settings.product) && (!settings?.stage || q.stage === settings.stage)).map(q => ({ ...q }));
  for (let i = list.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [list[i], list[j]] = [list[j], list[i]];
  }
  return list;
}

export const defaultSettings = {
  mode: 'focused',
  product: '',
  stage: '',
  order: 'random',
  view: 'single',
  orientation: 'portrait',
  resolution: 720,
  mirror: true
};

export const examples = [
  ['观众1', 'TCL MiniLED 电视的万象分区控光技术相比普通分区有什么核心优势？', 'TCL电视', '产品知识', '万象分区采用发光芯片、透镜、OD混光距离、光影控制算法与屏幕全链路调校，控光更精准，暗场更黑、亮部不过曝，大幅减少光晕。'],
  ['观众2', 'TCL 双系统平嵌冰箱是如何做到两边零厘米无缝嵌入橱柜的？', 'TCL冰箱', '产品知识', '采用底部前置散热与双翼变轨铰链设计，两侧无需预留传统散热缝隙，贴墙或平嵌橱柜时门体也能90度自由顺畅开合。'],
  ['观众3', 'TCL 双子舱洗烘一体机的超级筒洗净比达到多少？对顽固污渍有什么作用？', 'TCL洗衣机', '产品知识', '洗净比高达 1.2，配合大筒径与六根提升筋水流摔打路径，能深层剥离领口汗渍、油渍等顽固污渍且呵护衣物纤维。'],
  ['观众4', 'TCL 小蓝翼新风空调在不开窗的情况下怎么解决室内闷热和缺氧问题？', 'TCL空调', '产品知识', '通过微正压新风换气技术将室外空气经过四重滤网净化后引入室内，排出浊气并补充含氧新风，同时具备恒温新风功能避免忽冷忽热。'],
  ['观众5', 'TCL Q10 系列电视搭载的灵控桌面有什么日常使用便利性？', 'TCL电视', '产品知识', '无开机广告、支持极速唤醒，桌面卡片可像手机一样自由定制分类，老人和小孩都能一键直达常看频道与应用。'],
  ['观众6', 'TCL 冰箱的冷藏与冷冻双系统独立循环能带来什么保鲜好处？', 'TCL冰箱', '产品知识', '冷藏室与冷冻室各自配备独立蒸发器与风道，独立制冷互不干扰，既能有效防止食材串味，又能保持冷藏室湿润果蔬不风干。']
].map(([name, content, product, stage, reference], i) => ({
  id: `sample-v43-${i + 1}`,
  question_id: `sample-v43-${i + 1}`,
  name,
  content,
  question_text: content,
  reference,
  reference_answer: reference,
  product,
  stage,
  question_type: 'oral_qa',
  status: 'ready',
  source_locator: `内置示例题库 #${i + 1}`
}));

// Base Session preserved for compatibility; modulo wrap-around and autoNext are disabled per V4.3 spec.
export class Session {
  constructor(questions, settings = defaultSettings, now = () => performance.now(), wall = () => Date.now()) {
    this.now = now;
    this.wall = wall;
    this.questions = questions;
    this.settings = { ...defaultSettings, ...settings };
    this.state = 'idle';
    this.index = 0;
    this.activeBase = 0;
    this.lastResume = 0;
    this.record = {
      id: uid(),
      startedAt: 0,
      endedAt: null,
      totalMs: 0,
      activeMs: 0,
      answered: 0,
      settings: { ...this.settings },
      questions: [],
      segments: [],
      recordingStatus: 'pending',
      status: 'active',
      warnings: []
    };
  }
  get activeMs() {
    return this.activeBase + (this.state === 'running' ? Math.max(0, this.now() - this.lastResume) : 0);
  }
  get current() {
    return this.record.questions.at(-1) || null;
  }
  begin() {
    if (this.state !== 'idle' || !this.questions.length) throw new Error('没有可用题目或场次已开始');
    this.startedMono = this.now();
    this.record.startedAt = this.wall();
    this.lastResume = this.now();
    this.state = 'running';
    this.emit();
  }
  emit() {
    if (this.index >= this.questions.length) return null;
    const q = this.questions[this.index++];
    const activeNow = this.activeMs;
    const item = {
      ...q,
      sourceId: q.question_id || q.id,
      question_id: q.question_id || q.id || uid(),
      id: uid(),
      number: this.record.questions.length + 1,
      ordinal: q.ordinal || (this.record.questions.length + 1),
      sessionId: this.record.id,
      question_text: q.question_text || q.content || '',
      content: q.question_text || q.content || '',
      reference_answer: q.reference_answer || q.reference || '',
      reference: q.reference_answer || q.reference || '',
      appearedAt: this.wall(),
      endedAt: null,
      startActiveMs: activeNow,
      endActiveMs: null,
      barrage_start_ms: activeNow,
      barrage_end_ms: null,
      answer_start_ms: activeNow,
      answer_end_ms: null,
      durationMs: 0,
      completed: false,
      skipped_by_anchor: false,
      transcript: null,
      transcription_status: 'pending',
      score: null,
      score_status: 'pending',
      reasoning_summary: null,
      errors: [],
      severe_product_misinformation: false,
      videoRanges: []
    };
    this.record.questions.push(item);
    return item;
  }
  closeCurrent(completed) {
    const q = this.current;
    if (!q || q.endedAt !== null) return;
    const activeNow = this.activeMs;
    q.endedAt = this.wall();
    q.endActiveMs = activeNow;
    q.barrage_end_ms = activeNow;
    q.answer_end_ms = activeNow;
    q.durationMs = Math.max(0, q.endActiveMs - q.startActiveMs);
    q.completed = Boolean(completed);
    if (completed) this.record.answered++;
  }
  next(completed = true) {
    if (this.state !== 'running') return false;
    this.closeCurrent(completed);
    if (this.index >= this.questions.length) return false;
    this.emit();
    return true;
  }
  autoNext() {
    // V4.3 strictly prohibits automatic interval switching.
    return false;
  }
  pause() {
    if (this.state !== 'running') return;
    this.activeBase = this.activeMs;
    this.state = 'paused';
  }
  resume() {
    if (this.state !== 'paused') return;
    this.lastResume = this.now();
    this.state = 'running';
  }
  snapshot() {
    this.record.activeMs = this.activeMs;
    this.record.totalMs = this.startedMono === undefined ? 0 : Math.max(0, (this.endedMono ?? this.now()) - this.startedMono);
    if (this.current && this.current.endedAt === null) {
      this.current.durationMs = Math.max(0, this.activeMs - this.current.startActiveMs);
    }
    return structuredClone(this.record);
  }
  end() {
    if (!['running', 'paused'].includes(this.state)) return this.snapshot();
    this.closeCurrent(false);
    this.pause();
    this.record.endedAt = this.wall();
    this.record.status = 'completed';
    this.endedMono = this.now();
    this.snapshot();
    this.state = 'ended';
    return this.snapshot();
  }
}
