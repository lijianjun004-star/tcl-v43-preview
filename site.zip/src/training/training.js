import { Session, fisherYatesDraw, uid, defaultSettings } from './core.js';
import { AssessmentStateMachine } from './state-machine.js';

export function questionCount(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > 20) throw new Error('题目数量必须是1～20的整数');
  return n;
}

const TRUSTED_ASR_PROVIDERS = new Set([
  'sherpa-onnx-local',
  'browser',
  'gemini-fallback'
]);

export class TrainingSession extends Session {
  constructor(questions, settings = defaultSettings, now = () => performance.now(), wall = () => Date.now(), random = Math.random) {
    const selected = fisherYatesDraw(questions, 5, random);
    super(selected, settings, now, wall);
    this.pending = [...selected];
    this.target = selected.length;
    this.recordingConfirmed = false;
    this.awaitingFirstQuestion = false;
    this.outroActive = false;
    this.processedQuestionActions = new Set();
    this.fsm = new AssessmentStateMachine({ initialState: 'ready', now, wall });

    this.record.schema_version = 'v4.3.4';
    this.record.session_id = this.record.id;
    this.record.trainingMode = settings?.trainingMode || 'exam';
    this.record.targetCount = this.target;
    this.record.anchor = settings?.anchor
      ? structuredClone(settings.anchor)
      : { local_profile_id: uid(), display_name_local_only: '', operator_id: '' };
    this.record.question_set_snapshot = settings?.questionSetSnapshot
      ? structuredClone(settings.questionSetSnapshot)
      : { id: uid(), hash: 'unhashed', saved_at: new Date(wall()).toISOString(), title: '默认题集' };
    this.record.barrage_timeline = [];
    this.record.consents = {
      browser_speech_notice_acknowledged: Boolean(settings?.consents?.browser_speech_notice_acknowledged),
      gemini_audio_transcription_consent: Boolean(settings?.consents?.gemini_audio_transcription_consent),
      local_asr_model_install_consent: Boolean(settings?.consents?.local_asr_model_install_consent)
    };
    this.record.assessment = {
      status: 'ready',
      average_raw: null,
      average_display: null,
      score: null,
      passed: null,
      scored_at: null,
      scoring_policy_version: 'semantic-answer-v1',
      model_id: null,
      source: 'pending',
      reason: '等待完成全部题目并提交语义评分'
    };
    this.record.recording = {
      status: 'pending',
      contains_barrage: false,
      has_audio: true,
      timeline_version: 2,
      mime_type: null,
      local_recording_id: null,
      cloud_object_id: null,
      retention_expires_at: null
    };
    this.record.videoPolicy = 'v4.3-pass-retained-fail-deleted-pending-safe';
    this.record.stateHistory = this.fsm.history;
  }

  begin() {
    return this.confirmRecordingStarted({ idempotencyKey: `begin:${this.record.id}` });
  }

  confirmRecordingStarted({ recordingPosMs = 0, idempotencyKey = null } = {}) {
    if (this.recordingConfirmed) {
      return { accepted: false, duplicate: true, current: this.current };
    }
    if (!this.pending.length) {
      throw new Error('没有可抽取的口头问答题');
    }
    this.fsm.transition('recording', {
      source: 'media_recorder_started',
      idempotencyKey: idempotencyKey || `rec_start:${this.record.id}`,
      detail: this.settings.r7DeferFirstQuestion ? '录像已启动，等待主播手动开始第一题' : '录像已确认启动，立即展示第 1 题弹幕'
    });
    this.recordingConfirmed = true;
    this.startedMono = this.now();
    this.record.startedAt = this.wall();
    this.lastResume = this.now();
    this.state = 'running';
    this.record.assessment.status = 'recording';
    this.awaitingFirstQuestion = Boolean(this.settings.r7DeferFirstQuestion);
    if (!this.awaitingFirstQuestion) this.emit(recordingPosMs);
    return { accepted: true, current: this.current };
  }

  startFirstQuestion({ recordingPosMs = 0 } = {}) {
    if (!this.recordingConfirmed || this.state !== 'running' || !this.awaitingFirstQuestion) {
      return { accepted: false, current: this.current };
    }
    this.awaitingFirstQuestion = false;
    this.record.intro_end_ms = recordingPosMs;
    const current = this.emit(recordingPosMs);
    return { accepted: true, current };
  }

  finishOutro() {
    if (!this.outroActive || this.fsm.state !== 'recording') return { accepted: false };
    this.record.outro_end_ms = this.activeMs;
    this.fsm.transition('stopping', { source: 'r7_outro_confirmed', idempotencyKey: `stopping:${this.record.id}`, detail: '主播完成直播收尾后确认停止录像' });
    this.outroActive = false;
    return { accepted: true };
  }

  markRecordingStartFailed(reason = '摄像头或麦克风录制未能启动') {
    this.fsm.transition('record_start_failed', {
      source: 'media_preflight',
      detail: reason
    });
    this.state = 'idle';
    this.record.status = 'record_start_failed';
    this.record.assessment.status = 'record_start_failed';
    this.record.assessment.reason = reason;
    return this.snapshot();
  }

  emit(recordingPosMs = null) {
    if (!this.recordingConfirmed) {
      throw new Error('录像尚未确认成功启动，禁止提前展示第一道题目弹幕');
    }
    if (!this.pending.length) return null;
    const q = this.pending.shift();
    this.questions = [q];
    this.index = 0;
    const item = super.emit();
    const posMs = Number.isFinite(recordingPosMs) ? recordingPosMs : this.activeMs;
    item.ordinal = q.ordinal;
    item.revisit = false;
    item.barrage_start_ms = posMs;
    item.answer_start_ms = posMs;
    item.transcription_provider = 'none';
    item.asr_model_version = null;
    item.source_audio_hash = null;
    item.manual_note_untrusted = null;
    item.transcript_evidence = null;
    item.videoRanges = [];
    this.record.barrage_timeline.push({
      question_id: item.question_id,
      order: item.ordinal,
      question_text: item.question_text,
      question_set_snapshot_id: this.record.question_set_snapshot.id,
      barrage_start_ms: posMs,
      barrage_end_ms: null,
      answer_start_ms: posMs,
      answer_end_ms: null
    });
    return item;
  }

  // TASK002 P1-02 & TASK004 Section 5.6/5.7:
  // Formal oral exam ('exam' mode) strictly prohibits manual text input from overwriting or substituting ASR transcript!
  // Only trusted ASR providers ('sherpa-onnx-local', 'browser', or 'gemini-fallback') may populate formal `q.transcript`.
  closeCurrentWithContext({
    asrTranscript = undefined,
    transcript = '',
    transcriptionProvider = 'browser',
    asrModelVersion = null,
    sourceAudioHash = null,
    asrSegmentCount = 0,
    manualNote = '',
    transcriptionStatus = 'completed',
    audioSignalDetected = false,
    asrStatus = 'ok',
    explicitSkip = false,
    recordingPosMs = null
  } = {}) {
    const q = this.current;
    if (!q || q.endedAt !== null) return null;
    const posMs = Number.isFinite(recordingPosMs) ? Math.max(q.barrage_start_ms, recordingPosMs) : this.activeMs;

    // Separate trusted ASR output from any manual note
    const isTrustedProvider = TRUSTED_ASR_PROVIDERS.has(transcriptionProvider);
    const rawAsr = asrTranscript !== undefined ? String(asrTranscript || '').trim() : (isTrustedProvider ? String(transcript || '').trim() : '');
    const cleanManualNote = String(manualNote || (!isTrustedProvider ? transcript : '') || '').trim();

    if (cleanManualNote) {
      // Never allow manual note into formal transcript; store separately as untrusted practice/proofreading note
      q.manual_note_untrusted = cleanManualNote;
    }

    const hasTrustedSpeechText = rawAsr.length > 0 && isTrustedProvider;
    const hasTechnicalFault = !hasTrustedSpeechText && (
      asrStatus === 'technical_fault' ||
      asrStatus === 'permission_denied' ||
      asrStatus === 'error' ||
      asrStatus === 'unsupported' ||
      asrStatus === 'deferred_local_batch' ||
      transcriptionStatus === 'technical_fault' ||
      transcriptionStatus === 'transcription_pending' ||
      Boolean(audioSignalDetected) ||
      Boolean(cleanManualNote) // If anchor typed text when ASR produced nothing, keep as pending transcription, never fake ASR or judge 0!
    );

    super.closeCurrent(hasTrustedSpeechText);
    q.barrage_end_ms = posMs;
    q.answer_end_ms = posMs;

    const tlEntry = this.record.barrage_timeline.find(t => t.question_id === q.question_id && t.barrage_end_ms === null);
    if (tlEntry) {
      tlEntry.barrage_end_ms = posMs;
      tlEntry.answer_end_ms = posMs;
    }

    const normalizedProvider = transcriptionProvider === 'browser-flushed-on-switch' ? 'browser' : transcriptionProvider;
    q.transcript_evidence = {
      provider: hasTrustedSpeechText ? normalizedProvider : 'none',
      asr_model_version: asrModelVersion || null,
      source_audio_hash: sourceAudioHash || null,
      interval: [q.answer_start_ms, q.answer_end_ms],
      segment_count: asrSegmentCount,
      audio_slice_id: `audio-slice:${this.record.id}:${q.question_id}`,
      manual_override_blocked: Boolean(cleanManualNote)
    };

    if (hasTrustedSpeechText && !explicitSkip && transcriptionStatus !== 'technical_fault') {
      q.transcript = rawAsr;
      q.transcription_provider = normalizedProvider;
      q.asr_model_version = asrModelVersion || null;
      q.source_audio_hash = sourceAudioHash || null;
      q.transcription_status = 'completed';
      q.skipped_by_anchor = false;
      q.score = null;
      q.score_status = 'pending';
      q.completed = true;
    } else if ((hasTechnicalFault || hasTrustedSpeechText || !explicitSkip) && !explicitSkip) {
      // Crucial V4.3, TASK002 P1-02 & TASK004 Section 5.6 rule:
      // 1. Mic/ASR fault, deferred local ASR batch, or missing ASR must NOT be judged 0!
      // 2. Manual note must NOT overwrite/substitute ASR to obtain a formal score!
      q.transcript = hasTrustedSpeechText ? rawAsr : null;
      q.transcription_provider = hasTrustedSpeechText ? normalizedProvider : 'none';
      q.transcription_status = 'technical_fault';
      q.skipped_by_anchor = false;
      q.score = null;
      q.score_status = 'pending_transcription';
      q.reasoning_summary = cleanManualNote
        ? '正式口头考核严禁用手工输入文本代替语音识别结果；本题已保留语音分片并标记为「待语音转写」，手工备注仅留作复盘参考。'
        : '本题浏览器语音识别未完成，已保留有效的最终文字（如有）及原始录像，标记为待转写，不自动判 0 分。';
      q.completed = false;
    } else {
      // Anchor actively skipped or clicked Next with zero speech & healthy ASR link -> 0 points and NEVER re-queued
      q.transcript = '';
      q.transcription_provider = 'none';
      q.transcription_status = 'skipped_no_speech';
      q.skipped_by_anchor = true;
      q.skipped = true;
      q.score = 0;
      q.score_status = 'scored_skip_zero';
      q.reasoning_summary = '主播主动跳过本题且未作答，按考核规则单题记 0 分并计入总平均分，不重新入队。';
      q.errors = ['本题主动未作答跳过'];
      q.completed = false;
    }
    return q;
  }

  advanceQuestion(options = {}) {
    if (this.state !== 'running') {
      return { accepted: false, reason: 'not_running', hasMore: false };
    }
    const q = this.current;
    if (!q) {
      return { accepted: false, reason: 'no_current_question', hasMore: false };
    }
    const lockKey = options.idempotencyKey || `advance:${this.record.id}:${q.question_id}`;
    if (this.processedQuestionActions.has(lockKey)) {
      return { accepted: false, duplicate: true, reason: 'duplicate_click', hasMore: this.pending.length > 0 };
    }
    this.processedQuestionActions.add(lockKey);

    this.closeCurrentWithContext(options);

    if (!this.pending.length) {
      if (this.settings.r7OutroEnabled) {
        this.outroActive = true;
        this.record.outro_start_ms = this.activeMs;
        return { accepted: true, hasMore: false, finishedAllQuestions: false, startedOutro: true, closedQuestion: q };
      }
      this.fsm.transition('stopping', {
        source: 'complete_exam_button',
        idempotencyKey: `stopping:${this.record.id}`,
        detail: '最后一题已完成，准备停止录制并执行语音转写与评分'
      });
      return { accepted: true, hasMore: false, finishedAllQuestions: true, closedQuestion: q };
    }

    const nextQ = this.emit(options.recordingPosMs);
    return { accepted: true, hasMore: true, finishedAllQuestions: false, closedQuestion: q, nextQuestion: nextQ };
  }

  next(completed = true, extra = {}) {
    const res = this.advanceQuestion({
      asrTranscript: completed ? (extra.asrTranscript ?? extra.transcript ?? this.current?.transcript ?? '已口头作答') : '',
      transcriptionProvider: extra.transcriptionProvider || 'browser',
      explicitSkip: !completed,
      ...extra
    });
    return res.hasMore;
  }

  autoNext() {
    return false;
  }

  cancelMidSession(reason = '主播在未完成全部题目时确认取消本场练播') {
    if (this.current && this.current.endedAt === null) {
      const posMs = this.activeMs;
      this.current.endedAt = this.wall();
      this.current.endActiveMs = posMs;
      this.current.barrage_end_ms = posMs;
      this.current.answer_end_ms = posMs;
    }
    this.pause();
    this.endedMono = this.now();
    this.record.endedAt = this.wall();
    this.record.status = 'cancelled';
    this.record.countsTowardPassRate = false;
    this.record.uploadEligible = false;
    this.record.assessment = {
      ...this.record.assessment,
      status: 'cancelled',
      average_raw: null,
      average_display: null,
      score: null,
      passed: null,
      reason
    };
    this.fsm.transition('cancelled', {
      source: 'user_confirmed_cancel',
      idempotencyKey: `cancel:${this.record.id}`,
      detail: reason
    });
    this.state = 'cancelled';
    return this.snapshot();
  }
}
