// Explicit state machine for TCL Streamer V4.3 assessment and recording lifecycle.
// Normal path: idle -> ready -> recording -> stopping -> transcribing -> scoring -> pass | fail
// Exception branches: record_start_failed, interrupted, transcription_pending, scoring_pending_quota, scoring_retry_required, cancelled, upload_pending

import { uid } from './core.js';

export const ASSESSMENT_STATES = Object.freeze({
  IDLE: 'idle',
  READY: 'ready',
  RECORDING: 'recording',
  STOPPING: 'stopping',
  TRANSCRIBING: 'transcribing',
  SCORING: 'scoring',
  PASS: 'pass',
  FAIL: 'fail',
  RECORD_START_FAILED: 'record_start_failed',
  INTERRUPTED: 'interrupted',
  TRANSCRIPTION_PENDING: 'transcription_pending',
  SCORING_PENDING_QUOTA: 'scoring_pending_quota',
  SCORING_RETRY_REQUIRED: 'scoring_retry_required',
  CANCELLED: 'cancelled',
  UPLOAD_PENDING: 'upload_pending'
});

export const STATE_LABELS = Object.freeze({
  idle: '空闲待命',
  ready: '设备与题库就绪',
  recording: '正式录制答题中',
  stopping: '正在收尾保存录像',
  transcribing: '正在整理语音转写',
  scoring: '正在进行 AI 语义评分',
  pass: '考核通过',
  fail: '考核未通过',
  record_start_failed: '录制启动失败（未进入正式考核）',
  interrupted: '录制异常中断（录像已保留待恢复）',
  transcription_pending: '等待语音转写（未评分）',
  scoring_pending_quota: '等待 AI 评分（免费额度或服务未联调）',
  scoring_retry_required: '评分结果校验未通过（需重试评分）',
  cancelled: '已中途取消（不记成绩）',
  upload_pending: '考核通过（本地已存，待接入云端上传）'
});

const ALLOWED_TRANSITIONS = {
  idle: ['ready', 'record_start_failed', 'cancelled'],
  ready: ['recording', 'record_start_failed', 'cancelled', 'idle'],
  record_start_failed: ['ready', 'recording', 'idle', 'cancelled'],
  recording: ['stopping', 'interrupted', 'cancelled'],
  stopping: ['transcribing', 'transcription_pending', 'scoring', 'scoring_pending_quota', 'interrupted', 'cancelled'],
  transcribing: ['scoring', 'transcription_pending', 'scoring_pending_quota', 'scoring_retry_required', 'pass', 'fail'],
  transcription_pending: ['transcribing', 'scoring', 'scoring_pending_quota', 'idle'],
  scoring: ['pass', 'fail', 'scoring_pending_quota', 'scoring_retry_required', 'upload_pending'],
  scoring_pending_quota: ['scoring', 'pass', 'fail', 'scoring_retry_required'],
  scoring_retry_required: ['scoring', 'scoring_pending_quota', 'pass', 'fail'],
  pass: ['upload_pending', 'idle'],
  upload_pending: ['pass', 'idle'],
  fail: ['idle'],
  interrupted: ['ready', 'idle', 'cancelled'],
  cancelled: ['ready', 'idle']
};

export class AssessmentStateMachine {
  constructor({ initialState = 'idle', now = () => performance.now(), wall = () => Date.now() } = {}) {
    this.state = initialState;
    this.now = now;
    this.wall = wall;
    this.history = [
      {
        from: null,
        to: initialState,
        monotonicMs: this.now(),
        wallTimeIso: new Date(this.wall()).toISOString(),
        source: 'init',
        idempotencyKey: uid(),
        detail: '初始化状态机'
      }
    ];
    this.processedKeys = new Set();
  }

  canTransition(targetState) {
    const allowed = ALLOWED_TRANSITIONS[this.state] || [];
    return allowed.includes(targetState);
  }

  transition(targetState, { source = 'system', idempotencyKey = null, detail = '' } = {}) {
    const key = idempotencyKey || `${this.state}->${targetState}:${ uid() }`;
    if (idempotencyKey && this.processedKeys.has(idempotencyKey)) {
      return { accepted: false, duplicate: true, state: this.state, historyEntry: this.history.at(-1) };
    }
    if (this.state === targetState && idempotencyKey) {
      this.processedKeys.add(idempotencyKey);
      return { accepted: true, noOp: true, state: this.state, historyEntry: this.history.at(-1) };
    }
    if (!this.canTransition(targetState)) {
      throw new Error(`非法状态转换：不能从「${this.state}」直接切换到「${targetState}」`);
    }
    const entry = {
      from: this.state,
      to: targetState,
      monotonicMs: this.now(),
      wallTimeIso: new Date(this.wall()).toISOString(),
      source,
      idempotencyKey: key,
      detail
    };
    this.state = targetState;
    this.history.push(entry);
    if (idempotencyKey) this.processedKeys.add(idempotencyKey);
    return { accepted: true, state: this.state, historyEntry: entry };
  }

  snapshot() {
    return {
      currentState: this.state,
      label: STATE_LABELS[this.state] || this.state,
      history: structuredClone(this.history)
    };
  }
}
