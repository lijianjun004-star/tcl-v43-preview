import { questionCount } from '../training/training.js';

export function appendNotice(text, level, elements) {
  const { notices, details, count, createParagraph } = elements;
  if (!notices || !details || !count) return;
  const p = createParagraph();
  p.textContent = text;
  p.dataset.level = level || 'info';
  notices.append(p);
  while (notices.children.length > 8) notices.firstChild.remove();
  details.hidden = false;
  if (level === 'error' || level === 'warning') details.open = true;
  count.textContent = String(notices.children.length);
}

export function readQuestionCount(input, error, focus = false) {
  try {
    const n = questionCount(input.value);
    input.removeAttribute('aria-invalid');
    error.textContent = '';
    error.hidden = true;
    return n;
  } catch (cause) {
    input.setAttribute('aria-invalid', 'true');
    error.textContent = cause.message;
    error.hidden = false;
    if (focus) input.focus();
    throw cause;
  }
}
