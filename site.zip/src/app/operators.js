// TASK010: 邀请制主播端的纯前端边界。
// 运营后台未接入时，没有“真实运营列表”，链接/绑定码只能待服务端验证。
import { uid } from '../training/core.js';

export const AUTH_BLOCKER_NOTICE =
  '正式主播由运营后台创建，邀请链接/绑定码须经服务端校验后才能完成绑定。当前未接入运营后台，不能在本页自行注册或选择运营。可进入本机体验模式先检查题库、摄像头与练播流程；体验记录绝不视作正式成绩。';

export const DEMO_OPERATOR_ID = 'local-experience-only';
export const DEMO_OPERATOR_NAME = '本机体验（未绑定运营）';

export function normalizeInviteCode(value) {
  const input = String(value || '').trim();
  if (!input) throw new Error('请输入运营发送的邀请链接或绑定码');
  let code = input;
  if (/^https?:\/\//i.test(input)) {
    let url;
    try { url = new URL(input); } catch { throw new Error('邀请链接格式不正确'); }
    code = url.searchParams.get('invite') || url.searchParams.get('code') || '';
  }
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(code)) {
    throw new Error('邀请码格式应为 6～64 位字母、数字、下划线或连字符；完整邀请链接需包含 invite 或 code 参数');
  }
  return code;
}

// UI-only: query-string parameters never grant any access by themselves.
// Accept both ?invite= and ?code= so copied and clicked invitation links behave consistently.
export function getInvitationPrefill(search) {
  const params = new URLSearchParams(String(search || ''));
  return params.get('invite') || params.get('code') || '';
}

export function createLocalExperienceProfile(name, existing = {}) {
  const displayName = String(name || '').trim();
  if (!displayName || displayName.length > 30) {
    throw new Error('请填写本机体验昵称（1～30 字符）');
  }
  return {
    local_profile_id: existing.identity_scope === 'local_preview' && existing.local_profile_id ? existing.local_profile_id : uid(),
    display_name_local_only: displayName,
    operator_id: DEMO_OPERATOR_ID,
    operator_name: DEMO_OPERATOR_NAME,
    identity_scope: 'local_preview',
    binding_status: 'unverified_local_demo',
    sync_eligible: false,
    updated_at: new Date().toISOString()
  };
}

export function isLocalExperienceProfile(profile) {
  return profile?.identity_scope === 'local_preview' &&
    profile?.binding_status === 'unverified_local_demo' &&
    profile?.operator_id === DEMO_OPERATOR_ID &&
    profile?.sync_eligible === false;
}
