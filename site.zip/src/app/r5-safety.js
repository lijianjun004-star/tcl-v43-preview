// R5 isolated-result and media-device guards. No persistence mutation.
export function isFailedStartRecord(record) {
  return Boolean(record) && [record.status, record.assessment?.status, record.fsm?.state]
    .includes('record_start_failed');
}

export function isResultViewVisible(page, session, selectedRecord) {
  return page === 'result' && Boolean(selectedRecord || session?.state === 'ended');
}

export function normalizeHistoryQuestions(record) {
  return Array.isArray(record?.questions) ? record.questions.filter(q => q && typeof q === 'object') : [];
}

export function describeMediaError(error, device = '摄像头或麦克风') {
  const code = error?.name || 'UnknownError';
  const hints = {
    NotAllowedError: '浏览器或系统拒绝设备权限；请在站点设置和手机系统设置中允许摄像头与麦克风。',
    PermissionDeniedError: '设备权限被拒绝；请修改浏览器或系统权限。',
    NotFoundError: '找不到摄像头或麦克风；请连接可用设备。',
    DevicesNotFoundError: '找不到可用媒体设备；请确认设备已连接。',
    NotReadableError: '设备可能被其他应用占用或硬件读取失败；请关闭其他拍摄应用重试。',
    TrackStartError: '媒体设备可能被占用；请关闭其他应用重试。',
    OverconstrainedError: '设备无法满足请求参数；请尝试默认画质或其他浏览器。',
    SecurityError: '当前环境或浏览器安全策略限制设备访问；请使用 HTTPS 或 localhost。',
    TypeError: '媒体权限接口不可用或请求参数无效；请使用支持摄像头的 HTTPS 浏览器。'
  };
  return `${device}无法启动（${code}）：${hints[code] || error?.message || '请检查设备连接和浏览器权限。'}`;
}
