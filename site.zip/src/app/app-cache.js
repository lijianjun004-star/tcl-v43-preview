// Program shell only. This module never opens IndexedDB or clears localStorage.
export const SHELL_CACHE_PREFIX = 'tcl-v43-preview-shell-';
const trainingActive = session => ['running', 'paused', 'stopping', 'transcribing', 'scoring'].includes(session?.state);

async function activateUpdate(registration, timeoutMs) {
  const worker = registration?.installing || registration?.waiting;
  if (!worker || worker.state === 'activated') return;
  await new Promise((resolve, reject) => {
    let done = false;
    const finish = error => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      worker.removeEventListener('statechange', changed);
      error ? reject(error) : resolve();
    };
    const changed = () => {
      if (worker.state === 'activated') finish();
      else if (worker.state === 'redundant') finish(new Error('新版程序资源安装失败，请联网重试；本地录像与题库未清理。'));
    };
    const timer = setTimeout(() => finish(new Error('新版程序激活超时，请稍后重试；本地录像与题库未清理。')), timeoutMs);
    worker.addEventListener('statechange', changed);
    try {
      if (registration.waiting) registration.waiting.postMessage('ACTIVATE_UPDATE');
    } catch (error) {
      finish(error);
      return;
    }
    changed();
  });
}

export function createAppCacheGuard({
  serviceWorker,
  cacheStorage,
  getSession,
  isBusy = () => false,
  isOnline = () => globalThis.navigator?.onLine !== false,
  getRegistration = () => null,
  notice,
  reload,
  updateTimeoutMs = 15000
}) {
  const hadController = !!serviceWorker?.controller;
  let refreshing = false, manualRefresh = false, announced = false;
  const controllerChanged = () => {
    if (!hadController || refreshing || manualRefresh) return;
    if (trainingActive(getSession()) || isBusy()) {
      if (!announced) notice('检测到新版本代码已就绪，请在本场练播/评分结束并保存后刷新页面。', 'info');
      announced = true;
      return;
    }
    refreshing = true;
    reload();
  };
  serviceWorker?.addEventListener('controllerchange', controllerChanged);
  return {
    async refresh() {
      if (trainingActive(getSession()) || isBusy()) {
        throw new Error('请先结束当前练播/评分并等待录像保存完成，再刷新程序缓存。');
      }
      if (manualRefresh || refreshing) return;
      if (!isOnline()) {
        throw new Error('当前离线，未清理程序缓存；请联网后重试，本地录像与题库未清理。');
      }
      if (!cacheStorage?.keys || !cacheStorage?.delete) {
        throw new Error('当前浏览器不支持程序缓存管理；请勿清除网站数据，以免丢失录像与题库。');
      }
      manualRefresh = true;
      try {
        for (const name of await cacheStorage.keys()) {
          if (name.startsWith(SHELL_CACHE_PREFIX)) await cacheStorage.delete(name);
        }
        const registration = getRegistration() || await serviceWorker?.getRegistration?.('./');
        if (registration) {
          await registration.update();
          await activateUpdate(registration, updateTimeoutMs);
        }
        if (trainingActive(getSession()) || isBusy()) {
          throw new Error('练播或评分正在进行，已取消页面刷新；请结束并保存后重试。');
        }
        notice('程序缓存已刷新，本地录像与多题目集完整保留，正在重新加载最新页面…', 'info');
        refreshing = true;
        reload();
      } finally {
        manualRefresh = false;
      }
    }
  };
}
