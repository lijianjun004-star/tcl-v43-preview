import { TrainingSession } from '../training/training.js';
import { uid, examples, defaultSettings, formatTime } from '../training/core.js';
import * as db from '../storage/storage.js';
import { MediaEngine } from '../media/media.js';
import { formatPosition, locateRecording } from '../media/recording.js';
import { renderLiveBarrageDOM, attachPlaybackBarrageOverlay } from '../media/barrage-overlay.js';
import { ActionGate } from './actions.js';
import { createFileActions } from '../media/file-save.js';
import { appendNotice } from './feedback.js';
import { createAppCacheGuard } from './app-cache.js';
import { AUTH_BLOCKER_NOTICE, normalizeInviteCode, createLocalExperienceProfile, isLocalExperienceProfile, getInvitationPrefill } from './operators.js';
import {
  parseFileToQuestionDraft,
  evaluateAndClassifyItems,
  buildConfirmedQuestionSet,
  QUESTION_STATUS_LABELS,
  QUESTION_TYPE_LABELS
} from '../files/question-set.js';
import { SpeechRecognitionController, detectBrowserSpeechSupport } from '../speech/speech.js';
import {
  fetchGatewayCapabilities,
  submitSessionForScoring,
  recoverPendingScoringJobs
} from '../assessment/scorer-client.js';
import { STATE_LABELS } from '../training/state-machine.js';
import { isFailedStartRecord, isResultViewVisible, describeMediaError, normalizeHistoryQuestions } from './r5-safety.js';

const $ = id => document.getElementById(id);

let settings = { ...defaultSettings, trainingMode: 'exam', mirror: true };
let anchorProfile = { local_profile_id: uid(), display_name_local_only: '', operator_id: '' };
let questionSets = [];
let activeQuestionSetId = null;
let currentDraft = null;
let aiCapabilities = { enabled: false, status: 'checking', reason: '正在检测本地隔离 AI 网关状态…' };

let session = null;
let busy = false;
let timerBusy = false;
let urls = [];
let lastCheckpoint = 0;
let recordingLockRelease = null;
let lastSession = null;
let wakeLock = null;
let pendingFault = null;


// Expose speech & local ASR controllers on window solely for deterministic browser E2E verification
if (typeof window !== 'undefined') {
  window.__tclStreamerApp = {
    modelNetworkRequests: 0
  };
}

const statusLabels = {
  saved: '已保存（无弹幕纯净原片）',
  stored: '数据已保存，播放待确认',
  unavailable: '未录制',
  partial: '部分录像异常',
  recording: '录制中',
  pending: '等待录制',
  failed: '录制失败',
  empty: '无有效内容',
  interrupted: '录制中断，原片已保留待恢复',
  'storage-failed': '存储失败',
  none: '无录像（未通过或已取消按策略清理）',
  unplayable: '解码检查未通过',
  deleted_after_fail_policy: '考核未通过（已按规则清理本地录像，保留文字成绩）',
  deleted_after_cancel: '中途取消（已清理本场临时录像）',
  local_retained_pass_pending_cloud: '考核通过（本地保留无弹幕原片，待接云端）',
  local_pending_scoring: '待评分保护（原片本地安全保留，严禁删除）'
};

function notice(text, level = 'info') {
  appendNotice(text, level, {
    notices: $('notices'),
    details: $('noticeDetails'),
    count: $('noticeCount'),
    createParagraph: () => document.createElement('p')
  });
  const dialog = document.querySelector('dialog[open]');
  if (dialog) {
    let message = dialog.querySelector('.dialog-notice');
    if (!message) {
      message = document.createElement('p');
      message.className = 'dialog-notice';
      dialog.querySelector('.dialog-head')?.after(message);
    }
    message.hidden = false;
    message.setAttribute('role', level === 'error' || level === 'warning' ? 'alert' : 'status');
    message.textContent = text;
  }
}

function clearNotices() {
  if (!$('notices')) return;
  $('notices').replaceChildren();
  $('noticeDetails').hidden = true;
  $('noticeDetails').open = false;
  $('noticeCount').textContent = '';
}

const media = new MediaEngine($('stage'), $('cameraSource'), notice, reason => {
  pendingFault = reason;
  notice(reason, 'error');
  setTimeout(() => {
    if (session?.state === 'running') run(pause, 'pause');
  }, 0);
});

const speech = new SpeechRecognitionController({
  onUpdate() { /* R6: transcript deliberately hidden during recording. */ },
  onStatusChange(status, detail) {
    const badge = $('asrStatusBadge');
    if (badge) {
      badge.textContent = status === 'ok' ? '语音识别中' : detail || status;
      badge.dataset.tone = status === 'ok' ? 'pass' : 'warn';
    }
    const homeBadge = $('localAsrStatusBadge');
    if (homeBadge) {
      homeBadge.textContent = status === 'ok' ? '识别运行中' : status === 'unsupported' ? '浏览器不支持' : '录像继续 · 转写待确认';
      homeBadge.dataset.tone = status === 'ok' ? 'pass' : 'warn';
    }
  }
});

if (typeof window !== 'undefined') {
  window.__tclStreamerApp.speech = speech;
  window.__tclStreamerApp.media = media;
  window.__tclStreamerApp.triggerAutoRecovery = () => triggerAutoScoreRecovery('manual_test_trigger');
}

media.render(() => {
  if (!session || session.state === 'idle') return null;
  return {
    current: session.current,
    elapsed: session.activeMs,
    questionMs: session.current ? session.activeMs - session.current.startActiveMs : 0,
    paused: session.state !== 'running'
  };
});

const actions = new ActionGate({
  changed() {
    busy = actions.busy;
    update();
  },
  error(error) {
    notice(error?.message || String(error), 'error');
  },
  async settled() {
    if ((document.hidden || pendingFault) && session?.state === 'running') {
      try { await pause(); } catch (error) { notice(error.message, 'error'); }
    }
    pendingFault = null;
  }
});

function run(action, kind = 'regular') {
  return actions.run(kind === true ? 'deferred' : kind, action);
}

let swRegistration;
const appCache = createAppCacheGuard({
  serviceWorker: globalThis.isSecureContext ? navigator.serviceWorker : undefined,
  cacheStorage: globalThis.caches,
  getSession: () => session,
  isBusy: () => actions.busy || (!!media.recorder && media.recorder.state !== 'inactive'),
  getRegistration: () => swRegistration,
  notice,
  reload: () => location.reload()
});

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

function getActiveQuestionSet() {
  return questionSets.find(s => s.id === activeQuestionSetId) || questionSets[0] || null;
}

function renderAnchorProfileUI() {
  if ($('authBlockerNote')) $('authBlockerNote').textContent = AUTH_BLOCKER_NOTICE;
  const experience = isLocalExperienceProfile(anchorProfile);
  const nameInput = $('localDemoNameInput');
  if (nameInput && document.activeElement !== nameInput) {
    nameInput.value = experience ? anchorProfile.display_name_local_only : (nameInput.value || '体验主播');
  }
  if ($('profileSavedBadge')) {
    $('profileSavedBadge').textContent = experience ? '本机体验中' : '尚未绑定运营';
    $('profileSavedBadge').dataset.tone = experience ? 'warn' : 'warn';
  }
  if ($('localDemoStatus')) {
    $('localDemoStatus').textContent = experience
      ? `当前体验昵称：${anchorProfile.display_name_local_only}。未绑定真实运营，不能生成正式考核成绩。`
      : '尚未进入体验模式；正式绑定需等待运营后台提供在线验证接口。';
  }
  if ($('exitLocalDemoButton')) $('exitLocalDemoButton').hidden = !experience;
  if ($('localExperienceBanner')) $('localExperienceBanner').hidden = !experience;
  if ($('startButton')) {
    $('startButton').textContent = experience ? '开始本机体验录制（非正式考核）' : '开始考核录制（需要正式授权）';
    $('startButton').disabled = !experience || busy;
    $('startButton').title = experience ? '体验过程录制保存在本机，不能作为正式考核成绩' : '运营后台尚未接入，正式授权入口暂不可用';
  }
}

function renderQuestionSetsSelector() {
  const select = $('activeQuestionSetSelect');
  if (!select) return;
  select.replaceChildren();
  for (const qs of questionSets) {
    const readyCount = (qs.questions || []).filter(q => q.status === 'ready' && q.question_type === 'oral_qa').length;
    const opt = document.createElement('option');
    opt.value = qs.id;
    opt.textContent = qs.title;
    opt.title = `${qs.title}（可用口头问答 ${readyCount} 题 · v${qs.version || 1}）`;
    select.append(opt);
  }
  const active = getActiveQuestionSet();
  if (active) {
    activeQuestionSetId = active.id;
    select.value = active.id;
    const readyCount = (active.questions || []).filter(q => q.status === 'ready' && q.question_type === 'oral_qa').length;
    const incompleteCount = (active.questions || []).filter(q => q.status === 'incomplete').length;
    $('knowledgeTitle').textContent = `${active.title}（v${active.version} · #${active.hash.slice(0, 6)}）`;
    $('knowledgeStatus').textContent = `共 ${active.questions.length} 条｜可抽口头问答 ${readyCount} 题${incompleteCount ? `｜待完善 ${incompleteCount} 题` : ''} · 点击编辑或上传新文件`;
    const badge = $('activeSetBadge');
    if (badge) {
      badge.textContent = readyCount >= 1 ? `可抽 ${Math.min(5, readyCount)} 题` : '缺少可用题';
      badge.dataset.tone = readyCount >= 1 ? 'pass' : 'fail';
    }
  } else {
    $('knowledgeTitle').textContent = '尚未创建题目集';
    $('knowledgeStatus').textContent = '请点击上传 DOCX / XLSX / XLS / 文字PDF / TXT 题目文件';
  }
}

function update() {
  const active = !!session && ['running', 'paused'].includes(session.state);
  const running = session?.state === 'running';
  const ended = session?.state === 'ended';
  const current = session?.current;

  document.body.dataset.mirror = String(settings.mirror !== false);
  const cameraSlot = $(active ? 'liveCameraSlot' : 'homeCameraSlot');
  if (cameraSlot && $('cameraControl') && $('cameraControl').parentElement !== cameraSlot) {
    cameraSlot.append($('cameraControl'));
  }

  $('stageWrap')?.style.setProperty('--preview-ratio', settings.orientation === 'landscape' ? '16 / 9' : '9 / 16');
  $('stageWrap')?.classList.toggle('landscape', settings.orientation === 'landscape');
  $('stageWrap')?.classList.toggle('live-camera', !!media.camera);
  $('stageWrap')?.classList.toggle('camera-off', !media.camera);
  document.body.classList.toggle('camera-on', !!media.camera);

  // TASK002 P1-02: Live barrage ASR preview strictly reflects real ASR output, never manual input
  // R6: never display live speech content to anchor or overlay; show status only.
  const effectivePreview = '';

  renderLiveBarrageDOM($('liveBarrageOverlay'), {
    visible: Boolean(active && session?.recordingConfirmed && current),
    question: current,
    questionIndex: current?.ordinal || current?.number || 1,
    totalQuestions: session?.target || 5,
    questionElapsedMs: current ? session.activeMs - current.startActiveMs : 0,
    asrPreviewText: effectivePreview,
    paused: !running
  });

  if ($('asrLiveBox')) {
    $('asrLiveBox').hidden = !active || !session?.recordingConfirmed;
  }

  $('referenceButton').hidden = !active || (session?.record?.trainingMode || settings.trainingMode) === 'exam';
  $('liveStatus').textContent = actions.ending
    ? '正在收尾录像并保存已确认的语音文字'
    : busy
      ? '处理中…'
      : running
        ? '录制与答题进行中'
        : session?.fsm?.state === 'record_start_failed'
          ? '录制启动失败'
          : '已暂停';

  for (const id of ['homeResolution', 'homeOrientation', 'openKnowledge', 'bankShortcut', 'activeQuestionSetSelect', 'saveProfileButton', 'questionSetOpenButton']) {
    if ($(id)) $(id).disabled = active || busy;
  }
  $('navHome').disabled = busy;
  $('navRecords').disabled = active || busy;
  $('navKnowledge').disabled = active || busy;
  $('settingsButton').disabled = active || busy;
  $('historyButton').disabled = active || busy;

  $('startButton').hidden = active || (ended && document.body.dataset.page !== 'home');
  $('startButton').disabled = busy || !isLocalExperienceProfile(anchorProfile);
  $('retryRecordButton').hidden = session?.fsm?.state !== 'record_start_failed';

  $('nextButton').hidden = !running || !session?.recordingConfirmed;
  $('nextButton').disabled = !running || busy;
  if (running && current) {
    const isLast = (session.pending?.length || 0) === 0;
    $('nextButton').textContent = isLast
      ? `完成考核（第 ${current.ordinal} / ${session.target} 题）`
      : `下一题（当前第 ${current.ordinal} / ${session.target} 题）`;
  }

  $('resumeButton').hidden = !active || running;
  $('resumeButton').disabled = busy;
  $('skipButton').hidden = !running || !session?.recordingConfirmed;
  $('skipButton').disabled = !running || busy;
  $('endButton').hidden = !active;
  $('endButton').disabled = !active || actions.ending;
  $('pauseButton').disabled = !active || actions.ending || !!actions.playbackTransition;
  $('pauseButton').textContent = actions.playbackTransition === 'pause'
    ? '正在暂停'
    : actions.playbackTransition === 'resume'
      ? '正在继续'
      : running
        ? '暂停'
        : '继续';

  document.querySelector('.two-buttons').hidden = !running;
  document.querySelector('.controls').hidden = ended && document.body.dataset.page !== 'home';
  // R5: A historical result does NOT require a live, ended TrainingSession.
  $('sessionSummary').hidden = !isResultViewVisible(document.body.dataset.page, session, lastSession);
  const failedStart = session?.fsm?.state === 'record_start_failed';
  $('recordStartFaultPanel').hidden = !(failedStart && document.body.dataset.page === 'live');
  $('leaveLiveButton').hidden = document.body.dataset.page !== 'live';
  if (failedStart) {
    $('recordStartFaultText').textContent = session?.record?.record_start_error || session?.record?.reason || '录制未能开始。请检查摄像头与麦克风权限，返回检查设备后重试。';
  }

  $('cameraButton').disabled = busy || (active && !!media.stream);
  $('cameraButton').textContent = media.camera ? '关闭摄像头' : '开启摄像头';
  $('cameraButton').setAttribute('aria-pressed', String(!!media.camera));

  $('recordBadge').textContent = active
    ? media.recorder
      ? `${media.recorder.state === 'inactive' ? '录像收尾与解码校验中' : media.recorder.state === 'paused' ? '录像已暂停' : '录制中（画面无弹幕）'} · ${media.audioStatusText()}`
      : '未录制 · 请检查设备权限'
    : ended
      ? `录像状态：${statusLabels[session.record.recording?.status] || statusLabels[session.record.recordingStatus] || session.record.recordingStatus}`
      : '尚未开始录制';

  $('audioCheckButton').hidden = !active || media.audioStatus().status !== 'suspended';
  $('emergencyButton').hidden = !media.emergency.length;

  if (current && session?.recordingConfirmed) {
    $('trainingProgress').textContent = `第 ${current.ordinal || current.number} / ${session.target} 题`;
    $('questionName').textContent = `题库：${session.record.question_set_snapshot?.title || '当前题集'} · 口头问答题`;
    $('questionText').textContent = current.question_text || current.content;
    $('liveTime').textContent = formatTime(current.endedAt === null ? session.activeMs - current.startActiveMs : current.durationMs);
  }
}

async function persistSettingsAndProfile() {
  await db.put('settings', {
    settings,
    anchorProfile,
    activeQuestionSetId
  }, 'config');
}

async function checkpoint() {
  if (!session) return;
  lastCheckpoint = performance.now();
  lastSession = session.snapshot();
  try {
    await db.put('sessions', lastSession);
    lastCheckpoint = performance.now();
    return true;
  } catch (error) {
    notice(db.storageError(error), 'error');
    return false;
  }
}

async function acquireLock() {
  if (!navigator.locks) return;
  const acquired = await new Promise((resolve, reject) => {
    navigator.locks.request('tcl-v43-preview-r4-recorder', { ifAvailable: true }, async lock => {
      if (!lock) { resolve(false); return; }
      resolve(true);
      await new Promise(done => { recordingLockRelease = done; });
    }).catch(reject);
  });
  if (!acquired) throw new Error('另一个浏览器标签页正在录制练播，请先结束该标签页训练');
}

function releaseLock() {
  recordingLockRelease?.();
  recordingLockRelease = null;
}

async function requestWakeLock() {
  try { wakeLock = await navigator.wakeLock?.request('screen'); } catch {}
}

// Start formal practice/exam session
async function start() {
  if (media.pendingEncoders.size) {
    throw new Error('上一场录像编码器尚未收尾完成，请稍候片刻再试');
  }
  if (!isLocalExperienceProfile(anchorProfile)) {
    throw new Error('尚未获得运营后台授权；当前可先点击「进入本机体验练播房」体验流程。');
  }
  // TASK010: local_preview is never a formal operator-issued credential.
  renderAnchorProfileUI();

  const activeSet = getActiveQuestionSet();
  if (!activeSet) {
    throw new Error('请先选择或上传确认一套题目集');
  }
  const readyOralQuestions = (activeSet.questions || []).filter(
    q => q.status === 'ready' && q.question_type === 'oral_qa' && String(q.reference_answer || '').trim()
  );
  if (readyOralQuestions.length < 1) {
    throw new Error(`题目集「${activeSet.title}」中没有可用的口头问答题（至少需 1 道含参考答案的口头问答），请先点击题目集补充或确认`);
  }

  await db.storageHealth();
  const snapshot = await db.createQuestionSetSnapshot(activeSet);
  await persistSettingsAndProfile();
  clearNotices();

  const browserConsent = Boolean($('browserSpeechNoticeCheck')?.checked);
  if (!browserConsent || !speech.supported) notice('当前浏览器语音识别未启用；视频照常录制，未识别的题目保留待转写。', 'warning');

  await acquireLock();

  session = new TrainingSession(readyOralQuestions, {
    ...settings,
    anchor: anchorProfile,
    questionSetSnapshot: snapshot,
    consents: {
      browser_speech_notice_acknowledged: Boolean($('browserSpeechNoticeCheck')?.checked),
      gemini_audio_transcription_consent: false,
      local_asr_model_install_consent: false
    }
  });

  document.body.dataset.page = 'live';
  $('questionText').textContent = '正在自检并启动摄像头与麦克风录制，录制真正启动后将立即显示第 1 题…';
  $('liveBarrageOverlay').hidden = true;
  if ($('manualTranscriptInput')) $('manualTranscriptInput').value = '';

  try {
    await db.put('sessions', session.record);
    await media.prepare(session.record, settings.resolution, settings.orientation);
    await media.startSegment(null, 0);
    if (!media.recorder || media.recorder.state !== 'recording') {
      throw new Error('MediaRecorder 未能进入 recording 状态');
    }
    const recStartPos = media.timeline?.positionMs || 0;
    session.confirmRecordingStarted({ recordingPosMs: recStartPos });
    media.timeline.open(session.current, media.recording.id, session.activeMs);
    media.startQuestionAudioSlice(session.current.question_id, recStartPos);

    speech.startSession(session.current.question_id, { consented: browserConsent });
    if ($('liveTranscriptText')) $('liveTranscriptText').textContent = '';

    session.record.recordingStatus = 'recording';
    await checkpoint();
    await requestWakeLock();
    update();
  } catch (error) {
    speech.stopSession();
    await media.finishRecording(session?.activeMs || 0);
    media.releaseRecording();
    releaseLock();
    if (session) {
      session.markRecordingStartFailed(describeMediaError(error));
      session.record.record_start_error = describeMediaError(error);
      await checkpoint();
    }
    update();
    throw new Error(describeMediaError(error));
  }
}

// TASK002 P1-02 & TASK004: Pass trusted ASR transcript separately from manualNote so manual input NEVER overwrites ASR in formal exams
async function handleManualAdvance(explicitSkip = false) {
  if (!session || session.state !== 'running') return;
  const currentQ = session.current;
  if (!currentQ) return;

  // Freeze the current question BEFORE persistence; partial/interim recognition must
  // remain pending even when earlier final fragments exist. Also blocks stale callbacks.
  const speechInfo = speech.sealQuestion(currentQ.question_id);
  const manualNote = $('manualTranscriptInput')?.value?.trim() || '';
  const asrTranscript = explicitSkip ? '' : (speechInfo.finalText || '');
  const audioObs = media.audioStatus();
  const posMs = media.timeline?.positionMs ?? session.activeMs;

  media.closeQuestion(session.activeMs);

  const effectiveAsrStatus = speechInfo.status === 'technical_fault' || speechInfo.status === 'unsupported' || speechInfo.status === 'permission_denied'
    ? speechInfo.status : (!asrTranscript && !explicitSkip ? 'technical_fault' : speech.status);

  const stepResult = session.advanceQuestion({
    asrTranscript,
    transcriptionProvider: speechInfo.provider || 'browser',
    asrModelVersion: speechInfo.asrModelVersion || null,
    sourceAudioHash: speechInfo.sourceAudioHash || null,
    asrSegmentCount: speechInfo.segments?.length || 0,
    manualNote,
    transcriptionStatus: !explicitSkip && (!asrTranscript || ['technical_fault', 'unsupported', 'permission_denied'].includes(speechInfo.status)) ? 'technical_fault' : 'completed',
    audioSignalDetected: Boolean(audioObs.questionSignalDetected),
    asrStatus: effectiveAsrStatus,
    explicitSkip,
    recordingPosMs: posMs,
    idempotencyKey: `q-advance:${session.record.id}:${currentQ.question_id}`
  });

  if (!stepResult.accepted) return;
  if ($('manualTranscriptInput')) $('manualTranscriptInput').value = '';

  if (stepResult.finishedAllQuestions) {
    await completeExamAndScore();
    return;
  }

  const nextQ = session.current;
  speech.switchQuestion(nextQ.question_id);
  if ($('liveTranscriptText')) $('liveTranscriptText').textContent = '';
  await media.startSegment(nextQ, session.activeMs);
  await checkpoint();
  update();
}

async function pause() {
  if (session?.state !== 'running') return;
  session.pause();
  speech.pauseListening();
  await media.pauseRecording(session.activeMs);
  await checkpoint();
  try { await wakeLock?.release(); } catch {}
  wakeLock = null;
  update();
}

async function resume() {
  if (session?.state !== 'paused') return;
  session.resume();
  await media.startSegment(session.current, session.activeMs);
  speech.resumeListening({ consented: Boolean(session?.record?.consents?.browser_speech_notice_acknowledged) });
  await checkpoint();
  await requestWakeLock();
  update();
}

async function completeExamAndScore() {
  if (!session) return;
  speech.stopSession();
  session.pause();
  const endedMono = session.now();
  const endedAt = Date.now();

  await media.finishRecording(session.activeMs);
  session.end();
  session.endedMono = endedMono;
  session.record.endedAt = endedAt;
  session.record.recordingStatus = media.summary();
  if (session.record.recording) {
    session.record.recording.status = session.record.recordingStatus;
  }

  media.releaseRecording();
  await media.toggleCamera(false);
  releaseLock();
  try { await wakeLock?.release(); } catch {}
  wakeLock = null;

  // R6 browser-only: final recognition words were captured while recording.
  // R6 only: no local model and no post-recording transcription. Recognition happened during recording.

  // TASK010: local experience does not request Gemini transcription, Gemini grading,
  // or create a scoring queue. Save the real recording/transcription as pending only.
  if (session.record.anchor?.identity_scope === 'local_preview') {
    session.record.assessment = {
      status: 'scoring_pending_quota',
      passed: null,
      average_raw: null,
      average_display: null,
      source: 'pending',
      reason: '本机体验结束：录像、题目和可用的本地转写已保存在此浏览器；未绑定运营，禁止正式 AI 评分和后台同步。'
    };
    lastSession = session.snapshot();
    await db.put('sessions', lastSession);
    renderResultSummary(lastSession);
    document.body.dataset.page = 'result';
    update();
    return;
  }

  // Browser-only R6: never ask for Gemini audio fallback or upload raw microphone data.
  // Incomplete browser transcripts remain pending; preserve recording for later authorized handling.
  const faultQuestions = (session.record.questions || []).filter(
    q => !q.skipped_by_anchor && (!q.transcript || q.transcription_status === 'technical_fault')
  );
  if (faultQuestions.length) {
    session.record.assessment = {
      ...session.record.assessment,
      status: 'transcription_pending', passed: null,
      reason: `有 ${faultQuestions.length} 题缺少完整可信的浏览器最终语音转写；录像安全保留待转写，未计算成绩。`
    };
    lastSession = session.snapshot();
    await db.put('sessions', lastSession);
    renderResultSummary(lastSession);
    document.body.dataset.page = 'result';
    update();
    return;
  }

  if (session.fsm.canTransition('scoring')) {
    session.fsm.transition('scoring', { source: 'auto_submit_score', detail: '自动提交语义评分' });
  }

  await submitSessionForScoring(session.record);
  lastSession = session.snapshot();
  await db.put('sessions', lastSession);

  renderResultSummary(lastSession);
  document.body.dataset.page = 'result';
  update();
}

function renderResultSummary(record) {
  if (!record || typeof record !== 'object') throw new Error('历史考核记录不存在或格式无效');
  if (isFailedStartRecord(record)) throw new Error('录制未成功开始：此记录没有可恢复的语音或录像评分结果');
  const assessment = record.assessment || {};
  const status = assessment.status || 'scoring_pending_quota';
  const passed = assessment.passed;

  const scoreBox = $('scoreBox');
  if (scoreBox) {
    scoreBox.dataset.status = passed === true ? 'pass' : passed === false ? 'fail' : 'pending';
  }
  $('resultSymbol').textContent = passed === true ? '✓' : passed === false ? '✕' : '⏳';
  $('summaryHeading').textContent = passed === true
    ? '考核通过'
    : passed === false
      ? '考核未通过'
      : STATE_LABELS[status] || '等待评分 / 待联调';

  const sourceLabels = {
    real_ai: '评分来源：真实 AI 语义评分（Gemini Free Tier）',
    test_simulation: '评分来源：本地测试模拟夹具（非真实 AI 联调）',
    rule_skip_zero: '评分来源：主动跳题 0 分规则判定',
    schema_rejected: '评分来源：模型返回未通过 Schema 校验（需重试）',
    pending: '评分来源：待评分（尚未完成真实 AI 联调或配额等待中）'
  };
  $('scoreSourceLabel').textContent = sourceLabels[assessment.source] || sourceLabels.pending;

  if (typeof assessment.average_raw === 'number') {
    $('scoreValueDisplay').textContent = `${assessment.average_display} 分（精确均分 ${assessment.average_raw.toFixed(2)}）`;
  } else {
    $('scoreValueDisplay').textContent = STATE_LABELS[status] || '待评分';
  }

  $('assessmentStatus').textContent = assessment.reason || '';
  $('summaryStats').textContent =
    `主播：${record.anchor?.display_name_local_only || '未填'} · 直属运营：${record.anchor?.operator_name || record.anchor?.operator_id || '未选'} · 题集快照：${record.question_set_snapshot?.title || ''} (#${(record.question_set_snapshot?.hash || '').slice(0, 6)}) · 总用时 ${formatTime(record.totalMs)}`;

  const recStatus = record.recording?.status || record.recordingStatus;
  $('summarySave').textContent = `本地存储状态：${statusLabels[recStatus] || recStatus}`;

  if (passed === false && status === 'fail') {
    $('improvementTips').textContent =
      '本场考核未通过：正式评分已完成且文字成绩/错误分析已持久化保存，本地原始录像分块与临时语音分片已按安全规则清理，不向运营后台上传失败录像。';
  } else if (passed === true && status === 'pass') {
    $('improvementTips').textContent =
      `本场考核已通过：无弹幕原始录像与独立弹幕时间轴已保存在本机（预留保留到期时间：${record.recording?.retention_expires_at || '7天'}；当前阶段未连接 CloudBase，未启动云端每日 18:00 定时清理任务）。`;
  } else {
    $('improvementTips').textContent =
      '当前尚未完成正式 AI 判定。录像、可用的浏览器最终转写与答题时间轴已在本机保留；默认浏览器无法对历史录像直接补转写，不会自动判零分。';
  }

  $('retryScoringButton').hidden = true;
  $('viewSummary').hidden = recStatus === 'deleted_after_fail_policy' || recStatus === 'deleted_after_cancel';

  const listEl = $('resultQuestionList');
  listEl.replaceChildren();
  for (const q of normalizeHistoryQuestions(record)) {
    const card = document.createElement('div');
    card.className = 'result-q-card';

    const head = document.createElement('div');
    head.className = 'result-q-head';
    const qTitle = document.createElement('strong');
    qTitle.textContent = `第 ${q.ordinal || q.number} 题：${q.question_text || q.content}`;
    const qBadge = document.createElement('span');
    qBadge.className = 'status-pill';
    if (typeof q.score === 'number') {
      qBadge.textContent = `${q.score} 分${q.skipped_by_anchor ? '（主动跳题）' : ''}`;
      qBadge.dataset.tone = q.score >= 80 ? 'pass' : 'fail';
    } else {
      qBadge.textContent = q.transcription_status === 'technical_fault' ? '待转写（录像已保留）' : '待评分';
      qBadge.dataset.tone = 'warn';
    }
    head.append(qTitle, qBadge);

    const grid = document.createElement('div');
    grid.className = 'result-q-grid';

    const ansBox = document.createElement('div');
    ansBox.className = 'result-q-box';
    const ansLabel = document.createElement('strong');
    const modelVerTag = q.asr_model_version ? ` · ${q.asr_model_version}` : '';
    ansLabel.textContent = `主播实际语音识别转写（来源：${q.transcription_provider || '无'}${modelVerTag}）`;
    const ansText = document.createElement('p');
    ansText.textContent = q.skipped_by_anchor
      ? '（主播主动跳过本题，未作答）'
      : q.transcript
        ? q.transcript
        : '（本题未获取浏览器最终识别文字，录像已保留待转写）';
    ansBox.append(ansLabel, ansText);

    if (q.manual_note_untrusted) {
      const noteEl = document.createElement('p');
      noteEl.className = 'muted';
      noteEl.textContent = `复盘备注（不计入正式评分）：${q.manual_note_untrusted}`;
      ansBox.append(noteEl);
    }

    const refBox = document.createElement('div');
    refBox.className = 'result-q-box';
    const refLabel = document.createElement('strong');
    refLabel.textContent = '完整参考答案';
    const refText = document.createElement('p');
    refText.textContent = q.reference_answer || q.reference || '';
    refBox.append(refLabel, refText);
    grid.append(ansBox, refBox);

    const analysisP = document.createElement('p');
    analysisP.className = 'muted';
    const hits = Array.isArray(q.semantic_matches) && q.semantic_matches.length
      ? `命中要点：${q.semantic_matches.join('；')}。`
      : '';
    const misses = Array.isArray(q.missing_or_incorrect) && q.missing_or_incorrect.length
      ? `缺失/偏差：${q.missing_or_incorrect.join('；')}。`
      : '';
    const severe = q.severe_product_misinformation
      ? `【重大产品事实错误警示：${q.critical_false_claim_reason || '虚构产品参数'}】`
      : '';
    analysisP.textContent = [severe, hits, misses, q.reasoning_summary || '等待 AI 语义评分分析'].filter(Boolean).join(' ');

    card.append(head, grid, analysisP);
    listEl.append(card);
  }
}

function openCancelConfirmModal() {
  if (!session || !['running', 'paused'].includes(session.state)) return;
  $('cancelConfirmDialog')?.showModal();
}

async function confirmMidSessionCancel() {
  $('cancelConfirmDialog')?.close();
  if (!session) return;
  speech.stopSession();
  await media.finishRecording(session.activeMs);
  session.cancelMidSession();
  media.releaseRecording();
  await media.toggleCamera(false);
  releaseLock();
  try { await wakeLock?.release(); } catch {}
  wakeLock = null;

  await db.applyPostAssessmentStoragePolicy(session.record);
  session = null;
  document.body.dataset.page = 'home';
  notice('已确认取消本场练播：未生成正式成绩、不计入通过率，本场临时录像片段已清理，历史记录完好保留。', 'info');
  update();
}

function openQuestionSetManager(setToLoad = getActiveQuestionSet()) {
  if (setToLoad) {
    const { items, summary } = evaluateAndClassifyItems(setToLoad.questions || []);
    currentDraft = {
      existingId: setToLoad.id,
      existingVersion: setToLoad.version || 1,
      title: setToLoad.title,
      sourceFileName: setToLoad.sourceFileName || '已存题集',
      items,
      summary
    };
  } else {
    currentDraft = {
      existingId: null,
      existingVersion: 0,
      title: '新建产品题目集',
      sourceFileName: '手动创建',
      items: [],
      summary: evaluateAndClassifyItems([]).summary
    };
  }
  renderDraftEditor();
  $('knowledgeDialog').showModal();
}

function renderDraftEditor() {
  if (!currentDraft) return;
  const evaluated = evaluateAndClassifyItems(currentDraft.items);
  currentDraft.items = evaluated.items;
  currentDraft.summary = evaluated.summary;

  if (document.activeElement !== $('draftSetTitleInput')) {
    $('draftSetTitleInput').value = currentDraft.title || '';
  }
  const s = currentDraft.summary;
  $('draftStatsSummary').innerHTML =
    `<span class="status-pill" data-tone="pass">可用口头问答 ${s.readyCount}</span> ` +
    `<span class="status-pill" data-tone="warn">待完善(缺答案) ${s.incompleteCount}</span> ` +
    `<span class="status-pill" data-tone="warn">待核对 ${s.needsReviewCount}</span> ` +
    `<span class="status-pill">非口头题型 ${s.unsupportedTypeCount}</span> ` +
    `<span class="status-pill" data-tone="${s.duplicateCount || s.conflictCount ? 'fail' : 'pass'}">重复 ${s.duplicateCount} / 冲突 ${s.conflictCount}</span>`;

  const container = $('draftItemsContainer');
  container.replaceChildren();

  currentDraft.items.forEach((item, idx) => {
    const card = document.createElement('div');
    card.className = 'draft-item-card';

    const head = document.createElement('div');
    head.className = 'draft-item-head';
    const loc = document.createElement('span');
    loc.textContent = `#${idx + 1} · 来源：${item.source_locator}`;
    const statusBadge = document.createElement('span');
    statusBadge.className = 'status-pill';
    statusBadge.textContent = QUESTION_STATUS_LABELS[item.status] || item.status;
    statusBadge.dataset.tone = item.status === 'ready' ? 'pass' : ['conflict', 'duplicate', 'unparseable'].includes(item.status) ? 'fail' : 'warn';
    head.append(loc, statusBadge);

    const grid = document.createElement('div');
    grid.className = 'profile-grid';

    const qLabel = document.createElement('label');
    qLabel.textContent = '题干（观众提问）';
    const qInput = document.createElement('textarea');
    qInput.rows = 2;
    qInput.value = item.question_text;
    qInput.onchange = () => {
      currentDraft.items[idx].question_text = qInput.value.trim();
      renderDraftEditor();
    };
    qLabel.append(qInput);

    const aLabel = document.createElement('label');
    aLabel.textContent = '参考答案（必填方可参与抽题，禁止臆造）';
    const aInput = document.createElement('textarea');
    aInput.rows = 2;
    aInput.value = item.reference_answer;
    aInput.placeholder = '请填写或核对参考答案要点；留空则标记为「待完善」且不会被抽中';
    aInput.onchange = () => {
      currentDraft.items[idx].reference_answer = aInput.value.trim();
      renderDraftEditor();
    };
    aLabel.append(aInput);
    grid.append(qLabel, aLabel);

    const foot = document.createElement('div');
    foot.className = 'inline-actions';

    const typeSelect = document.createElement('select');
    typeSelect.style.width = 'auto';
    for (const [val, label] of Object.entries(QUESTION_TYPE_LABELS)) {
      const o = document.createElement('option');
      o.value = val;
      o.textContent = label;
      typeSelect.append(o);
    }
    typeSelect.value = item.question_type;
    typeSelect.onchange = () => {
      currentDraft.items[idx].question_type = typeSelect.value;
      renderDraftEditor();
    };
    foot.append(typeSelect);

    if (item.raw_unpaired) {
      const confirmBtn = document.createElement('button');
      confirmBtn.type = 'button';
      confirmBtn.textContent = '确认此条配对无误';
      confirmBtn.onclick = () => {
        currentDraft.items[idx].confirmed_pairing = true;
        currentDraft.items[idx].raw_unpaired = false;
        renderDraftEditor();
      };
      foot.append(confirmBtn);
    }

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.className = 'danger-button';
    delBtn.textContent = '删除此条';
    delBtn.onclick = () => {
      currentDraft.items.splice(idx, 1);
      renderDraftEditor();
    };
    foot.append(delBtn);

    const reasonP = document.createElement('p');
    reasonP.className = 'muted';
    reasonP.textContent = item.status_reason;

    card.append(head, grid, foot, reasonP);
    container.append(card);
  });
}

let historyGeneration = 0;
function configurePlayback(player) {
  player.controls = true;
  player.playsInline = true;
  player.muted = false;
  player.defaultMuted = false;
  player.volume = 1;
  player.setAttribute('playsinline', '');
  player.setAttribute('webkit-playsinline', '');
}

function clearPlayback() {
  historyGeneration++;
  $('historyDetail')?.querySelectorAll('video,audio').forEach(el => {
    el.pause();
    el.removeAttribute('src');
    el.load();
  });
  urls.forEach(url => URL.revokeObjectURL(url));
  urls = [];
}

async function appendWholeRecording(detail, record, recording) {
  const section = document.createElement('section');
  section.className = 'whole-recording';
  const heading = document.createElement('h3');
  heading.textContent = '整场无弹幕原始录像回放（DOM 弹幕独立同步叠加）';
  const info = document.createElement('p');
  info.className = 'muted';
  info.textContent = '视频文件本身仅含摄像头画面与麦克风音频（contains_barrage: false）；播放时由独立 DOM 层按 barrage_timeline 毫秒级同步渲染弹幕，支持拖动、暂停、倍速同步。';
  section.append(heading, info);
  detail.append(section);

  if (record.recording?.status === 'deleted_after_fail_policy' || recording.status === 'deleted_after_fail_policy') {
    info.textContent = '本场考核未通过：根据 V4.3 存储安全策略，正式评分完成并保存文字记录后已自动清理本地视频数据，仅保留下方逐题文字成绩与错误分析。';
    return;
  }

  try {
    const generation = historyGeneration;
    const blob = await db.segmentBlob(recording);
    if (generation !== historyGeneration || !$('historyDialog').open) return;
    if (!blob.size) {
      info.textContent = '本场没有可用录像字节（可能已清理或未录制），下方文字答题记录仍完整保留。';
      return;
    }
    const url = URL.createObjectURL(blob);
    urls.push(url);
    const mime = recording.mime || blob.type || '';
    const isAudioOnly = recording.mode === 'audio-only' || mime.startsWith('audio');
    const player = document.createElement(isAudioOnly ? 'audio' : 'video');
    player.className = 'playback';
    configurePlayback(player);
    player.preload = 'metadata';
    player.src = url;

    const stageBox = document.createElement('div');
    stageBox.className = 'playback-stage-container';
    stageBox.append(player);

    const timelineItems = Array.isArray(record.barrage_timeline) && record.barrage_timeline.length
      ? record.barrage_timeline
      : (record.questions || []).map(q => ({
          question_id: q.question_id || q.id,
          order: q.ordinal || q.number,
          question_text: q.question_text || q.content,
          barrage_start_ms: q.barrage_start_ms ?? q.videoRanges?.[0]?.startMs ?? 0,
          barrage_end_ms: q.barrage_end_ms ?? q.videoRanges?.[0]?.endMs ?? record.totalMs
        }));
    attachPlaybackBarrageOverlay(player, stageBox, timelineItems);

    const status = document.createElement('p');
    status.className = 'muted';
    status.textContent = `无弹幕原片 ${(blob.size / 1024 / 1024).toFixed(2)} MB · ${recording.mime || 'video/webm'} · ${statusLabels[recording.status] || recording.status}`;

    section.append(
      stageBox,
      status,
      createFileActions({
        blob,
        recording,
        sessionId: record.id,
        url,
        status,
        assessmentStatus: record.assessment?.status || 'pending'
      })
    );

    const navigation = document.createElement('div');
    navigation.className = 'recording-navigation';
    const label = document.createElement('label');
    label.textContent = '跳转到指定题目时段（DOM弹幕同步定位）';
    const select = document.createElement('select');
    const ranges = [];
    for (const q of record.questions || []) {
      const startMs = q.barrage_start_ms ?? q.videoRanges?.[0]?.startMs ?? 0;
      const endMs = q.barrage_end_ms ?? q.videoRanges?.[0]?.endMs ?? recording.durationMs;
      const opt = document.createElement('option');
      opt.value = String(ranges.length);
      opt.textContent = `第 ${q.ordinal || q.number} 题：${(q.question_text || q.content || '').slice(0, 32)} (${formatPosition(startMs)})`;
      ranges.push({ startMs, endMs });
      select.append(opt);
    }
    label.append(select);
    const seekBtn = document.createElement('button');
    seekBtn.type = 'button';
    seekBtn.textContent = '定位到该题';
    seekBtn.onclick = async () => {
      const target = ranges[Number(select.value)];
      if (!target) return;
      try {
        await locateRecording(player, target.startMs);
      } catch (err) {
        status.textContent = err.message;
      }
    };
    navigation.append(label, seekBtn);
    section.append(navigation);
  } catch (error) {
    info.textContent = `读取本地录像失败：${error.message}`;
  }
}

async function openHistory(record) {
  clearPlayback();
  const detail = $('historyDetail');
  detail.replaceChildren();
  detail.hidden = false;
  if (isFailedStartRecord(record)) {
    const heading = document.createElement('h3');
    heading.textContent = '录制启动失败诊断';
    const reason = document.createElement('p');
    reason.textContent = record.record_start_error || record.reason || record.assessment?.reason || '录制未成功启动，请检查设备连接、摄像头与麦克风权限。';
    const status = document.createElement('p');
    status.textContent = '无录像（未生成）。此记录未产生正式成绩，不能恢复语音转写或评分；原始诊断记录保留在本机。';
    detail.append(heading, reason, status);
    return;
  }
  const continuous = (record.segments || []).filter(s => s.kind === 'continuous');
  for (const recording of continuous) {
    await appendWholeRecording(detail, record, recording);
  }
  const h = document.createElement('h3');
  h.textContent = '逐题回答、时间区间与评分详情';
  detail.append(h);
  for (const q of normalizeHistoryQuestions(record)) {
    const div = document.createElement('div');
    div.className = 'history-question';
    const title = document.createElement('strong');
    title.textContent = `第 ${q.ordinal || q.number} 题：${q.question_text || q.content}`;
    const meta = document.createElement('p');
    meta.className = 'muted';
    const scoreStr = typeof q.score === 'number' ? `得分：${q.score} 分` : '待评分';
    meta.textContent = `${scoreStr} · 弹幕时段 ${formatPosition(q.barrage_start_ms || 0)}–${formatPosition(q.barrage_end_ms || q.durationMs || 0)} · 回答转写：${q.skipped_by_anchor ? '主动跳题未答' : q.transcript || '待语音转写'} · 参考答案：${q.reference_answer || q.reference || ''}`;
    div.append(title, meta);
    detail.append(div);
  }
}

async function showHistory() {
  clearPlayback();
  $('historyDetail').hidden = true;
  $('historyDetail').replaceChildren();
  $('historyList').replaceChildren();
  const sessions = await db.allSessions();
  if (!sessions.length) {
    $('historyList').textContent = '暂无考核或练播记录。';
    return;
  }
  for (const record of sessions) {
    const div = document.createElement('div');
    div.className = 'history-item';
    const title = document.createElement('strong');
    title.textContent = `${new Date(record.startedAt || Date.now()).toLocaleString('zh-CN')} · ${record.question_set_snapshot?.title || '默认题集'}`;
    const p = document.createElement('p');
    const st = record.assessment?.status || record.status;
    const noRecording = isFailedStartRecord(record);
    const scoreTxt = typeof record.assessment?.average_raw === 'number'
      ? `综合均分 ${record.assessment.average_raw.toFixed(2)} 分（${record.assessment.passed ? '通过' : '未通过'}）`
      : STATE_LABELS[st] || st;
    p.textContent = `主播：${record.anchor?.display_name_local_only || '未填'} · 状态：${scoreTxt} · 录像：${noRecording ? '无录像（未生成）' : statusLabels[record.recording?.status || record.recordingStatus] || record.recordingStatus || '未知'}`;
    const openBtn = document.createElement('button');
    openBtn.type = 'button';
    openBtn.textContent = noRecording ? '查看失败诊断（无录像）' : '查看详情 / 同步弹幕回放';
    openBtn.onclick = () => run(() => openHistory(record));
    const viewResultBtn = document.createElement('button');
    viewResultBtn.type = 'button';
    viewResultBtn.textContent = noRecording ? '录制未成功，无结果可恢复' : '在结果页打开 / 恢复转写评分';
    viewResultBtn.disabled = noRecording;
    viewResultBtn.title = noRecording ? '该记录没有生成录像，不能恢复语音识别或评分' : '';
    viewResultBtn.onclick = () => {
      if (isFailedStartRecord(record)) return;
      const previousRecord = lastSession;
      try {
        renderResultSummary(record);
        lastSession = record;
        $('historyDialog').close();
        document.body.dataset.page = 'result';
        update();
        if ($('sessionSummary').hidden) throw new Error('历史结果页面未正确显示');
      } catch (error) {
        console.error('[R5] 历史结果恢复失败', error);
        lastSession = previousRecord;
        document.body.dataset.page = 'home';
        update();
        $('historyDialog').close();
        notice(`历史结果打开失败：${error?.message || '数据格式异常'}。已安全返回练播房，原始记录未被删除。`, 'error');
      }
    };
    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.className = 'danger-button';
    delBtn.textContent = '删除此记录';
    delBtn.onclick = () => run(async () => {
      clearPlayback();
      await db.deleteSession(record.id);
      await showHistory();
    });
    div.append(title, p, openBtn, viewResultBtn, delBtn);
    $('historyList').append(div);
  }
}

// Wire up UI event listeners
$('checkInviteButton').onclick = () => {
  const output = $('inviteValidationResult');
  try {
    normalizeInviteCode($('operatorInviteCodeInput').value);
    output.textContent = '邀请信息格式有效，但运营后台尚未接入。尚未验证身份或设备授权，请运营后台上线后完成正式绑定。';
    notice('没有向任何服务提交邀请凭证；本地检查不代表运营审核通过。', 'warning');
  } catch (error) {
    output.textContent = error.message;
    notice(error.message, 'warning');
  }
};

$('enterLocalDemoButton').onclick = () => run(async () => {
  anchorProfile = createLocalExperienceProfile($('localDemoNameInput').value, anchorProfile);
  await persistSettingsAndProfile();
  renderAnchorProfileUI();
  notice('已进入本机体验：可以检查题集、摄像头和录制。不会上传正式成绩，也不会自动调用 Gemini。', 'info');
});

$('exitLocalDemoButton').onclick = () => run(async () => {
  if (session && ['running', 'paused', 'stopping'].includes(session.state)) {
    throw new Error('请先结束或取消当前录制，再退出体验模式');
  }
  anchorProfile = { local_profile_id: uid(), display_name_local_only: '', operator_id: '' };
  await persistSettingsAndProfile();
  renderAnchorProfileUI();
  notice('已退出本机体验模式。此前保存的题目集、练播历史和录像未被删除。', 'info');
});

$('activeQuestionSetSelect').onchange = () => run(async () => {
  activeQuestionSetId = $('activeQuestionSetSelect').value;
  await persistSettingsAndProfile();
  renderQuestionSetsSelector();
});

for (const id of ['openKnowledge', 'navKnowledge', 'bankShortcut', 'questionSetOpenButton']) {
  if ($(id)) $(id).onclick = () => run(() => openQuestionSetManager(getActiveQuestionSet()));
}

$('newBlankSetButton').onclick = () => {
  openQuestionSetManager(null);
};

$('deleteCurrentSetButton').onclick = () => run(async () => {
  if (!currentDraft?.existingId) {
    notice('当前为尚未入库的新草稿，已重置空白草稿', 'info');
    openQuestionSetManager(null);
    return;
  }
  if (questionSets.length <= 1) {
    throw new Error('至少需要保留 1 套题目集');
  }
  await db.remove('question_sets', currentDraft.existingId);
  questionSets = await db.allQuestionSets();
  activeQuestionSetId = questionSets[0]?.id || null;
  await persistSettingsAndProfile();
  renderQuestionSetsSelector();
  openQuestionSetManager(getActiveQuestionSet());
  notice('已删除该套题目集', 'info');
});

$('addDraftQuestionBtn').onclick = () => {
  if (!currentDraft) return;
  currentDraft.title = $('draftSetTitleInput').value.trim() || currentDraft.title;
  currentDraft.items.push({
    id: uid(),
    question_text: '请简述该款 TCL 产品的核心差异化卖点？',
    reference_answer: '请填写标准参考答案要点',
    question_type: 'oral_qa',
    source_locator: '主播手动新增',
    raw_unpaired: false,
    confirmed_pairing: true
  });
  renderDraftEditor();
};

$('confirmSaveSetBtn').onclick = () => run(async () => {
  if (!currentDraft) return;
  const confirmed = await buildConfirmedQuestionSet({
    existingId: currentDraft.existingId,
    existingVersion: currentDraft.existingVersion,
    title: $('draftSetTitleInput').value,
    sourceFileName: currentDraft.sourceFileName,
    items: currentDraft.items
  });
  await db.saveQuestionSet(confirmed);
  questionSets = await db.allQuestionSets();
  activeQuestionSetId = confirmed.id;
  await persistSettingsAndProfile();
  renderQuestionSetsSelector();
  $('knowledgeDialog').close();
  notice(`题目集「${confirmed.title}」已确认入库（可用口头问答 ${confirmed.summary.readyCount} 题，未保存原始文件 Blob）。`, 'info');
});

$('knowledgeFile').onchange = event => {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file) return;
  run(async () => {
    const draft = await parseFileToQuestionDraft(file);
    currentDraft = {
      existingId: null,
      existingVersion: 0,
      title: draft.suggestedTitle,
      sourceFileName: draft.sourceFileName,
      items: draft.items,
      summary: draft.summary
    };
    renderDraftEditor();
    notice(
      `文件「${draft.sourceFileName}」本地解析完成：共提取 ${draft.summary.totalCount} 条（可用口头问答 ${draft.summary.readyCount} 条，待完善 ${draft.summary.incompleteCount} 条，待核对 ${draft.summary.needsReviewCount} 条）。请预览核对后点击「确认保存题目集入库」。`,
      'info'
    );
  }, true);
};

$('startButton').onclick = () => run(start);
$('retryRecordButton').onclick = () => run(start);
$('nextButton').onclick = () => run(() => handleManualAdvance(false), 'next');
$('skipButton').onclick = () => run(() => handleManualAdvance(true), 'next');
$('resumeButton').onclick = () => run(resume, 'resume');
$('pauseButton').onclick = () => run(session?.state === 'running' ? pause : resume, session?.state === 'running' ? 'pause' : 'resume');
$('endButton').onclick = () => openCancelConfirmModal();
$('continuePracticeButton').onclick = () => $('cancelConfirmDialog')?.close();
$('confirmCancelButton').onclick = () => run(confirmMidSessionCancel, 'end');

$('restartTraining').onclick = () => {
  session = null;
  document.body.dataset.page = 'home';
  if (!media.emergency.length) clearNotices();
  update();
};

// R6: historical video cannot be directly passed into default-browser recognition.
$('retryScoringButton').onclick = () => {
  notice('R6 仅支持录制过程中由浏览器实时识别；无法直接将历史视频重新送入手机默认浏览器识别。该记录已安全保留为待转写。', 'warning');
};

$('viewSummary').onclick = () => run(async () => {
  await showHistory();
  $('historyDialog').showModal();
  if (lastSession) await openHistory(lastSession);
});

$('exportSessionButton').onclick = () => {
  const target = lastSession || session?.record;
  if (!target) return;
  download(new Blob([JSON.stringify(target, null, 2)], { type: 'application/json' }), `TCL练播考核记录-${target.id}.json`);
};

$('leaveLiveButton').onclick = () => {
  if (session && ['running', 'paused'].includes(session.state)) {
    openCancelConfirmModal();
    return;
  }
  document.body.dataset.page = 'home';
  update();
};
$('backFromRecordFault').onclick = () => {
  document.body.dataset.page = 'home';
  update();
};
$('recheckRecordDevices').onclick = () => run(async () => {
  try {
    await media.toggleCamera(true, settings.resolution, settings.orientation);
    notice('摄像头重新检测已通过；麦克风将在正式开始录制时由浏览器请求权限。请返回练播房重新开始。', 'info');
  } catch (error) {
    notice(describeMediaError(error), 'error');
  }
});

$('cameraButton').onclick = () => run(async () => {
  try {
    await media.toggleCamera(!media.camera, settings.resolution, settings.orientation);
  } catch (error) {
    await media.toggleCamera(false);
    throw new Error(describeMediaError(error, '摄像头')); 
  }
});

$('homeResolution').onchange = () => run(async () => {
  settings.resolution = Number($('homeResolution').value);
  media.size(settings.resolution, settings.orientation);
  await persistSettingsAndProfile();
});

$('homeOrientation').onchange = () => run(async () => {
  settings.orientation = $('homeOrientation').value;
  media.size(settings.resolution, settings.orientation);
  await persistSettingsAndProfile();
  update();
});

$('audioCheckButton').onclick = () => media.audioInput.resume();

$('referenceButton').onclick = () => run(async () => {
  if (!session || session.record.trainingMode === 'exam') {
    throw new Error('正式考核模式提交前不可查看参考答案');
  }
  if (session.state === 'running') await pause();
  $('analysisQuestion').textContent = session.current?.question_text || '';
  $('analysisProgress').textContent = $('trainingProgress').textContent;
  $('referenceBody').textContent = session.current?.reference_answer || '';
  $('analysisPage').hidden = false;
  document.body.dataset.page = 'analysis';
});

$('backToLive').onclick = () => {
  document.body.dataset.page = 'live';
  $('analysisPage').hidden = true;
  update();
};

$('historyButton').onclick = () => run(async () => {
  await showHistory();
  $('historyDialog').showModal();
});
$('navRecords').onclick = () => $('historyButton').click();
$('navHome').onclick = () => {
  document.body.dataset.page = session && ['running', 'paused'].includes(session.state) ? 'live' : 'home';
  $('analysisPage').hidden = true;
  update();
};

$('settingsButton').onclick = () => run(async () => {
  $('mode').value = settings.trainingMode || 'exam';
  $('mirrorSelect').value = String(settings.mirror !== false);
  const estimate = await db.storageHealth().catch(() => null);
  $('storageInfo').textContent = estimate?.quota
    ? `本地存储已用 ${(estimate.usage / 1048576).toFixed(1)} MB / ${(estimate.quota / 1048576).toFixed(0)} MB`
    : '当前浏览器未提供存储配额估算';
  $('settingsDialog').showModal();
});

$('settingsForm').onsubmit = event => {
  event.preventDefault();
  run(async () => {
    settings.trainingMode = $('mode').value;
    settings.mirror = $('mirrorSelect').value === 'true';
    media.mirror = settings.mirror;
    await persistSettingsAndProfile();
    $('settingsDialog').close();
    update();
    notice('练播设置已保存', 'info');
  });
};

document.querySelectorAll('[data-close]').forEach(b => {
  b.onclick = () => {
    $(b.dataset.close)?.close();
    if (b.dataset.close === 'historyDialog') clearPlayback();
  };
});
$('historyDialog')?.addEventListener('close', clearPlayback);

async function prepareOffline() {
  if (!('serviceWorker' in navigator) || !globalThis.isSecureContext) {
    throw new Error('离线缓存需 HTTPS 或 localhost 环境');
  }
  const registration = swRegistration || await navigator.serviceWorker.register('./sw.js', { scope: './', updateViaCache: 'none' });
  if (registration.waiting && !session) registration.waiting.postMessage('ACTIVATE_UPDATE');
  notice('网页程序静态资源缓存已就绪；R6 不安装离线语音模型，题库和录像保持原样。', 'info');
}
$('offlineButton').onclick = () => run(prepareOffline);
$('refreshAppCache').onclick = () => run(() => appCache.refresh());

// TASK003 P1-A: Automatic bounded pending score recovery on startup, network recovery, and returning to foreground
async function triggerAutoScoreRecovery(triggerSource = 'auto') {
  if (session && ['running', 'paused', 'stopping'].includes(session.state)) return null;
  try {
    const res = await recoverPendingScoringJobs({
      onSessionRecovered(recoveredRecord) {
        if (lastSession && lastSession.id === recoveredRecord.id) {
          lastSession = recoveredRecord;
          renderResultSummary(recoveredRecord);
        }
        notice(
          `待评分任务已自动恢复完成（场次 ${recoveredRecord.id.slice(0, 8)}）：${recoveredRecord.assessment?.passed ? '考核通过' : '考核未通过'}`,
          'info'
        );
      }
    });
    aiCapabilities = await fetchGatewayCapabilities();
    const capBadge = $('aiCapabilityBadge');
    if (capBadge) {
      capBadge.textContent = aiCapabilities.enabled ? 'Free Tier 已就绪' : '待评分模式（无免费Key/未联调）';
      capBadge.dataset.tone = aiCapabilities.enabled ? 'pass' : 'warn';
    }
    if ($('aiCapabilityReason')) {
      $('aiCapabilityReason').textContent = aiCapabilities.reason || '';
    }
    return res;
  } catch {
    return null;
  }
}

window.addEventListener('online', () => {
  void triggerAutoScoreRecovery('network_online');
});

document.addEventListener('visibilitychange', () => {
  if (document.hidden && session?.state === 'running') {
    notice('页面切入后台，已自动暂停录制。返回后请点击继续练播。', 'warning');
    run(pause, 'pause');
  } else if (!document.hidden) {
    void triggerAutoScoreRecovery('visibility_foreground');
  }
});

setInterval(() => {
  update();
  if (!session || session.state !== 'running' || busy || timerBusy) return;
  if (performance.now() - lastCheckpoint > 10000) {
    timerBusy = true;
    lastCheckpoint = performance.now();
    checkpoint().then(ok => { if (!ok) run(pause, 'pause'); }).finally(() => { timerBusy = false; });
  }
}, 250);

async function seedDefaultQuestionSetsIfEmpty() {
  const existing = await db.allQuestionSets();
  if (existing.length > 0) return existing;

  const categories = [
    {
      title: 'TCL MiniLED 电视与全品类综合题集',
      filter: () => true
    },
    {
      title: 'TCL 双系统平嵌冰箱专项题集',
      filter: q => q.product === 'TCL冰箱'
    },
    {
      title: 'TCL 洗烘一体机与新风空调专项题集',
      filter: q => q.product === 'TCL洗衣机' || q.product === 'TCL空调'
    }
  ];

  for (const cat of categories) {
    const items = examples.filter(cat.filter).map(q => ({
      id: uid(),
      question_text: q.question_text,
      reference_answer: q.reference_answer,
      question_type: 'oral_qa',
      source_locator: q.source_locator
    }));
    const confirmed = await buildConfirmedQuestionSet({
      title: cat.title,
      sourceFileName: '内置初始化题集',
      items
    });
    await db.saveQuestionSet(confirmed);
  }
  return await db.allQuestionSets();
}

async function init() {
  try {
    const saved = await db.get('settings', 'config');
    if (saved?.settings) settings = { ...settings, ...saved.settings };
    if (saved?.anchorProfile) {
      // Historical roster-based profiles are NOT silently promoted to verified identities.
      // Their prior session records remain untouched in IndexedDB.
      anchorProfile = isLocalExperienceProfile(saved.anchorProfile)
        ? { ...anchorProfile, ...saved.anchorProfile }
        : { local_profile_id: uid(), display_name_local_only: '', operator_id: '' };
    }
    const suppliedInvite = getInvitationPrefill(location.search);
    if (suppliedInvite && $('operatorInviteCodeInput')) {
      // UI-only prefill. No automatic acceptance or network request.
      $('operatorInviteCodeInput').value = suppliedInvite;
      $('inviteValidationResult').textContent = '检测到邀请链接：仍须运营后台服务端验证。当前未完成绑定。';
    }
    if (saved?.activeQuestionSetId) activeQuestionSetId = saved.activeQuestionSetId;

    if (saved?.bank && Array.isArray(saved.bank) && saved.bank.length) {
      const legacyItems = saved.bank.map((q, idx) => ({
        id: q.id || uid(),
        question_text: q.content || q.question_text || '',
        reference_answer: q.reference || q.reference_answer || '',
        question_type: 'oral_qa',
        source_locator: `V4旧版迁移 #${idx + 1}`,
        confirmed_pairing: true
      })).filter(q => q.question_text);
      if (legacyItems.length) {
        const migratedSet = await buildConfirmedQuestionSet({
          existingId: 'v4-migrated-question-set',
          title: 'V4 升级保留题库',
          sourceFileName: 'live-practice-v1',
          items: legacyItems
        }).catch(() => null);
        if (migratedSet) await db.saveQuestionSet(migratedSet);
      }
    }

    questionSets = await seedDefaultQuestionSetsIfEmpty();
    if (!activeQuestionSetId && questionSets.length) {
      activeQuestionSetId = questionSets[0].id;
    }

    media.mirror = settings.mirror !== false;
    $('homeResolution').value = String(settings.resolution || 720);
    $('homeOrientation').value = settings.orientation || 'portrait';
    media.size(settings.resolution, settings.orientation);

    renderAnchorProfileUI();
    renderQuestionSetsSelector();
    const capability = detectBrowserSpeechSupport();
    if ($('localAsrStatusBadge')) $('localAsrStatusBadge').textContent = capability.supported ? '浏览器接口可用 · 待真机验证' : '浏览器不支持';
    if ($('localAsrTrafficHint')) $('localAsrTrafficHint').textContent = capability.limitationNote;

    const speechSupport = detectBrowserSpeechSupport();
    if ($('browserSpeechPrivacyText')) {
      $('browserSpeechPrivacyText').textContent = `${speechSupport.privacyNotice}（${speechSupport.limitationNote}）同意后才尝试语音识别；不同意仍可录像。`;
    }

    // Auto-recover interrupted sessions if lock is free
    if (navigator.locks) {
      await navigator.locks.request('tcl-v43-preview-r4-recorder', { ifAvailable: true }, async lock => {
        if (!lock) return;
        for (const record of await db.allSessions()) {
          if (record.status === 'active') {
            record.status = 'interrupted';
            record.recordingStatus = record.segments?.length ? 'partial' : 'unavailable';
            (record.segments || []).forEach(s => { if (s.status === 'recording') s.status = 'interrupted'; });
            await db.put('sessions', record);
          }
        }
      });
    }

    await triggerAutoScoreRecovery('startup_init');
  } catch (error) {
    notice(db.storageError(error), 'error');
  }
  update();

  if ('serviceWorker' in navigator && globalThis.isSecureContext) {
    navigator.serviceWorker.register('./sw.js', { scope: './', updateViaCache: 'none' })
      .then(r => { swRegistration = r; })
      .catch(() => {});
  }
}

await init();
