// Only safety controls may wait behind a transition. Never replay a burst of Next clicks.
export class ActionGate {
  constructor({ changed = () => {}, error = () => {}, settled = async () => {} } = {}) {
    this.changed = changed;
    this.error = error;
    this.settled = settled;
    this.active = null;
    this.pending = [];
  }
  get busy() { return !!this.active; }
  get playbackTransition() {
    return [...this.pending].reverse().find(item => ['pause', 'resume'].includes(item.kind))?.kind ||
      (['pause', 'resume'].includes(this.active?.kind) ? this.active.kind : null);
  }
  get ending() {
    return this.active?.kind === 'end' || this.pending.some(item => item.kind === 'end');
  }
  run(kind, action) {
    if (this.ending && kind !== 'deferred') return Promise.resolve({ accepted: false, reason: 'ending' });
    if (this.busy && !['pause', 'resume', 'end', 'deferred'].includes(kind)) {
      return Promise.resolve({ accepted: false, reason: 'busy' });
    }
    const duplicate = this.pending.at(-1);
    if (duplicate?.kind === kind && kind !== 'deferred') return duplicate.promise;
    if (kind === 'end') {
      for (const item of this.pending.filter(item => item.kind !== 'deferred')) {
        item.resolve({ accepted: false, reason: 'superseded-by-end' });
      }
      this.pending = this.pending.filter(item => item.kind === 'deferred');
    }
    let resolve;
    const promise = new Promise(done => { resolve = done; });
    const item = { kind, action, promise, resolve };
    if (this.busy) {
      if (kind === 'end') this.pending.unshift(item);
      else this.pending.push(item);
      this.changed();
    } else {
      this.active = item;
      this.changed();
      void this.drain();
    }
    return promise;
  }
  async drain() {
    while (this.active) {
      const item = this.active;
      let result;
      try {
        await item.action();
        result = { accepted: true };
      } catch (error) {
        this.error(error);
        result = { accepted: true, error };
      } finally {
        try { await this.settled(); } catch (error) { this.error(error); }
      }
      this.active = this.pending.shift() || null;
      this.changed();
      item.resolve(result);
    }
  }
}
