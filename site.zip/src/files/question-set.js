// Question set extraction, validation, duplicate/conflict detection, preview editing, and snapshot hashing.
// Strictly enforces: oral Q&A only for formal exams, no fabricated answers, missing answers marked 'incomplete' (待完善),
// ambiguous blocks marked 'needs_review' (待核对), and zero persistence of raw uploaded Blob or full document text.

import { uid } from '../training/core.js';
import { parseDocumentFile } from './parser.js';

export const QUESTION_STATUS_LABELS = {
  ready: '可用（口头问答）',
  incomplete: '待完善（缺参考答案）',
  needs_review: '待核对（需人工确认配对）',
  unsupported_type: '非口头问答（不参与正式考核）',
  duplicate: '重复题目（需去重）',
  conflict: '答案冲突（同题不同答）',
  unparseable: '无法解析'
};

export const QUESTION_TYPE_LABELS = {
  oral_qa: '口头问答题',
  multiple_choice: '选择题（不考核）',
  true_false: '判断题（不考核）',
  unknown: '不明题型（待处理）'
};

export function normalizeQuestionKey(text) {
  return String(text || '')
    .trim()
    .toLowerCase()
    .replace(/[\s\u3000？?！!。，,、：:；;“”"''（）()【】\[\]]+/g, '');
}

export function detectQuestionType(questionText, referenceAnswer = '', explicitType = '') {
  const combined = `${explicitType} ${questionText} ${referenceAnswer}`;
  if (/选择题|单选题|多选题/.test(explicitType) || /(?:^|\s)[A-D][.、．:：]\s*\S+.*(?:^|\s)[B-D][.、．:：]\s*\S+/s.test(questionText)) {
    return 'multiple_choice';
  }
  if (/判断题|是非题/.test(explicitType) || /(?:请判断对错|判断正误|对不对[？?]?$|是否正确[？?]?$)/.test(questionText) || /^(?:对|错|正确|错误|√|×|TRUE|FALSE)$/i.test(referenceAnswer.trim())) {
    return 'true_false';
  }
  if (!questionText || questionText.trim().length < 2) {
    return 'unknown';
  }
  return 'oral_qa';
}

const Q_PREFIX_RE = /^(?:【?(?:问题|题目|提问|观众提问|问|Q)\d*】?|\d+[.、．)\]]\s*(?:问题|题目|问))[：:\s]\s*(.+)$/i;
const A_PREFIX_RE = /^(?:【?(?:参考答案|标准答案|回答要点|参考|答案|答|A)\d*】?)[：:\s]\s*(.*)$/i;
const TYPE_PREFIX_RE = /^(?:【?(?:题型|类型)】?)[：:\s]\s*(.+)$/i;

const Q_HEADER_NAMES = ['问题', '题目', '提问', '题干', '观众提问', '问', 'question', 'q'];
const A_HEADER_NAMES = ['参考答案', '标准答案', '答案', '参考', '回答要点', '答', 'reference', 'answer', 'a'];
const TYPE_HEADER_NAMES = ['题型', '类型', 'type'];

function extractItemsFromTable(tableBlock) {
  const items = [];
  const rows = tableBlock.rows || [];
  if (!rows.length) return items;

  let qCol = -1, aCol = -1, typeCol = -1;
  let startRowIdx = 0;

  // Inspect first 2 rows for explicit headers
  for (let r = 0; r < Math.min(2, rows.length); r++) {
    const cells = rows[r].cells.map(c => String(c || '').trim().toLowerCase());
    const foundQ = cells.findIndex(c => Q_HEADER_NAMES.some(h => c === h || c.includes(h)));
    const foundA = cells.findIndex((c, idx) => idx !== foundQ && A_HEADER_NAMES.some(h => c === h || c.includes(h)));
    const foundT = cells.findIndex((c, idx) => idx !== foundQ && idx !== foundA && TYPE_HEADER_NAMES.some(h => c === h || c.includes(h)));
    if (foundQ >= 0) {
      qCol = foundQ;
      aCol = foundA;
      typeCol = foundT;
      startRowIdx = r + 1;
      break;
    }
  }

  for (let r = startRowIdx; r < rows.length; r++) {
    const row = rows[r];
    const nonEmpty = row.cells.map((c, idx) => ({ idx, text: String(c || '').trim() })).filter(x => x.text);
    if (!nonEmpty.length) continue;

    if (qCol >= 0) {
      const qText = String(row.cells[qCol] || '').trim();
      const aText = aCol >= 0 ? String(row.cells[aCol] || '').trim() : '';
      const tText = typeCol >= 0 ? String(row.cells[typeCol] || '').trim() : '';
      if (!qText && !aText) continue;
      if (!qText && aText) {
        items.push({
          question_text: '',
          reference_answer: aText,
          explicit_type: tText,
          source_locator: row.locator,
          raw_unpaired: true
        });
      } else {
        items.push({
          question_text: qText,
          reference_answer: aText,
          explicit_type: tText,
          source_locator: row.locator,
          raw_unpaired: false
        });
      }
    } else {
      // No explicit header row: check if cells have explicit prefixes like 问： / 答：
      if (nonEmpty.length === 2 && (Q_PREFIX_RE.test(nonEmpty[0].text) || A_PREFIX_RE.test(nonEmpty[1].text))) {
        const qm = nonEmpty[0].text.match(Q_PREFIX_RE);
        const am = nonEmpty[1].text.match(A_PREFIX_RE);
        items.push({
          question_text: qm ? qm[1].trim() : nonEmpty[0].text,
          reference_answer: am ? am[1].trim() : nonEmpty[1].text,
          explicit_type: '',
          source_locator: row.locator,
          raw_unpaired: false
        });
      } else {
        // Complex or headerless table row cannot be high-confidence paired -> mark needs_review, never invent answer
        items.push({
          question_text: nonEmpty[0].text,
          reference_answer: nonEmpty.slice(1).map(x => x.text).join(' | '),
          explicit_type: '',
          source_locator: row.locator,
          raw_unpaired: true
        });
      }
    }
  }
  return items;
}

function extractItemsFromParagraphs(paraBlocks) {
  const items = [];
  let pendingQ = null;
  let pendingType = '';

  const flushPending = () => {
    if (!pendingQ) return;
    items.push({
      question_text: pendingQ.text,
      reference_answer: pendingQ.answer || '',
      explicit_type: pendingQ.explicitType || '',
      source_locator: pendingQ.locator,
      raw_unpaired: false
    });
    pendingQ = null;
  };

  for (const b of paraBlocks) {
    const lines = String(b.text || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    for (const line of lines) {
      const tm = line.match(TYPE_PREFIX_RE);
      if (tm) {
        pendingType = tm[1].trim();
        continue;
      }
      // Inline "问题：... 答：..." on the same line
      const inlineMatch = line.match(/^(?:【?(?:问题|题目|提问|问|Q)\d*】?)[：:\s]\s*(.+?)\s+(?:【?(?:参考答案|标准答案|参考|答案|答|A)\d*】?)[：:\s]\s*(.*)$/i);
      if (inlineMatch) {
        flushPending();
        items.push({
          question_text: inlineMatch[1].trim(),
          reference_answer: inlineMatch[2].trim(),
          explicit_type: pendingType,
          source_locator: b.locator,
          raw_unpaired: false
        });
        pendingType = '';
        continue;
      }

      const qm = line.match(Q_PREFIX_RE);
      if (qm) {
        flushPending();
        pendingQ = {
          text: qm[1].trim(),
          answer: '',
          explicitType: pendingType,
          locator: b.locator,
          hasExplicitAnswerTag: false
        };
        pendingType = '';
        continue;
      }

      const am = line.match(A_PREFIX_RE);
      if (am) {
        if (pendingQ) {
          pendingQ.answer = pendingQ.answer ? `${pendingQ.answer}\n${am[1].trim()}` : am[1].trim();
          pendingQ.hasExplicitAnswerTag = true;
        } else {
          items.push({
            question_text: '',
            reference_answer: am[1].trim(),
            explicit_type: pendingType,
            source_locator: b.locator,
            raw_unpaired: true
          });
        }
        continue;
      }

      // Check pipe format from legacy TXT: "观众昵称 | 问题 | 参考答案"
      if (line.includes('|') && !pendingQ) {
        const parts = line.split('|').map(s => s.trim());
        if (parts.length >= 3) {
          items.push({
            question_text: parts[1],
            reference_answer: parts.slice(2).join(' | '),
            explicit_type: '',
            source_locator: b.locator,
            raw_unpaired: false
          });
          continue;
        } else if (parts.length === 2) {
          items.push({
            question_text: parts[1],
            reference_answer: '',
            explicit_type: '',
            source_locator: b.locator,
            raw_unpaired: false
          });
          continue;
        }
      }

      // Continuation of an active answer block vs unpaired paragraph
      if (pendingQ && pendingQ.hasExplicitAnswerTag) {
        pendingQ.answer = `${pendingQ.answer}\n${line}`.trim();
      } else {
        flushPending();
        items.push({
          question_text: line,
          reference_answer: '',
          explicit_type: pendingType,
          source_locator: b.locator,
          raw_unpaired: true
        });
        pendingType = '';
      }
    }
  }
  flushPending();
  return items;
}

export function evaluateAndClassifyItems(rawItems) {
  const seenMap = new Map();
  const evaluated = [];
  const warnings = [];

  for (let i = 0; i < rawItems.length; i++) {
    const raw = rawItems[i];
    const id = raw.id || uid();
    const qText = String(raw.question_text ?? raw.question ?? raw.content ?? '').trim();
    const rAnswer = String(raw.reference_answer ?? raw.reference ?? '').trim();
    const locator = String(raw.source_locator || `条目 #${i + 1}`);
    const qType = raw.question_type || detectQuestionType(qText, rAnswer, raw.explicit_type || '');

    let status = 'ready';
    let statusReason = '显式问答配对完整，可参与正式抽题';

    if (!qText || qText.length > 500 || rAnswer.length > 10000) {
      status = 'unparseable';
      statusReason = !qText ? '缺少题干内容，无法作为有效题目' : '题干（≤500字）或参考答案（≤10000字）超长';
    } else if (qType !== 'oral_qa') {
      status = 'unsupported_type';
      statusReason = `检测到${QUESTION_TYPE_LABELS[qType] || '非口头问答题'}，正式考核仅允许口头问答题`;
    } else if (raw.raw_unpaired && !raw.confirmed_pairing) {
      status = 'needs_review';
      statusReason = '未检测到显式「问/答」标签或标准表头，请人工核对题干与参考答案（禁止系统臆造答案）';
    } else if (!rAnswer) {
      status = 'incomplete';
      statusReason = '缺少参考答案，已标记为「待完善」，补齐参考答案前不会在考核中抽到';
    }

    const normKey = qText ? normalizeQuestionKey(qText) : '';
    if (normKey && !['unparseable'].includes(status)) {
      if (seenMap.has(normKey)) {
        const first = seenMap.get(normKey);
        if (first.reference_answer === rAnswer) {
          status = 'duplicate';
          statusReason = `与第 ${first.index + 1} 条题目重复`;
          warnings.push(`发现重复题目：「${qText.slice(0, 36)}」`);
        } else {
          status = 'conflict';
          statusReason = `与第 ${first.index + 1} 条同名题目存在不同参考答案，请人工消歧`;
          first.item.status = 'conflict';
          first.item.status_reason = `与第 ${i + 1} 条同名题目参考答案不一致，请人工修正`;
          warnings.push(`同一问题存在冲突参考答案：「${qText.slice(0, 36)}」`);
        }
      } else {
        seenMap.set(normKey, { index: i, reference_answer: rAnswer, item: null });
      }
    }

    const entry = {
      id,
      order: i + 1,
      question_text: qText,
      reference_answer: rAnswer,
      question_type: qType,
      status,
      status_reason: statusReason,
      source_locator: locator,
      raw_unpaired: Boolean(raw.raw_unpaired && !raw.confirmed_pairing),
      confirmed_pairing: Boolean(raw.confirmed_pairing)
    };
    if (normKey && seenMap.get(normKey)?.index === i) {
      seenMap.get(normKey).item = entry;
    }
    evaluated.push(entry);
  }

  const summary = {
    totalCount: evaluated.length,
    readyCount: evaluated.filter(x => x.status === 'ready').length,
    incompleteCount: evaluated.filter(x => x.status === 'incomplete').length,
    needsReviewCount: evaluated.filter(x => x.status === 'needs_review').length,
    unsupportedTypeCount: evaluated.filter(x => x.status === 'unsupported_type').length,
    duplicateCount: evaluated.filter(x => x.status === 'duplicate').length,
    conflictCount: evaluated.filter(x => x.status === 'conflict').length,
    unparseableCount: evaluated.filter(x => x.status === 'unparseable').length,
    warnings
  };

  return { items: evaluated, summary };
}

export async function parseFileToQuestionDraft(inputFile) {
  const parsed = await parseDocumentFile(inputFile);
  const rawItems = [];

  if (parsed.format === 'json') {
    const data = parsed.jsonData;
    const qs = Array.isArray(data?.questions) ? data.questions : Array.isArray(data) ? data : [];
    qs.forEach((q, idx) => {
      rawItems.push({
        question_text: String(q?.question ?? q?.question_text ?? q?.content ?? '').trim(),
        reference_answer: String(q?.reference ?? q?.reference_answer ?? '').trim(),
        explicit_type: String(q?.type ?? q?.question_type ?? ''),
        source_locator: `${parsed.fileName} · JSON 条目 #${idx + 1}`,
        raw_unpaired: false
      });
    });
  } else {
    const paraQueue = [];
    const flushParas = () => {
      if (!paraQueue.length) return;
      rawItems.push(...extractItemsFromParagraphs(paraQueue));
      paraQueue.length = 0;
    };
    for (const block of parsed.blocks) {
      if (block.kind === 'table') {
        flushParas();
        rawItems.push(...extractItemsFromTable(block));
      } else {
        paraQueue.push(block);
      }
    }
    flushParas();
  }

  if (rawItems.length > 500) {
    throw new Error(`单次文件解析提取到 ${rawItems.length} 条记录，超过单集 500 条上限，请按品类拆分文件`);
  }

  const { items, summary } = evaluateAndClassifyItems(rawItems);
  const suggestedTitle = parsed.fileName.replace(/\.[^.]+$/, '').slice(0, 60) || '新建题目集';

  return {
    draftId: uid(),
    suggestedTitle,
    sourceFileName: parsed.fileName,
    sourceFormat: parsed.format,
    extractedAt: new Date().toISOString(),
    items,
    summary
  };
}

export async function computeSnapshotHash(questions) {
  const canonical = JSON.stringify(
    questions.map(q => ({
      id: q.id,
      question_text: q.question_text,
      reference_answer: q.reference_answer,
      question_type: q.question_type,
      status: q.status
    }))
  );
  const bytes = new TextEncoder().encode(canonical);
  if (globalThis.crypto?.subtle?.digest) {
    const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
  }
  // Fallback FNV-1a 64-bit hex for runtimes without subtle crypto
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < bytes.length; i++) {
    h1 = Math.imul(h1 ^ bytes[i], 2654435761);
    h2 = Math.imul(h2 ^ bytes[i], 1597334677);
  }
  return (h1 >>> 0).toString(16).padStart(8, '0') + (h2 >>> 0).toString(16).padStart(8, '0');
}

export async function buildConfirmedQuestionSet({ existingId = null, existingVersion = 0, title, sourceFileName, items }) {
  const cleanTitle = String(title || '').trim().slice(0, 80);
  if (!cleanTitle) throw new Error('请填写题目集名称（如：TCL MiniLED 电视题集）');
  const { items: classified, summary } = evaluateAndClassifyItems(items);
  if (summary.conflictCount > 0) {
    throw new Error(`当前题集存在 ${summary.conflictCount} 处同名题目答案冲突，请先在预览列表中修正或删除冲突项后再确认入库`);
  }
  if (summary.duplicateCount > 0) {
    throw new Error(`当前题集存在 ${summary.duplicateCount} 处重复题目，请先删除重复项后再确认入库`);
  }
  if (classified.length === 0) {
    throw new Error('题目集不能为空，请至少保留 1 条题目记录');
  }
  const version = existingVersion + 1;
  const hash = await computeSnapshotHash(classified);
  const nowIso = new Date().toISOString();

  // Strictly persist ONLY curated questions and answers; never store raw File/Blob or full document text.
  return {
    id: existingId || uid(),
    title: cleanTitle,
    sourceFileName: String(sourceFileName || '手动维护'),
    version,
    hash,
    createdAt: nowIso,
    updatedAt: nowIso,
    summary,
    questions: classified.map(q => ({
      id: q.id,
      question_text: q.question_text,
      reference_answer: q.reference_answer,
      question_type: q.question_type,
      status: q.status,
      status_reason: q.status_reason,
      source_locator: q.source_locator
    }))
  };
}
