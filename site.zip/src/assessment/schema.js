// Strict JSON Schema validation and business contract enforcement for V4.3 AI Semantic Scoring
// and future Operations Backend (tcl-ops-v4.3) synchronization.
// TASK002 P1-02, TASK004 & TASK005 P1-01 Fix:
// - Enforces that formal scoring requests ONLY accept trusted ASR transcripts
//   ('sherpa-onnx-local', 'browser', or 'gemini-fallback') and strictly rejects manual text input substitutions.
// - Rejects any simulated/test ASR provider ('pipeline-verify', 'sandbox-pipeline-verify-int8',
//   'sherpa-wasm-worker-acoustic', 'mock', 'simulated').
// - Requires 'sherpa-onnx-local' questions to carry a valid production `asr_model_version`
//   (`paraformer-zh-small-int8@...` or `sense-voice-zh-small-int8@...`), a 64-char hex `source_audio_hash`,
//   and `engine_mode === 'sherpa-wasm-native'` (when present).
// - Note on Production Trust Boundary (TASK005 P1-01): Browser client payloads are untrusted; in production,
//   the backend/gateway must independently verify audio hashes and ASR provenance rather than trusting client strings alone.

export const SCORING_POLICY_VERSION = 'semantic-answer-v1';
export const PASSING_THRESHOLD = 80;
export const ALLOWED_ASR_PROVIDERS = new Set([
  'sherpa-onnx-local',
  'browser',
  'gemini-fallback'
]);

export const FORBIDDEN_SIMULATED_PATTERNS = /pipeline-verify|worker-acoustic|acoustic-sim|mock|simulated|fake/i;
export const VALID_PRODUCTION_LOCAL_ASR_VERSION_RE = /^(paraformer-zh-small-int8|sense-voice-zh-small-int8)@[0-9A-Za-z._-]+$/;

// Validate outgoing scoring request payload to guarantee zero privacy leakage and authentic ASR provenance (P1-02, A19, TASK005 P1-01)
export function validateScoringRequestPayload(payload) {
  const errors = [];
  if (!payload || typeof payload !== 'object') {
    return { valid: false, errors: ['请求体必须为 JSON 对象'] };
  }
  const rawJson = JSON.stringify(payload);
  if (payload.display_name_local_only || payload.anchor_name || payload.anchor?.display_name_local_only) {
    errors.push('隐私安全违规：严禁向免费 Gemini 接口发送主播真实姓名 (display_name_local_only)');
  }
  if (payload.video_base64 || payload.video_blob || /"video\/(?:mp4|webm)"/i.test(rawJson)) {
    errors.push('隐私与成本违规：严禁向评分接口上传原始视频数据');
  }
  if (!payload.session_id || typeof payload.session_id !== 'string') {
    errors.push('缺少合法的 session_id');
  }
  if (!payload.snapshot_hash || typeof payload.snapshot_hash !== 'string') {
    errors.push('缺少题库快照哈希 snapshot_hash');
  }
  if (!Array.isArray(payload.questions) || payload.questions.length < 1 || payload.questions.length > 5) {
    errors.push('questions 数组必须包含 1～5 道实际考核题目');
  } else {
    const seenIds = new Set();
    for (const q of payload.questions) {
      if (!q?.question_id || typeof q.question_id !== 'string') {
        errors.push('存在缺少 question_id 的题目');
      } else if (seenIds.has(q.question_id)) {
        errors.push(`请求中存在重复的 question_id: ${q.question_id}`);
      } else {
        seenIds.add(q.question_id);
      }
      if (!q?.question_text || typeof q.question_text !== 'string') {
        errors.push(`题目 ${q?.question_id || ''} 缺少题干 question_text`);
      }
      if (!q?.reference_answer || typeof q.reference_answer !== 'string') {
        errors.push(`题目 ${q?.question_id || ''} 缺少参考答案 reference_answer`);
      }
      if (!q?.skipped_by_anchor) {
        if (
          q?.transcription_status === 'technical_fault' ||
          q?.transcription_status === 'pending' ||
          q?.transcription_status === 'transcription_pending'
        ) {
          errors.push(`题目 ${q?.question_id || ''} 存在麦克风/ASR技术故障或待转写，禁止直接提交猜测 0 分`);
        }
        // TASK002 P1-02, TASK004 A19 & TASK005 P1-01: Verify transcript comes from a trusted, non-simulated ASR provider
        const provider = q?.transcription_provider || 'browser';
        if (!ALLOWED_ASR_PROVIDERS.has(provider) || FORBIDDEN_SIMULATED_PATTERNS.test(provider)) {
          errors.push(`题目 ${q?.question_id || ''} 转写来源非法或为模拟组件（${provider}）：正式考核严禁用模拟引擎或手工输入替代真实语音识别结果`);
        }
        if (q?.manual_override || q?.manual_input) {
          errors.push(`题目 ${q?.question_id || ''} 检测到手工覆盖标识，拒绝进入正式 AI 评分`);
        }
        if (q?.engine_mode && q.engine_mode !== 'sherpa-wasm-native') {
          errors.push(`题目 ${q?.question_id || ''} 识别引擎模式非原生 sherpa-wasm-native（实际：${q.engine_mode}），拒绝进入正式评分`);
        }
        if (provider === 'sherpa-onnx-local') {
          const modelVer = String(q?.asr_model_version || '');
          if (!VALID_PRODUCTION_LOCAL_ASR_VERSION_RE.test(modelVer) || FORBIDDEN_SIMULATED_PATTERNS.test(modelVer)) {
            errors.push(
              `题目 ${q?.question_id || ''} 声明为 sherpa-onnx-local，但缺少合法的正式生产模型版本标识（实际：${modelVer || '无'}），拒绝接收 pipeline-verify 或模拟组件输出`
            );
          }
          const audioHash = String(q?.source_audio_hash || '');
          if (!/^[a-f0-9]{64}$/i.test(audioHash)) {
            errors.push(`题目 ${q?.question_id || ''} 声明为 sherpa-onnx-local，但缺少 64 位 SHA-256 源音频摘要 source_audio_hash`);
          }
        }
      }
    }
  }
  return { valid: errors.length === 0, errors };
}

// Strict schema & semantic contract validation of AI scoring response
// Any schema violation MUST result in status: 'scoring_retry_required', never pass or fail!
export function validateAndComputeAssessment(expectedRequest, modelResponse, { vetoOnCriticalFalseClaim = true } = {}) {
  const errors = [];
  if (!modelResponse || typeof modelResponse !== 'object') {
    return {
      valid: false,
      status: 'scoring_retry_required',
      passed: null,
      average_raw: null,
      average_display: null,
      errors: ['模型返回结果不是合法的 JSON 对象']
    };
  }

  if (modelResponse.session_id !== expectedRequest.session_id) {
    errors.push(`session_id 不匹配：期望 ${expectedRequest.session_id}，实际 ${modelResponse.session_id}`);
  }
  if (modelResponse.snapshot_hash !== expectedRequest.snapshot_hash) {
    errors.push(`题库版本 snapshot_hash 不一致：期望 ${expectedRequest.snapshot_hash}，实际 ${modelResponse.snapshot_hash}`);
  }
  if (!modelResponse.model_id || typeof modelResponse.model_id !== 'string') {
    errors.push('缺少模型标识 model_id');
  }
  if (!modelResponse.policy_version || typeof modelResponse.policy_version !== 'string') {
    errors.push('缺少评分策略版本 policy_version');
  }
  if (!modelResponse.generated_at || Number.isNaN(Date.parse(modelResponse.generated_at))) {
    errors.push('缺少合法的评估时间戳 generated_at');
  }

  const results = modelResponse.question_results;
  const expectedQuestions = expectedRequest.questions || [];
  if (!Array.isArray(results)) {
    errors.push('question_results 必须是数组');
  } else {
    if (results.length !== expectedQuestions.length) {
      errors.push(`返回题目数量（${results.length}）与实际考试题数（${expectedQuestions.length}）不一致`);
    }

    const expectedMap = new Map(expectedQuestions.map(q => [q.question_id, q]));
    const returnedIds = new Set();

    for (const r of results) {
      if (!r || typeof r !== 'object') {
        errors.push('question_results 包含非对象元素');
        continue;
      }
      const qid = r.question_id;
      if (!qid || !expectedMap.has(qid)) {
        errors.push(`返回了未知或额外的 question_id: ${qid}`);
        continue;
      }
      if (returnedIds.has(qid)) {
        errors.push(`返回了重复的 question_id: ${qid}`);
        continue;
      }
      returnedIds.add(qid);

      const expQ = expectedMap.get(qid);
      if (!Number.isInteger(r.score) || r.score < 0 || r.score > 100) {
        errors.push(`题目 ${qid} 的分数必须是 0～100 的整数，实际为 ${r.score}`);
      }
      if (expQ.skipped_by_anchor) {
        if (r.score !== 0) {
          errors.push(`题目 ${qid} 为主播主动跳题未作答，分数必须为 0，实际为 ${r.score}`);
        }
      } else {
        if (!String(expQ.transcript || '').trim()) {
          errors.push(`题目 ${qid} 无转写文本且非主动跳题，禁止无依据判分`);
        }
        if (typeof r.analysis !== 'string' || !r.analysis.trim()) {
          errors.push(`题目 ${qid} 缺少关键语义判断依据与错误分析 analysis`);
        }
        if (!Array.isArray(r.semantic_matches)) {
          errors.push(`题目 ${qid} 缺少已覆盖知识点数组 semantic_matches`);
        }
        if (!Array.isArray(r.missing_or_incorrect)) {
          errors.push(`题目 ${qid} 缺少缺失/错误知识点数组 missing_or_incorrect`);
        }
        if (typeof r.critical_false_claim !== 'boolean') {
          errors.push(`题目 ${qid} 缺少重大产品事实错误标识 critical_false_claim (boolean)`);
        }
        if (r.critical_false_claim && (!r.critical_false_claim_reason || !String(r.critical_false_claim_reason).trim())) {
          errors.push(`题目 ${qid} 标记了重大产品事实错误，但缺少触发依据 critical_false_claim_reason`);
        }
      }
    }

    for (const expQ of expectedQuestions) {
      if (!returnedIds.has(expQ.question_id)) {
        errors.push(`缺失题目评分结果：${expQ.question_id}`);
      }
    }
  }

  if (errors.length > 0) {
    return {
      valid: false,
      status: 'scoring_retry_required',
      passed: null,
      average_raw: null,
      average_display: null,
      errors
    };
  }

  const resultMap = new Map(results.map(r => [r.question_id, r]));
  const orderedResults = expectedQuestions.map(q => resultMap.get(q.question_id));

  // Equal-weight arithmetic mean without pre-rounding!
  const totalScore = orderedResults.reduce((sum, r) => sum + r.score, 0);
  const averageRaw = totalScore / orderedResults.length;
  const averageDisplay = averageRaw < PASSING_THRESHOLD ? Math.floor(averageRaw) : Math.round(averageRaw);

  const criticalViolations = orderedResults.filter(r => r.critical_false_claim === true);
  const hasCriticalViolation = criticalViolations.length > 0;

  let passed = averageRaw >= PASSING_THRESHOLD;
  let vetoReason = null;
  if (hasCriticalViolation && vetoOnCriticalFalseClaim) {
    passed = false;
    vetoReason = `检测到严重虚构或误导 TCL 产品参数/功能（${criticalViolations.map(v => v.critical_false_claim_reason).join('；')}），触发考核一票否决规则`;
  }

  return {
    valid: true,
    status: passed ? 'pass' : 'fail',
    passed,
    average_raw: Number(averageRaw.toFixed(4)),
    average_display: averageDisplay,
    has_critical_false_claim: hasCriticalViolation,
    veto_reason: vetoReason,
    policy_version: modelResponse.policy_version || SCORING_POLICY_VERSION,
    model_id: modelResponse.model_id,
    scored_at: modelResponse.generated_at,
    question_results: orderedResults,
    errors: []
  };
}

export function validateOperatorContractRecord(sessionRecord) {
  const errors = [];
  if (!sessionRecord || typeof sessionRecord !== 'object') {
    return { valid: false, errors: ['记录为空'] };
  }
  const requiredTop = ['schema_version', 'session_id', 'anchor', 'question_set_snapshot', 'questions', 'assessment', 'recording', 'barrage_timeline'];
  for (const key of requiredTop) {
    if (!(key in sessionRecord)) errors.push(`缺少顶层字段 ${key}`);
  }
  if (!sessionRecord.anchor?.operator_id) {
    errors.push('缺少直属运营归属标识 anchor.operator_id');
  }
  if (!sessionRecord.question_set_snapshot?.id || !sessionRecord.question_set_snapshot?.hash) {
    errors.push('缺少题库快照版本标识 question_set_snapshot.id / hash');
  }
  if (sessionRecord.recording?.contains_barrage !== false) {
    errors.push('recording.contains_barrage 必须为 false（录像原片严禁烧录弹幕）');
  }
  if (!Array.isArray(sessionRecord.barrage_timeline)) {
    errors.push('barrage_timeline 必须为数组');
  }
  return { valid: errors.length === 0, errors };
}
