import { AudioInputMonitor, audioInputText } from './audio-input.js';
import { uid } from '../training/core.js';
import { put, segmentBlob, saveQuestionAudioSlice, getQuestionAudioSliceFromDB } from '../storage/storage.js';
import { RecordingTimeline, inspectMedia, captureTail, checkMediaTimeline } from './recording.js';

export function containFrame(sourceWidth, sourceHeight, width, height, left = 0, top = 0) {
  if (![sourceWidth, sourceHeight, width, height].every(n => Number.isFinite(n) && n > 0)) return null;
  const scale = Math.min(width / sourceWidth, height / sourceHeight);
  return {
    x: left + (width - sourceWidth * scale) / 2,
    y: top + (height - sourceHeight * scale) / 2,
    width: sourceWidth * scale,
    height: sourceHeight * scale
  };
}

export function recordingTypes(hasVideo, hasAudio) {
  if (!hasVideo) return ['audio/mp4;codecs=mp4a.40.2', 'audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'];
  if (hasAudio) {
    return [
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/mp4;codecs=avc1.4d002a,mp4a.40.2',
      'video/mp4;codecs=avc1,mp4a.40.2',
      'video/webm;codecs=vp8,opus',
      'video/webm',
      'video/mp4'
    ];
  }
  return ['video/mp4;codecs=avc1.42E01E', 'video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp8', 'video/webm'];
}

export function microphoneFailure(error) {
  const reasons = {
    NotAllowedError: '麦克风权限未获允许，请在浏览器和系统设置中开启麦克风权限',
    NotFoundError: '未找到可用麦克风，请连接音频输入设备',
    NotReadableError: '麦克风暂时无法读取，请检查是否被其他应用占用'
  };
  return `${reasons[error?.name] || '麦克风未能开启'}（${error?.name || 'UnknownError'}）`;
}

export async function acquireCameraWithFallback(mediaDevices, targetResolution = 720, orientation = 'portrait') {
  if (!mediaDevices?.getUserMedia) {
    throw new Error('此环境无法使用摄像头，请使用 HTTPS 或本机 localhost 打开');
  }
  // R3: Restore the production V4 native-camera negotiation. Forcing a portrait
  // 720x1280 or 1080x1920 constraint can trigger digital crop-and-scale on phones.
  // Keep the camera's natural sensor framing. The canvas may letterbox it but never crop it.
  const candidates = [
    { label: 'V4原生前置视野', constraints: { video: { facingMode: 'user' }, audio: false } },
    { label: '默认摄像头原生视野（兼容降级）', constraints: { video: true, audio: false } }
  ];

  let lastError = null;
  for (const candidate of candidates) {
    try {
      const stream = await mediaDevices.getUserMedia(candidate.constraints);
      const track = stream.getVideoTracks()[0];
      const settings = track?.getSettings?.() || {};
      return {
        stream,
        negotiatedProfile: candidate.label,
        degraded: candidate !== candidates[0],
        settings: {
          width: settings.width || null,
          height: settings.height || null,
          frameRate: settings.frameRate || null
        }
      };
    } catch (err) {
      lastError = err;
      if (err?.name === 'NotAllowedError' || err?.name === 'SecurityError') {
        throw err;
      }
    }
  }
  throw lastError || new Error('无法开启摄像头');
}

export class MediaEngine {
  constructor(canvas, video, notify, fault, resources = { put, segmentBlob, inspectMedia, saveQuestionAudioSlice, getQuestionAudioSliceFromDB }) {
    this.canvas = canvas;
    this.video = video;
    this.notify = (text, level = 'warning') => notify(text, level);
    this.fault = fault;
    this.camera = null;
    this.mic = null;
    this.stream = null;
    this.recorder = null;
    this.segment = null;
    this.writeQueue = Promise.resolve();
    this.sliceWriteQueue = Promise.resolve();
    this.emergency = [];
    this.provider = () => null;
    this.frame = 0;
    this.lastDraw = 0;
    this.recordingMode = 'none';
    this.mirror = true;
    this.resources = { put, segmentBlob, inspectMedia, saveQuestionAudioSlice, getQuestionAudioSliceFromDB, ...resources };
    this.pendingEncoders = new Set();
    this.audioInput = new AudioInputMonitor();
    this.questionAudioRecorder = null;
    this.questionAudioSlices = new Map();
    this.slicePersistErrors = new Map();
    this.canvasTextDrawCount = 0;
    this.canvasDrawsCameraOnly = true;
    this.negotiatedCameraInfo = null;
  }

  async toggleCamera(on, resolution = 720, orientation = 'portrait') {
    const request = this.cameraRequest = (this.cameraRequest || 0) + 1;
    if (!on) {
      const previous = this.camera;
      this.camera = null;
      this.negotiatedCameraInfo = null;
      this.video?.pause?.();
      if (this.video) this.video.srcObject = null;
      previous?.getTracks().forEach(t => t.stop());
      return;
    }
    if (this.camera?.getVideoTracks().some(t => t.readyState === 'live')) return;
    const acquired = await acquireCameraWithFallback(navigator.mediaDevices, resolution, orientation);
    const { stream, negotiatedProfile, degraded, settings } = acquired;
    if (request !== this.cameraRequest) {
      stream.getTracks().forEach(t => t.stop());
      return;
    }
    const previous = this.camera;
    this.camera = stream;
    this.negotiatedCameraInfo = { negotiatedProfile, degraded, ...settings };
    if (this.video) {
      this.video.muted = true;
      this.video.defaultMuted = true;
      this.video.playsInline = true;
      this.video.disablePictureInPicture = true;
      this.video.setAttribute?.('webkit-playsinline', '');
      this.video.srcObject = stream;
    }
    previous?.getTracks().forEach(t => t.stop());
    stream.getTracks().forEach(t => t.addEventListener('ended', () => {
      if (this.camera === stream) {
        this.camera = null;
        if (this.video) this.video.srcObject = null;
        this.notify('摄像头连接已中断', 'error');
        this.fault('摄像头连接中断');
      }
    }));
    try {
      await this.video?.play?.();
    } catch (error) {
      if (request !== this.cameraRequest) return;
      this.camera = null;
      if (this.video) this.video.srcObject = null;
      stream.getTracks().forEach(t => t.stop());
      throw error;
    }
    if (request !== this.cameraRequest) return;
    const resInfo = settings.width && settings.height
      ? `${settings.width}×${settings.height}${settings.frameRate ? `@${Math.round(settings.frameRate)}fps` : ''}`
      : negotiatedProfile;
    this.notify(
      `摄像头已就绪（${resInfo}${degraded ? ' · 已按设备能力自动降级' : ''}）。录像仅采集画面与麦克风，弹幕通过独立 DOM 层叠加。`,
      'info'
    );
  }

  render(provider) {
    this.provider = provider;
    if (this.frame || typeof requestAnimationFrame !== 'function') return;
    const draw = time => {
      this.frame = requestAnimationFrame(draw);
      if (time - this.lastDraw < 33) return;
      this.lastDraw = time;
      this.draw();
    };
    this.frame = requestAnimationFrame(draw);
  }

  size(resolution = 720, orientation = 'portrait') {
    if (!this.canvas) return;
    const shortSide = Number(resolution) >= 1080 ? 1080 : 720;
    const longSide = Math.round(shortSide * 16 / 9);
    this.canvas.width = orientation === 'portrait' ? shortSide : longSide;
    this.canvas.height = orientation === 'portrait' ? longSide : shortSide;
  }

  draw() {
    if (!this.canvas) return;
    const c = this.canvas;
    const x = c.getContext('2d', { alpha: false });
    if (!x) return;
    const w = c.width, h = c.height;
    x.fillStyle = '#000000';
    x.fillRect(0, 0, w, h);

    if (this.camera && this.video && this.video.readyState >= 2) {
      const v = this.video;
      const box = containFrame(v.videoWidth || w, v.videoHeight || h, w, h, 0, 0);
      if (box) {
        x.save();
        try {
          if (this.mirror) {
            x.translate(w, 0);
            x.scale(-1, 1);
          }
          x.drawImage(v, box.x, box.y, box.width, box.height);
        } finally {
          x.restore();
        }
      }
    }
  }

  async prepare(session, resolution = 720, orientation = 'portrait') {
    if (this.pendingEncoders.size) {
      throw new Error('上一场编码器尚未确认停止或写入结束，请稍候重试');
    }
    if (this.emergency.length) {
      throw new Error('请先下载未保存的应急录像，再开始新一场练播');
    }
    if (this.recorder && this.recorder.state !== 'inactive') {
      throw new Error('请先结束当前录像，再开始新一场练播');
    }
    this.releaseRecording();
    this.session = session;
    this.emergency = [];
    this.writeQueue = Promise.resolve();
    this.sliceWriteQueue = Promise.resolve();
    this.storageFailed = false;
    this.failed = false;
    this.recording = null;
    this.finishing = null;
    this.timeline = new RecordingTimeline();
    this.stopping = false;
    this.questionAudioSlices.clear();
    this.slicePersistErrors.clear();
    this.size(resolution, orientation);

    if (!this.camera || !this.camera.getVideoTracks().some(t => t.readyState === 'live')) {
      await this.toggleCamera(true, resolution, orientation);
    }
    this.draw();

    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error('当前环境不支持麦克风采集，请使用 HTTPS 或 localhost 访问');
    }
    try {
      this.mic = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
        video: false
      });
      const audioTracks = this.mic.getAudioTracks().filter(t => t.readyState === 'live' && t.enabled !== false);
      if (!audioTracks.length) {
        throw new Error('未检测到活动的麦克风音轨');
      }
      const microphone = this.mic;
      await this.audioInput.start(microphone);
      microphone.getTracks().forEach(t => t.addEventListener('ended', () => {
        if (this.mic === microphone) this.fault('麦克风连接中断，已暂停练播');
      }));
    } catch (error) {
      this.releaseRecording();
      throw new Error(`录制准备失败：${microphoneFailure(error)}（正式考核要求摄像头+麦克风同时可用，可点击「重试录制」）`);
    }

    if (typeof MediaRecorder === 'undefined') {
      this.releaseRecording();
      throw new Error('当前浏览器不支持 MediaRecorder 视频录制，请使用 Safari (iOS 14.5+)、Chrome 或 Edge 浏览器');
    }

    try {
      if (!this.canvas.captureStream) throw new Error('captureStream unavailable');
      this.stream = this.canvas.captureStream(30);
      this.recordingMode = 'composite';
      this.mic.getAudioTracks().forEach(t => this.stream.addTrack(t));
      this.createRecorder();
    } catch {
      this.stream?.getVideoTracks().forEach(t => t.stop());
      const videoTracks = this.camera?.getVideoTracks() || [];
      const audioTracks = this.mic?.getAudioTracks() || [];
      if (!videoTracks.length || !audioTracks.length) {
        this.releaseRecording();
        throw new Error('浏览器无法合成摄像头与麦克风录制流，请检查设备权限后重试');
      }
      this.stream = new MediaStream([...videoTracks, ...audioTracks]);
      this.recordingMode = 'camera-direct';
      this.createRecorder();
    }

    this.notify(
      `录制自检通过：画面（不含弹幕）+ 麦克风音轨已就绪（模式：${this.recordingMode}）。`,
      'info'
    );
  }

  createRecorder() {
    const types = recordingTypes(this.stream.getVideoTracks().length > 0, this.stream.getAudioTracks().length > 0);
    const options = {
      videoBitsPerSecond: this.canvas.width > 1280 || this.canvas.height > 1280 ? 4000000 : 2200000
    };
    for (const mimeType of types) {
      if (!MediaRecorder.isTypeSupported(mimeType)) continue;
      try { return new MediaRecorder(this.stream, { ...options, mimeType }); }
      catch (error) { if (error.name !== 'NotSupportedError') throw error; }
    }
    return new MediaRecorder(this.stream, options);
  }

  // TASK003 P1-B & TASK004 A15:
  // Capture per-question minimal audio slice AND persist it to IndexedDB before releasing memory.
  // Explicitly records and surfaces any persistence error instead of swallowing it with an empty catch!
  startQuestionAudioSlice(questionId, startMs = 0) {
    this.stopQuestionAudioSlice();
    if (!this.mic || typeof MediaRecorder === 'undefined' || !questionId) return;
    try {
      const audioTypes = recordingTypes(false, true);
      let rec = null;
      for (const mimeType of audioTypes) {
        if (MediaRecorder.isTypeSupported(mimeType)) {
          try { rec = new MediaRecorder(this.mic, { mimeType, audioBitsPerSecond: 64000 }); break; } catch {}
        }
      }
      if (!rec) rec = new MediaRecorder(this.mic);
      const chunks = [];
      const sessionId = this.session?.id || this.session?.session_id;
      let stoppedResolve;
      const stopPromise = new Promise(resolve => { stoppedResolve = resolve; });
      let stoppedAtMs = null;

      rec.ondataavailable = e => { if (e.data?.size) chunks.push(e.data); };
      rec.onstop = () => {
        const endMs = stoppedAtMs ?? this.timeline?.positionMs ?? startMs;
        const mime = rec.mimeType || chunks[0]?.type || 'audio/webm';
        if (chunks.length) {
          const blob = new Blob(chunks, { type: mime });
          this.questionAudioSlices.set(questionId, blob);
          if (sessionId && this.resources.saveQuestionAudioSlice) {
            this.sliceWriteQueue = this.sliceWriteQueue
              .then(() => this.resources.saveQuestionAudioSlice({
                sessionId,
                questionId,
                blob,
                startMs,
                endMs,
                mimeType: mime
              }))
              .catch(error => {
                // TASK003 P1-B & TASK004 A15: Never silently ignore audio slice persistence failures!
                const errMsg = error?.message || String(error);
                this.slicePersistErrors.set(questionId, errMsg);
                this.notify(`单题音频分片持久化失败（${errMsg}）：已保留整场原始录像与待处理任务，不会误删证据。`, 'error');
              })
              .finally(() => stoppedResolve());
            return;
          }
        }
        stoppedResolve();
      };
      rec.start(400);
      this.questionAudioRecorder = {
        questionId, rec, stopPromise,
        resolveStop: stoppedResolve,
        markStopPosition: () => { stoppedAtMs = this.timeline?.positionMs ?? startMs; }
      };
    } catch (error) {
      this.slicePersistErrors.set(questionId, error?.message || '录音分片器启动失败');
      this.questionAudioRecorder = null;
    }
  }

  stopQuestionAudioSlice() {
    const active = this.questionAudioRecorder;
    this.questionAudioRecorder = null;
    if (active?.rec && active.rec.state !== 'inactive') {
      active.markStopPosition?.();
      try { active.rec.stop(); } catch (error) {
        this.slicePersistErrors.set(active.questionId, error?.message || '录音分片停止失败');
        this.notify(`单题音频分片停止失败：${error?.message || error}`, 'error');
        active.resolveStop?.(); // Avoid hanging finishRecording when the browser rejects stop().
      }
      return active.stopPromise;
    }
    return Promise.resolve();
  }

  pauseQuestionAudioSlice() {
    const active = this.questionAudioRecorder;
    if (!active?.rec) return;
    if (active.rec.state === 'recording') {
      try { active.rec.pause(); } catch (error) {
        // Preserve the original fragment and fail closed. NEVER launch another
        // same-question recorder that would overwrite its persisted IDB key.
        this.slicePersistErrors.set(active.questionId, `暂停单题音频失败：${error?.message || error}`);
        void this.stopQuestionAudioSlice();
      }
    }
  }

  resumeQuestionAudioSlice(questionId) {
    const active = this.questionAudioRecorder;
    if (!questionId) return;
    if (!active || active.questionId !== questionId) {
      this.slicePersistErrors.set(questionId, '原音频分片不可恢复，保留整场原片待人工复核');
      return;
    }
    if (active.rec.state === 'paused') {
      try { active.rec.resume(); } catch (error) {
        this.slicePersistErrors.set(questionId, `继续单题音频失败：${error?.message || error}`);
      }
    } else if (active.rec.state !== 'recording') {
      this.slicePersistErrors.set(questionId, '音频分片录制器已中止，未覆盖旧录音');
    }
  }

  getSlicePersistError(questionId) {
    return this.slicePersistErrors.get(questionId) || null;
  }

  async getQuestionAudioSlice(questionId, sessionId = this.session?.id) {
    await this.sliceWriteQueue;
    if (sessionId && this.resources.getQuestionAudioSliceFromDB) {
      const persisted = await this.resources.getQuestionAudioSliceFromDB(sessionId, questionId);
      if (persisted?.blob) return persisted.blob;
    }
    if (this.questionAudioSlices.has(questionId)) {
      return this.questionAudioSlices.get(questionId);
    }
    return null;
  }

  async startSegment(question, activeMs) {
    if (!this.stream || this.failed || this.storageFailed) {
      throw new Error('录制流未就绪或已中断');
    }
    this.audioInput.resetQuestionPeak();
    if (this.recorder) {
      const resuming = this.recorder.state === 'paused';
      if (resuming) {
        try {
          this.recorder.resume();
          this.timeline.resume();
        } catch (error) {
          this.timeline.pause();
          this.failed = true;
          this.recording.status = 'interrupted';
          this.notify(`录像恢复失败：${error.message}。已录内容保留，请结束本场后重试。`);
          this.fault('录像恢复失败，已暂停练播');
          throw error;
        }
      }
      if (this.recorder.state !== 'recording') {
        throw new Error('MediaRecorder 未处于 recording 状态');
      }
      if (question) {
        this.timeline.open(question, this.recording.id, activeMs);
        if (resuming) this.resumeQuestionAudioSlice(question.question_id || question.id);
        else this.startQuestionAudioSlice(question.question_id || question.id, this.timeline.positionMs);
      }
      return this.recording;
    }

    if (this.recording) throw new Error('同一场次不可重复创建录制实例');
    let rec;
    try {
      rec = this.createRecorder();
    } catch (error) {
      this.failed = true;
      this.releaseRecording();
      throw new Error(`录像编码器启动失败：${error.message}`);
    }

    const dimensions = this.stream.getVideoTracks()[0]?.getSettings?.() || {};
    const recording = {
      id: uid(),
      sessionId: this.session.id,
      questionId: null,
      kind: 'continuous',
      timelineVersion: 2,
      contains_barrage: false,
      startedAt: Date.now(),
      startActiveMs: activeMs,
      endActiveMs: null,
      durationMs: 0,
      mime: rec.mimeType,
      status: 'recording',
      bytes: 0,
      persistedBytes: 0,
      cameraMirrored: this.mirror && this.recordingMode === 'composite',
      mode: this.recordingMode,
      hasAudio: this.stream.getAudioTracks().length > 0,
      width: dimensions.width || this.canvas?.width || null,
      height: dimensions.height || this.canvas?.height || null,
      events: []
    };
    this.recording = recording;
    this.segment = recording;
    this.recorder = rec;
    this.session.segments.push(recording);
    this.session.recordingLayout = 'continuous-v2-no-barrage';
    if (this.session.recording) {
      this.session.recording.local_recording_id = recording.id;
      this.session.recording.mime_type = recording.mime;
      this.session.recording.contains_barrage = false;
      this.session.recording.has_audio = recording.hasAudio;
      this.session.recording.status = 'recording';
    }

    const timeline = this.timeline;
    const emergency = this.emergency;
    const current = () => this.recorder === rec && this.recording === recording;
    let writes = this.writeQueue;
    let storageFailed = false;
    this.pendingEncoders.add(rec);

    const interrupt = () => {
      timeline.pause();
      if (timeline.range) {
        const observed = this.provider()?.elapsed;
        const estimated = timeline.range.startActiveMs + Math.max(0, timeline.positionMs - timeline.range.startMs);
        timeline.range.interrupted = true;
        timeline.range.endActiveEstimated = !Number.isFinite(observed);
        timeline.close(Number.isFinite(observed) ? observed : estimated);
      }
    };

    let sequence = 0;
    let stopped;
    this.stopSignal = new Promise(resolve => { stopped = resolve; });

    rec.ondataavailable = event => {
      if (!recording.mime) recording.mime = rec.mimeType || event.data?.type || '';
      if (!event.data?.size) return;
      const chunk = {
        id: `${recording.id}:${sequence}`,
        sequence: sequence++,
        sessionId: recording.sessionId,
        segmentId: recording.id,
        blob: event.data
      };
      recording.bytes += event.data.size;
      writes = writes.then(async () => {
        if (storageFailed) {
          emergency.push(chunk);
          return;
        }
        try {
          await this.resources.put('chunks', chunk);
          recording.persistedBytes += chunk.blob.size;
        } catch (error) {
          emergency.push(chunk);
          storageFailed = true;
          recording.status = 'storage-failed';
          if (current()) {
            this.storageFailed = true;
            this.notify(`录像写入失败（${error.name}），请下载应急录像，勿刷新页面。`, 'error');
            this.fault('存储失败，已暂停练播');
          }
        }
      });
      if (current()) this.writeQueue = writes;
    };

    rec.onerror = event => {
      if (!current()) return;
      interrupt();
      recording.status = 'interrupted';
      this.failed = true;
      this.notify(`录制中断：${event.error?.message || '设备或编码器异常'}`, 'error');
      this.fault('录制中断，已暂停练播');
    };

    rec.onstop = () => {
      if (!recording.mime) recording.mime = rec.mimeType || '';
      if (current() && !this.stopping) {
        interrupt();
        recording.status = 'interrupted';
        this.failed = true;
        this.fault('录像意外停止，已暂停练播');
      }
      void writes.finally(() => this.pendingEncoders.delete(rec));
      stopped();
    };

    for (const type of ['start', 'pause', 'resume', 'stop']) {
      rec.addEventListener(type, () => recording.events.push({
        type,
        positionMs: timeline.positionMs,
        monotonicMs: performance.now()
      }));
    }

    try {
      rec.start(1000);
      this.timeline.start();
      if (question) {
        this.timeline.open(question, recording.id, activeMs);
        this.startQuestionAudioSlice(question.question_id || question.id, this.timeline.positionMs);
      }
      this.draw();
      this.stream.getVideoTracks()[0]?.requestFrame?.();
      return recording;
    } catch (error) {
      recording.status = 'failed';
      this.failed = true;
      if (rec.state && rec.state !== 'inactive') {
        try { rec.stop(); } catch {}
      } else {
        this.pendingEncoders.delete(rec);
      }
      this.recorder = null;
      this.releaseRecording();
      stopped();
      throw new Error(`录制启动失败：${error.message}`);
    }
  }

  closeQuestion(activeMs) {
    void this.stopQuestionAudioSlice();
    this.timeline?.close(activeMs);
  }

  async pauseRecording(activeMs) {
    // Suspend a question's independent recorder in place instead of closing
    // and re-creating it under the SAME persisted `audio-slice:session:question` ID.
    this.timeline?.close(activeMs);
    if (!this.recorder || this.recorder.state !== 'recording') return;
    try {
      this.recorder.pause();
      this.timeline.pause();
      this.pauseQuestionAudioSlice();
    } catch (error) {
      this.failed = true;
      this.recording.status = 'interrupted';
      this.notify(`录像暂停失败：${error.message}`, 'error');
      await this.finishRecording(activeMs);
    }
  }

  async finishRecording(activeMs) {
    if (this.finishing) return this.finishing;
    const sliceStopPromise = this.stopQuestionAudioSlice();
    const rec = this.recorder;
    const recording = this.recording;
    if (!rec || !recording) {
      await sliceStopPromise;
      await this.sliceWriteQueue;
      return recording;
    }
    const hasVideo = this.stream?.getVideoTracks().length > 0;
    recording.audioInputObservation = this.audioInput.read(rec.state === 'recording');
    recording.durationMs = this.timeline.stop(activeMs);
    recording.endActiveMs = activeMs;
    recording.endedAt = Date.now();
    this.stopping = true;

    this.finishing = (async () => {
      let timedOut = false, timeout;
      try {
        if (rec.state === 'recording' && this.recordingMode === 'composite') {
          recording.tailPaintOpportunity = await captureTail(() => this.draw(), this.stream.getVideoTracks()[0]);
        }
        if (rec.state !== 'inactive') rec.stop();
        await Promise.race([
          this.stopSignal,
          new Promise(resolve => {
            timeout = setTimeout(() => { timedOut = true; resolve(); }, 8000);
          })
        ]);
      } catch {
        timedOut = true;
      } finally {
        clearTimeout(timeout);
      }

      // Wait for both main video chunks AND per-question audio slices to be persisted to IndexedDB before releasing memory
      await Promise.all([this.writeQueue, sliceStopPromise, this.sliceWriteQueue]);

      if (timedOut) {
        recording.status = 'interrupted';
        this.failed = true;
        this.notify('编码器结束超时，可用内容已保留，录像未确认完整。', 'warning');
      } else if (this.storageFailed) {
        recording.status = 'storage-failed';
      } else if (recording.status === 'recording') {
        if (!recording.bytes) {
          recording.status = 'empty';
        } else {
          try {
            recording.validation = await this.resources.inspectMedia(await this.resources.segmentBlob(recording), hasVideo);
          } catch (error) {
            recording.validation = { playable: null, error: 'inspection-unavailable', detail: error.message };
          }
          recording.timelineCheck = checkMediaTimeline(recording.durationMs, recording.validation?.durationMs);
          recording.status = recording.validation?.playable === true
            ? 'saved'
            : recording.validation?.playable === null
              ? 'stored'
              : 'unplayable';
          if (recording.validation?.playable === true && recording.timelineCheck.status !== 'within-tolerance') {
            recording.status = 'stored';
            this.notify(
              recording.timelineCheck.status === 'mismatch'
                ? '录像数据已保存，但媒体时长与答题计时存在偏差，已保留原始视频与弹幕时间轴。'
                : '录像已保存并可解码，媒体时长待播放时索引确认。',
              'info'
            );
          }
        }
      }
      this.recorder = null;
      this.segment = null;
      return recording;
    })();
    return this.finishing;
  }

  stopSegment(activeMs) {
    return this.finishRecording(activeMs);
  }

  summary() {
    if (!this.session?.segments?.length) return this.failed ? 'failed' : 'unavailable';
    if (this.session.segments.length === 1 && this.session.segments[0].kind === 'continuous') {
      return this.session.segments[0].status;
    }
    return this.session.segments.every(s => s.status === 'saved') ? 'saved' : 'partial';
  }

  audioStatus() {
    return this.audioInput.read(this.recorder?.state === 'recording');
  }

  audioStatusText() {
    return audioInputText(this.audioStatus());
  }

  releaseRecording() {
    void this.stopQuestionAudioSlice();
    this.audioInput.stop();
    const microphone = this.mic;
    this.mic = null;
    microphone?.getTracks().forEach(t => t.stop());
    if (this.recordingMode === 'composite') {
      this.stream?.getVideoTracks().forEach(t => t.stop());
    }
    this.stream = null;
    this.recordingMode = 'none';
  }

  dispose() {
    this.cameraRequest = (this.cameraRequest || 0) + 1;
    if (typeof cancelAnimationFrame === 'function') cancelAnimationFrame(this.frame);
    this.frame = 0;
    if (this.recorder && this.recorder.state !== 'inactive') {
      if (this.recording?.status === 'recording') this.recording.status = 'interrupted';
      try { this.recorder.stop(); } catch {}
    }
    this.recorder = null;
    this.releaseRecording();
    this.camera?.getTracks().forEach(t => t.stop());
    this.camera = null;
    if (this.video) this.video.srcObject = null;
  }
}
