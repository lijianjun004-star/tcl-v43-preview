import { formatTime } from '../training/core.js';

// Time within a single recording. Paused wall time never enters question offsets.
export class RecordingTimeline {
  constructor(now = () => performance.now()) {
    this.now = now;
    this.base = 0;
    this.state = 'idle';
    this.range = null;
  }
  get positionMs() {
    return this.base + (this.state === 'running' ? Math.max(0, this.now() - this.anchor) : 0);
  }
  start() {
    if (this.state !== 'idle') throw new Error('录像时间轴已启动');
    this.anchor = this.now();
    this.state = 'running';
  }
  pause() {
    if (this.state !== 'running') return;
    this.base = this.positionMs;
    this.state = 'paused';
  }
  resume() {
    if (this.state !== 'paused') return;
    this.anchor = this.now();
    this.state = 'running';
  }
  open(question, recordingId, activeMs) {
    if (this.range) this.close(activeMs);
    const range = {
      recordingId,
      startMs: this.positionMs,
      endMs: null,
      startActiveMs: activeMs,
      endActiveMs: null
    };
    if (question) {
      (question.videoRanges ||= []).push(range);
      if (!Number.isFinite(question.barrage_start_ms) || question.barrage_start_ms === 0) {
        question.barrage_start_ms = range.startMs;
        question.answer_start_ms = range.startMs;
      }
    }
    this.range = range;
    return range;
  }
  close(activeMs) {
    if (!this.range) return;
    this.range.endMs = Math.max(this.range.startMs, this.positionMs);
    this.range.endActiveMs = activeMs;
    this.range.short = this.range.endMs - this.range.startMs < 50;
    this.range = null;
  }
  stop(activeMs) {
    this.close(activeMs);
    this.pause();
    this.state = 'ended';
    return this.positionMs;
  }
}

export const formatPosition = ms => `${formatTime(ms)}.${String(Math.floor(Math.max(0, ms) % 1000)).padStart(3, '0')}`;

// Keep the original logical offsets. A duration comparison is NOT a PTS calibration.
export function checkMediaTimeline(logicalDurationMs, mediaDurationMs, toleranceMs = 250) {
  const known = Number.isFinite(logicalDurationMs) && logicalDurationMs >= 0 && Number.isFinite(mediaDurationMs) && mediaDurationMs > 0;
  const differenceMs = known ? mediaDurationMs - logicalDurationMs : null;
  return {
    version: 2,
    source: 'browser-media-duration',
    logicalDurationMs,
    mediaDurationMs: known ? mediaDurationMs : null,
    toleranceMs,
    differenceMs,
    status: !known ? 'unverified' : Math.abs(differenceMs) <= toleranceMs ? 'within-tolerance' : 'mismatch'
  };
}

export function mediaRange(range, check) {
  if (!range || !Number.isFinite(range.startMs) || range.startMs < 0 || !Number.isFinite(range.endMs) || range.endMs < range.startMs) {
    return { status: 'invalid' };
  }
  if (!check || check.status !== 'within-tolerance') return { status: check?.status || 'unverified' };
  const duration = check.mediaDurationMs;
  if (range.endMs > duration + check.toleranceMs) return { status: 'mismatch' };
  return {
    status: range.endMs > duration ? 'near-boundary' : 'within-tolerance',
    startMs: Math.min(range.startMs, Math.max(0, duration - 1)),
    endMs: Math.min(range.endMs, duration)
  };
}

// Allow the capture pipeline paint opportunities before stop.
export function captureTail(draw, track, timeoutMs = 150) {
  return new Promise(resolve => {
    if (typeof requestAnimationFrame !== 'function') {
      try { draw(); track?.requestFrame?.(); } catch {}
      resolve(true);
      return;
    }
    let done = false, first, second;
    const finish = painted => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      cancelAnimationFrame(first);
      cancelAnimationFrame(second);
      resolve(painted);
    };
    const timer = setTimeout(() => finish(false), timeoutMs);
    try {
      draw();
      track?.requestFrame?.();
      first = requestAnimationFrame(() => {
        second = requestAnimationFrame(() => finish(true));
      });
    } catch {
      finish(false);
    }
  });
}

export function mediaDurationSeconds(player) {
  if (Number.isFinite(player.duration) && player.duration > 0) return player.duration;
  try {
    const end = player.seekable?.length ? player.seekable.end(player.seekable.length - 1) : null;
    return Number.isFinite(end) && end > 0 ? end : null;
  } catch {
    return null;
  }
}

export async function inspectMedia(blob, hasVideo, timeoutMs = 8000) {
  if (!blob?.size) return { playable: false, error: 'empty' };
  if (typeof document === 'undefined') return { playable: true, durationMs: null, width: 720, height: 1280 };
  const player = document.createElement(hasVideo ? 'video' : 'audio');
  const url = URL.createObjectURL(blob);
  player.muted = true;
  player.preload = 'auto';
  player.playsInline = true;
  player.style.cssText = 'position:fixed;left:-4px;bottom:0;width:2px;height:2px;opacity:.01;pointer-events:none';
  player.setAttribute('aria-hidden', 'true');
  document.body.append(player);
  try {
    return await new Promise(resolve => {
      let done = false;
      let decoded = null, seeking = false;
      const finish = result => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        player.onloadeddata = player.onerror = player.onseeked = player.ondurationchange = null;
        resolve(result);
      };
      const timer = setTimeout(() => finish(decoded ? { ...decoded, durationMs: null, durationError: 'duration-unavailable' } : { playable: null, error: 'decode-timeout' }), timeoutMs);
      const durationReady = () => {
        if (!decoded) return;
        const duration = mediaDurationSeconds(player);
        if (duration !== null) finish({ ...decoded, durationMs: duration * 1000 });
      };
      player.onloadeddata = () => {
        decoded = { playable: !hasVideo || player.videoWidth > 0, width: player.videoWidth || null, height: player.videoHeight || null };
        durationReady();
        if (!done && !seeking) {
          seeking = true;
          player.pause?.();
          try { player.currentTime = 1e10; } catch { finish({ ...decoded, durationMs: null, durationError: 'duration-unavailable' }); }
        }
      };
      player.ondurationchange = durationReady;
      player.onseeked = () => {
        durationReady();
        if (!done && decoded) finish({ ...decoded, durationMs: null, durationError: 'duration-unavailable' });
      };
      player.onerror = () => {
        const code = player.error?.code;
        finish({
          playable: code === 1 || code === 2 ? null : false,
          error: ({ 1: 'decode-aborted', 2: 'media-read-error', 3: 'decode-error', 4: 'unsupported-format' })[code] || 'decode-error',
          mediaErrorCode: code || null
        });
      };
      player.src = url;
      player.load();
      try { player.play()?.catch(() => {}); } catch {}
    });
  } finally {
    player.pause();
    player.removeAttribute('src');
    player.load();
    player.remove();
    URL.revokeObjectURL(url);
  }
}

function mediaEvent(player, name, action, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      clearTimeout(timer);
      player.removeEventListener(name, ok);
      player.removeEventListener('error', bad);
    };
    const ok = () => { cleanup(); resolve(); };
    const bad = () => { cleanup(); reject(new Error('录像无法加载或定位')); };
    const timer = setTimeout(() => { cleanup(); reject(new Error('录像定位超时')); }, timeoutMs);
    player.addEventListener(name, ok, { once: true });
    player.addEventListener('error', bad, { once: true });
    try { action?.(); } catch (error) { cleanup(); reject(error); }
  });
}

export async function locateRecording(player, startMs) {
  if (!Number.isFinite(startMs) || startMs < 0) throw new Error('录像定位时间无效');
  if (player.readyState < 1) await mediaEvent(player, 'loadedmetadata', () => player.load?.());
  const requested = Math.max(0, startMs) / 1000;
  if (requested === 0) {
    if (!player.seeking && Math.abs(player.currentTime) < 0.001) return 0;
    await mediaEvent(player, 'seeked', () => { player.currentTime = 0; });
    return player.currentTime * 1000;
  }
  if (mediaDurationSeconds(player) === null) await mediaEvent(player, 'seeked', () => { player.currentTime = 1e10; });
  const end = mediaDurationSeconds(player);
  if (end === null || requested > end + 0.25) throw new Error('本题索引超出可定位录像范围，可播放整场录像并核对时间');
  const target = Math.min(requested, Math.max(0, end - 0.001));
  if (!player.seeking && Math.abs(player.currentTime - target) < 0.001) return player.currentTime * 1000;
  await mediaEvent(player, 'seeked', () => { player.currentTime = target; });
  return player.currentTime * 1000;
}
