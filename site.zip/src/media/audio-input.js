// Local level observation only. Never plays the microphone or uploads samples.
export class AudioInputMonitor {
  constructor(makeContext = () => { const C = globalThis.AudioContext || globalThis.webkitAudioContext; return C ? new C() : null; }) {
    this.makeContext = makeContext;
    this.generation = 0;
    this.peak = 0;
    this.samples = 0;
    this.questionPeak = 0;
  }
  async start(stream) {
    this.stop();
    const generation = this.generation;
    this.stream = stream;
    this.peak = 0;
    this.questionPeak = 0;
    this.samples = 0;
    this.error = null;
    try {
      const context = this.context = this.makeContext();
      if (!context) return;
      this.source = context.createMediaStreamSource(stream);
      this.analyser = context.createAnalyser();
      this.analyser.fftSize = 512;
      this.source.connect(this.analyser); // No connection to speakers: avoids feedback.
      this.buffer = new Float32Array(this.analyser.fftSize);
      if (context.state === 'suspended') await context.resume();
      if (generation !== this.generation) return;
    } catch {
      if (generation === this.generation) this.error = 'unavailable';
    }
  }
  resetQuestionPeak() {
    this.questionPeak = 0;
  }
  resume() {
    try { return this.context?.resume()?.catch(() => {}); } catch {}
  }
  read(observe = true) {
    const tracks = this.stream?.getAudioTracks() || [];
    const active = tracks.filter(t => t.readyState !== 'ended' && t.enabled !== false);
    let status = !tracks.length
      ? 'no-track'
      : !active.length
        ? 'inactive'
        : active.every(t => t.muted)
          ? 'muted'
          : this.error || !this.analyser
            ? 'unavailable'
            : this.context.state !== 'running'
              ? 'suspended'
              : 'quiet';
    let rms = 0;
    if (status === 'quiet') {
      try {
        this.analyser.getFloatTimeDomainData(this.buffer);
        rms = Math.sqrt(this.buffer.reduce((sum, n) => sum + n * n, 0) / this.buffer.length);
        if (observe) {
          this.samples++;
          this.peak = Math.max(this.peak, rms);
          this.questionPeak = Math.max(this.questionPeak, rms);
        }
        if (rms >= 0.01) status = 'signal';
      } catch {
        status = 'unavailable';
      }
    }
    return {
      status,
      rms,
      peak: this.peak,
      questionPeak: this.questionPeak,
      samples: this.samples,
      signalDetected: this.peak >= 0.01,
      questionSignalDetected: this.questionPeak >= 0.01
    };
  }
  stop() {
    this.generation++;
    this.source?.disconnect();
    this.analyser?.disconnect();
    try { this.context?.close()?.catch(() => {}); } catch {}
    this.source = this.analyser = this.context = this.buffer = this.stream = null;
  }
}

export function audioInputText(reading) {
  return ({
    'no-track': '未接入麦克风，当前无声',
    inactive: '麦克风音轨已停止或禁用',
    muted: '麦克风被系统静音',
    unavailable: '音轨已连接，音量未能检测',
    suspended: '音轨已连接，点击启用音量检测',
    signal: '检测到输入声响',
    quiet: reading.signalDetected ? '音轨已连接，当前安静' : '尚未检测到输入声响，请说话检查'
  })[reading.status];
}
