export function recordingFile(blob, recording, sessionId, label = '无弹幕原片') {
  const type = (blob.type || recording.mime || 'application/octet-stream').split(';')[0].trim().toLowerCase();
  const extension = type.includes('mp4') ? (type.startsWith('audio/') ? 'm4a' : 'mp4') : type.includes('webm') ? 'webm' : 'bin';
  const name = `${sessionId}-${label}.${extension}`;
  if (typeof globalThis.File === 'function') {
    try { return new globalThis.File([blob], name, { type }); } catch {}
  }
  const fallback = new Blob([blob], { type });
  Object.defineProperty(fallback, 'name', { value: name, enumerable: true });
  return fallback;
}

export function canSaveWithSystem(file, api = globalThis.navigator) {
  try {
    if (typeof globalThis.File !== 'function' || !(file instanceof globalThis.File)) return false;
    return typeof api?.share === 'function' && api.canShare?.({ files: [file] }) === true;
  } catch {
    return false;
  }
}

export async function saveWithSystem(file, api = globalThis.navigator) {
  if (!canSaveWithSystem(file, api)) return 'unsupported';
  try {
    await api.share({ files: [file], title: 'TCL练播房无弹幕原片' });
    return 'menu-closed';
  } catch (error) {
    if (error.name === 'AbortError') return 'cancelled';
    throw error;
  }
}

export function recordingAudioSummary(recording) {
  return recording.hasAudio === true
    ? '录制时已接入麦克风音轨'
    : recording.hasAudio === false
      ? '未接入音轨（无声）'
      : '旧记录音轨信息未知';
}

export function createFileActions({
  blob,
  recording,
  sessionId,
  url,
  status,
  assessmentStatus = 'pass',
  label = '无弹幕原片',
  downloadLabel = '下载无弹幕原片（本地文件）',
  doc = globalThis.document,
  api = globalThis.navigator
}) {
  const file = recordingFile(blob, recording, sessionId, label);
  const group = doc.createElement('div');
  group.className = 'recording-export-controls';

  // V4.3 policy: Do not offer system sharing for unverified / pending-score videos; only local rescue download
  const allowSystemShare = assessmentStatus === 'pass';

  if (allowSystemShare) {
    const save = doc.createElement('button');
    save.textContent = '保存到手机 / 系统菜单（仅本地原片）';
    save.dataset.action = 'save-file';
    save.onclick = async () => {
      if (save.disabled) return;
      save.disabled = true;
      try {
        const result = await saveWithSystem(file, api);
        status.textContent = result === 'cancelled'
          ? '已取消系统保存操作，本地原录像仍保留。'
          : result === 'unsupported'
            ? '此浏览器不支持系统文件保存菜单，请点击「下载无弹幕原片」。注意：本地下载不等同于云端同步。'
            : '系统菜单已关闭，请确认文件保存位置（本地保存不等于已上传 CloudBase 云端）。';
      } catch {
        status.textContent = '系统未允许文件保存菜单，请直接点击「下载无弹幕原片」。';
      } finally {
        save.disabled = false;
      }
    };
    group.append(save);
  }

  const download = doc.createElement('a');
  download.dataset.download = 'true';
  download.href = url;
  download.download = file.name;
  download.textContent = assessmentStatus === 'pass' ? downloadLabel : '本地救援下载原片（待评分保护）';
  download.onclick = () => {
    status.textContent = '已发起本地无弹幕原片下载（此操作仅保存在当前设备，未上传至 CloudBase 云端）。';
  };

  const open = doc.createElement('a');
  open.href = url;
  open.target = '_blank';
  open.rel = 'noopener';
  open.textContent = '新标签页查看原片（无弹幕）';

  const note = doc.createElement('p');
  note.className = 'muted';
  note.textContent = `原片视频流仅包含摄像头画面与麦克风声音，不含任何弹幕或 UI 文字（contains_barrage: false）。${recordingAudioSummary(recording)}。本地下载仅用于本机保存，不等同于云端共享。`;

  group.append(download, open, note);
  return group;
}
