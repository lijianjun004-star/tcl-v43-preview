// Independent DOM barrage overlay controller for both live recording preview and recorded video playback.
// Ensures 100% separation between video pixels and barrage text, while syncing accurately on play/pause/seek/playbackRate.

import { formatTime } from '../training/core.js';

export function findActiveBarrageItem(barrageTimeline, currentMs) {
  if (!Array.isArray(barrageTimeline) || !barrageTimeline.length || !Number.isFinite(currentMs)) {
    return null;
  }
  const ms = Math.max(0, currentMs);
  for (let i = barrageTimeline.length - 1; i >= 0; i--) {
    const item = barrageTimeline[i];
    const start = Number(item.barrage_start_ms ?? item.startMs ?? 0);
    const end = item.barrage_end_ms != null ? Number(item.barrage_end_ms) : Infinity;
    if (ms >= start && ms <= end + 80) {
      return item;
    }
  }
  return null;
}

export function renderLiveBarrageDOM(overlayEl, {
  visible = false,
  question = null,
  questionIndex = 1,
  totalQuestions = 5,
  questionElapsedMs = 0,
  asrPreviewText = '',
  paused = false
} = {}) {
  if (!overlayEl) return;
  overlayEl.hidden = !visible || !question;
  if (!visible || !question) {
    overlayEl.dataset.activeQuestionId = '';
    return;
  }
  overlayEl.dataset.activeQuestionId = question.question_id || question.id || '';
  overlayEl.dataset.paused = String(Boolean(paused));

  const badge = overlayEl.querySelector('[data-role="barrage-badge"]');
  const timer = overlayEl.querySelector('[data-role="barrage-timer"]');
  const text = overlayEl.querySelector('[data-role="barrage-question"]');
  const asr = overlayEl.querySelector('[data-role="barrage-asr"]');

  if (badge) badge.textContent = `弹幕提问 · 第 ${questionIndex} / ${totalQuestions} 题`;
  if (timer) timer.textContent = `${paused ? '已暂停 · ' : ''}${formatTime(questionElapsedMs)}`;
  if (text) text.textContent = question.question_text || question.content || '';
  if (asr) {
    asr.textContent = asrPreviewText
      ? `实时识别：${asrPreviewText}`
      : '请直接口头回答，回答完毕点击下方「下一题 / 完成考核」';
  }
}

export function attachPlaybackBarrageOverlay(playerEl, containerEl, barrageTimeline = []) {
  const overlay = document.createElement('div');
  overlay.className = 'playback-barrage-overlay';
  overlay.dataset.testid = 'playback-barrage-overlay';
  overlay.hidden = true;

  const header = document.createElement('div');
  header.className = 'playback-barrage-head';
  const tag = document.createElement('span');
  tag.className = 'playback-barrage-tag';
  const timeLabel = document.createElement('span');
  timeLabel.className = 'playback-barrage-time';
  header.append(tag, timeLabel);

  const body = document.createElement('p');
  body.className = 'playback-barrage-text';
  overlay.append(header, body);
  containerEl.append(overlay);

  const sync = () => {
    const currentMs = (playerEl.currentTime || 0) * 1000;
    const item = findActiveBarrageItem(barrageTimeline, currentMs);
    overlay.dataset.paused = String(playerEl.paused);
    overlay.style.setProperty('--playback-rate', String(playerEl.playbackRate || 1));
    if (!item) {
      overlay.hidden = true;
      overlay.dataset.activeQuestionId = '';
      return;
    }
    overlay.hidden = false;
    overlay.dataset.activeQuestionId = item.question_id || '';
    tag.textContent = `DOM同步弹幕 · 第 ${item.order || 1} 题`;
    const relSec = Math.max(0, (currentMs - (item.barrage_start_ms || 0)) / 1000).toFixed(1);
    timeLabel.textContent = `${playerEl.paused ? '暂停' : `${playerEl.playbackRate || 1}x`} · +${relSec}s`;
    body.textContent = item.question_text || '';
  };

  for (const evt of ['timeupdate', 'play', 'pause', 'seeking', 'seeked', 'ratechange', 'loadedmetadata', 'ended']) {
    playerEl.addEventListener(evt, sync);
  }
  sync();
  return { overlay, sync };
}
