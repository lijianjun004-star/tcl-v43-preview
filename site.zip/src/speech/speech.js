// Unified ASR Controller for TCL Streamer V4.3 (TASK004 & TASK005 P1-01 Fix).
// - Default Primary: LocalASREngine (sherpa-onnx WebAssembly running inside Web Worker, 100% on-device after user-confirmed install).
// - Optional Live Preview / Secondary: Browser Web Speech API (explicitly labeled as browser-vendor cloud-assisted, NEVER misrepresented as pure local offline ASR).
// - Consent-Gated Fallback: Single-use Gemini audio slice transcription via isolated Gateway (requires per-session explicit anchor consent).
// - TASK005 P1-01: Blocks unverified injection of `provider: 'sherpa-onnx-local'` via `ingestSegment` unless backed by an authentic `verifiedAsrRecord` from `LocalASREngine`.

import { LocalASREngine } from './local-asr/engine.js';
import { isAuthenticLocalAsrResult } from './local-asr/asr-results.js';

export { LocalASREngine };

export const LOCAL_SHERPA_PRIVACY_NOTICE =
  '首选本地识别：安装「免费离线语音识别组件（sherpa-onnx WASM）」后，答题录音将在本机浏览器 Worker 内离线转写为文字，录音绝不上传第三方服务器。首次安装需手动点击确认（预计消耗移动流量或 Wi-Fi 流量，缓存在本机但浏览器清理后需重装）。';

export const BROWSER_SPEECH_PRIVACY_NOTICE =
  '隐私提示：浏览器内置语音识别（Web Speech API）可能由浏览器厂商（如 Google、Apple、Microsoft）将音频发送至其云端服务器处理，并非纯本地离线识别。正式考核仅发送音频用于语音转文字，不附带主播姓名与直属运营信息。';

export const GEMINI_FALLBACK_CONSENT_TEXT =
  '当前本地语音识别未安装或未能完成转写。是否单次同意将本题必要的语音片段（仅单题可解码音频分片，不含视频画面、主播姓名或直属运营）发送至隔离测试网关的 Google Gemini 免费服务进行语音转文字？（隐私提醒：免费 Gemini API 可能按其服务条款使用提交内容改进服务，请勿包含员工身份或机密信息；若拒绝，本场将安全保留为「待转写 / 待评分」状态。）';

export function detectBrowserSpeechSupport(win = globalThis) {
  const Ctor = win?.SpeechRecognition || win?.webkitSpeechRecognition || null;
  const ua = win?.navigator?.userAgent || '';
  const isWeChat = /MicroMessenger/i.test(ua);
  return {
    supported: typeof Ctor === 'function',
    Constructor: Ctor,
    isWeChat,
    privacyNotice: BROWSER_SPEECH_PRIVACY_NOTICE,
    limitationNote: isWeChat
      ? '检测到微信内置浏览器环境，系统 WebView 可能限制 Web Speech 连续识别；建议优先安装使用本地离线语音识别组件，或在答题结束时选择备用转写。'
      : typeof Ctor === 'function'
        ? '当前浏览器支持 Web Speech 辅助实时预览（注意：可能调用浏览器厂商云端服务，非纯本地识别）。'
        : '当前浏览器不支持 Web Speech API，答题录制仍正常进行，将优先使用已安装的本地 sherpa-onnx 离线识别或结束后选择备用转写。'
  };
}

export class SpeechRecognitionController {
  constructor({
    win = globalThis,
    now = () => performance.now(),
    onUpdate = () => {},
    onStatusChange = () => {},
    boundaryGraceMs = 350,
    localEngine = null
  } = {}) {
    this.win = win;
    this.now = now;
    this.onUpdate = onUpdate;
    this.onStatusChange = onStatusChange;
    this.boundaryGraceMs = boundaryGraceMs;
    this.localEngine = localEngine || new LocalASREngine({ win });

    const support = detectBrowserSpeechSupport(win);
    this.supported = support.supported;
    this.Constructor = support.Constructor;

    this.active = false;
    this.status = this.supported ? 'ready' : 'unsupported';
    this.currentQuestionId = null;
    this.previousQuestionId = null;
    this.lastSwitchMs = 0;
    this.interimStartedMs = null;

    this.records = new Map();
    this.recognition = null;
  }

  ensureQuestionRecord(questionId) {
    if (!questionId) return null;
    if (!this.records.has(questionId)) {
      this.records.set(questionId, {
        questionId,
        finalSegments: [],
        interimText: '',
        provider: 'browser',
        asrModelVersion: null,
        sourceAudioHash: null,
        status: this.supported ? 'listening' : 'unsupported',
        error: null
      });
    }
    return this.records.get(questionId);
  }

  startSession(firstQuestionId) {
    this.records.clear();
    this.currentQuestionId = firstQuestionId;
    this.previousQuestionId = null;
    this.lastSwitchMs = this.now();
    this.interimStartedMs = null;
    this.ensureQuestionRecord(firstQuestionId);

    if (!this.supported) {
      this.status = 'unsupported';
      this.onStatusChange(this.status, '已启用录音分片（结束后由本地离线模型或备用服务转写）');
      return false;
    }

    try {
      const rec = new this.Constructor();
      rec.lang = 'zh-CN';
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      rec.onstart = () => {
        this.status = 'ok';
        this.onStatusChange('ok', '语音识别运行中');
      };

      rec.onresult = event => {
        const nowMs = this.now();
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const res = event.results[i];
          const text = String(res[0]?.transcript || '').trim();
          const confidence = typeof res[0]?.confidence === 'number' ? res[0].confidence : null;
          if (!text) continue;

          let targetQId = this.currentQuestionId;
          if (
            this.previousQuestionId &&
            nowMs - this.lastSwitchMs <= this.boundaryGraceMs &&
            this.interimStartedMs !== null &&
            this.interimStartedMs < this.lastSwitchMs
          ) {
            targetQId = this.previousQuestionId;
          }

          const qRec = this.ensureQuestionRecord(targetQId);
          if (!qRec) continue;

          if (res.isFinal) {
            qRec.finalSegments.push({
              text,
              confidence,
              startMs: this.interimStartedMs ?? nowMs,
              endMs: nowMs,
              provider: 'browser'
            });
            qRec.interimText = '';
            qRec.status = 'ok';
            this.interimStartedMs = null;
          } else {
            if (this.interimStartedMs === null) this.interimStartedMs = nowMs;
            interim += text;
            qRec.interimText = interim;
          }
        }
        this.onUpdate(this.getQuestionTranscript(this.currentQuestionId));
      };

      rec.onerror = event => {
        const err = event?.error || 'unknown';
        if (err === 'no-speech') return;
        const qRec = this.ensureQuestionRecord(this.currentQuestionId);
        if (err === 'not-allowed' || err === 'service-not-allowed') {
          this.status = 'permission_denied';
          if (qRec) { qRec.status = 'permission_denied'; qRec.error = err; }
        } else {
          this.status = 'technical_fault';
          if (qRec) { qRec.status = 'technical_fault'; qRec.error = err; }
        }
        this.onStatusChange(this.status, `实时预览异常（${err}），结束后由本地离线模型转写`);
      };

      rec.onend = () => {
        if (this.active && this.status === 'ok') {
          try { rec.start(); } catch {}
        }
      };

      this.recognition = rec;
      this.active = true;
      rec.start();
      return true;
    } catch (error) {
      this.status = 'technical_fault';
      const qRec = this.ensureQuestionRecord(firstQuestionId);
      if (qRec) { qRec.status = 'technical_fault'; qRec.error = error.message; }
      this.onStatusChange(this.status, `语音识别启动失败：${error.message}`);
      return false;
    }
  }

  switchQuestion(nextQuestionId) {
    const nowMs = this.now();
    if (this.currentQuestionId) {
      const prevRec = this.ensureQuestionRecord(this.currentQuestionId);
      if (prevRec && prevRec.interimText.trim()) {
        prevRec.finalSegments.push({
          text: prevRec.interimText.trim(),
          confidence: null,
          startMs: this.interimStartedMs ?? this.lastSwitchMs,
          endMs: nowMs,
          provider: 'browser-flushed-on-switch'
        });
        prevRec.interimText = '';
      }
    }
    this.previousQuestionId = this.currentQuestionId;
    this.currentQuestionId = nextQuestionId;
    this.lastSwitchMs = nowMs;
    this.interimStartedMs = null;
    if (nextQuestionId) this.ensureQuestionRecord(nextQuestionId);
  }

  // Inject recognition result:
  // TASK005 P1-01: If `provider === 'sherpa-onnx-local'`, requires `verifiedAsrRecord` to pass `isAuthenticLocalAsrResult`!
  ingestSegment({
    questionId = null,
    text,
    isFinal = true,
    confidence = 0.95,
    timestampMs = null,
    provider = 'browser',
    asrModelVersion = null,
    sourceAudioHash = null,
    verifiedAsrRecord = null
  } = {}) {
    if (provider === 'sherpa-onnx-local') {
      if (!isAuthenticLocalAsrResult(verifiedAsrRecord) ||
          verifiedAsrRecord.question_id !== (questionId || this.currentQuestionId)) {
        const err = new Error(
          '安全阻断：禁止在未持有真实 sherpa-wasm-native 内部凭证的情况下声明或注入 sherpa-onnx-local 转写文本'
        );
        err.code = 'unverified_local_asr_injection';
        throw err;
      }
      text = verifiedAsrRecord.text;
      asrModelVersion = verifiedAsrRecord.asr_model_version;
      sourceAudioHash = verifiedAsrRecord.source_audio_hash;
    }

    const nowMs = timestampMs ?? this.now();
    let targetQId = questionId || this.currentQuestionId;
    if (
      !questionId &&
      this.previousQuestionId &&
      nowMs - this.lastSwitchMs <= this.boundaryGraceMs &&
      this.interimStartedMs !== null &&
      this.interimStartedMs < this.lastSwitchMs
    ) {
      targetQId = this.previousQuestionId;
    }
    const qRec = this.ensureQuestionRecord(targetQId);
    if (!qRec) return null;
    if (isFinal) {
      qRec.provider = provider || 'browser';
      if (asrModelVersion) qRec.asrModelVersion = asrModelVersion;
      if (sourceAudioHash) qRec.sourceAudioHash = sourceAudioHash;
      qRec.finalSegments.push({
        text: String(text || '').trim(),
        confidence,
        startMs: this.interimStartedMs ?? nowMs,
        endMs: nowMs,
        provider: provider || 'browser'
      });
      qRec.interimText = '';
      qRec.status = 'ok';
      this.interimStartedMs = null;
    } else {
      if (this.interimStartedMs === null) this.interimStartedMs = nowMs;
      qRec.interimText = String(text || '').trim();
    }
    return this.getQuestionTranscript(targetQId);
  }

  getQuestionTranscript(questionId) {
    const qRec = this.records.get(questionId);
    if (!qRec) {
      return {
        questionId,
        finalText: '',
        interimText: '',
        combinedText: '',
        provider: 'browser',
        asrModelVersion: null,
        sourceAudioHash: null,
        status: this.status,
        segments: []
      };
    }
    const finalText = qRec.finalSegments.map(s => s.text).filter(Boolean).join('；');
    const combinedText = [finalText, qRec.interimText].filter(Boolean).join(' ');
    return {
      questionId,
      finalText,
      interimText: qRec.interimText,
      combinedText: combinedText.trim(),
      provider: qRec.provider,
      asrModelVersion: qRec.asrModelVersion || null,
      sourceAudioHash: qRec.sourceAudioHash || null,
      status: qRec.status,
      error: qRec.error,
      segments: structuredClone(qRec.finalSegments)
    };
  }

  stopSession() {
    this.active = false;
    if (this.currentQuestionId) {
      this.switchQuestion(null);
    }
    if (this.recognition) {
      try { this.recognition.stop(); } catch {}
      this.recognition = null;
    }
  }
}

export async function requestGeminiFallbackTranscription({
  questionId,
  sessionId,
  audioBlob,
  startMs = 0,
  endMs = 0,
  userConsented = false,
  gatewayBaseUrl = '',
  fetchImpl = globalThis.fetch
} = {}) {
  if (userConsented !== true) {
    return {
      ok: false,
      status: 'transcription_pending',
      provider: 'none',
      transcript: null,
      reason: '主播未同意将语音分片发送至 Gemini 进行备用转写，已保留为「待转写/待评分」状态'
    };
  }
  if (!audioBlob || !audioBlob.size) {
    return {
      ok: false,
      status: 'transcription_pending',
      provider: 'none',
      transcript: null,
      reason: '未采集到有效的单题音频分片，已保留为「待转写/待评分」状态'
    };
  }
  const mimeType = String(audioBlob.type || 'audio/webm').toLowerCase();
  if (mimeType.startsWith('video/')) {
    throw new Error('安全策略阻断：禁止上传整场原始视频用于语音转写，仅允许上传单题音频分片');
  }
  if (audioBlob.size > 4 * 1024 * 1024) {
    return {
      ok: false,
      status: 'transcription_pending',
      provider: 'none',
      transcript: null,
      reason: '单题音频分片超过 4 MB 免费限额保护上限，已保留为待转写状态'
    };
  }

  const bytes = new Uint8Array(await audioBlob.arrayBuffer());
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  const audioBase64 = typeof btoa === 'function' ? btoa(binary) : Buffer.from(bytes).toString('base64');

  try {
    const res = await fetchImpl(`${gatewayBaseUrl || '.'}/api/ai/transcribe`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: sessionId,
        question_id: questionId,
        consent_confirmed: true,
        mime_type: mimeType.split(';')[0],
        start_ms: startMs,
        end_ms: endMs,
        audio_base64: audioBase64
      })
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      return {
        ok: false,
        status: data.status || 'transcription_pending',
        provider: 'gemini-fallback',
        transcript: null,
        reason: data.reason || data.error || '备用语音转写当前不可用，已保留为待转写状态'
      };
    }
    return {
      ok: true,
      status: 'completed',
      provider: 'gemini-fallback',
      transcript: data.transcript,
      model_id: data.model_id
    };
  } catch (error) {
    return {
      ok: false,
      status: 'transcription_pending',
      provider: 'gemini-fallback',
      transcript: null,
      reason: `备用语音转写网关未连接或网络中断（${error.message}），已保留为待转写状态`
    };
  }
}
