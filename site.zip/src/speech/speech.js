// R6: Browser Web Speech API only. No local model, no paid transcription, no invented transcripts.
// Real-time final recognition results are recorded per question; interim results are NEVER scoring input.
export const BROWSER_SPEECH_PRIVACY_NOTICE =
  '实时中文语音识别可能由手机浏览器厂商通过云端处理麦克风声音，需联网且得到主播明确同意。当前浏览器是否能在录像时同时识别，必须在实际手机验证。';

export function detectBrowserSpeechSupport(win = globalThis) {
  const Constructor = win?.SpeechRecognition || win?.webkitSpeechRecognition || null;
  const supported = typeof Constructor === 'function';
  return {
    supported, Constructor,
    isWeChat: /MicroMessenger/i.test(win?.navigator?.userAgent || ''),
    privacyNotice: BROWSER_SPEECH_PRIVACY_NOTICE,
    limitationNote: supported
      ? '已检测到浏览器识别接口，是否能与录像同时运行仍须实际验证。'
      : '本浏览器未提供网页语音识别接口。视频可照常录制，未转写的题目保留待处理。'
  };
}

export class SpeechRecognitionController {
  constructor({ win = globalThis, now = () => performance.now(), onUpdate = () => {}, onStatusChange = () => {}, maxAutoRestarts = 2 } = {}) {
    this.win = win;
    this.now = now;
    this.onUpdate = onUpdate;
    this.onStatusChange = onStatusChange;
    const support = detectBrowserSpeechSupport(win);
    this.supported = support.supported;
    this.Constructor = support.Constructor;
    this.maxAutoRestarts = maxAutoRestarts;
    this.status = this.supported ? 'ready' : 'unsupported';
    this.active = false;
    this.recognition = null;
    this.currentQuestionId = null;
    this.records = new Map();
    this._generation = 0;
    this._restartCount = 0;
    this._restartTimer = null;
    this._seenFinals = new Set();
    this._resultOwners = new Map();
    this._recognizerSerial = 0;
    this._activeRecognizerSerial = 0;
  }

  ensureQuestionRecord(questionId) {
    if (!questionId) return null;
    if (!this.records.has(questionId)) {
      this.records.set(questionId, {
        questionId, finalSegments: [], interimText: '', provider: 'browser', hadGap: false,
        status: this.supported ? 'listening' : 'unsupported', error: null
      });
    }
    return this.records.get(questionId);
  }

  _notify(status, detail) {
    this.status = status;
    this.onStatusChange(status, detail);
  }

  _markFault(status, error) {
    const record = this.ensureQuestionRecord(this.currentQuestionId);
    if (record) {
      // An error may omit onend. Later final fragments cannot prove the missing
      // speech was recovered, so keep this answer incomplete until it is sealed.
      record.hadGap = true;
      record.status = status;
      record.error = String(error || status);
    }
    this._notify(status, status === 'permission_denied'
      ? '浏览器拒绝语音识别权限，视频继续录制，当前题目待转写'
      : `浏览器语音识别异常：${error || status}，视频继续录制`);
  }

  _startRecognizer(generation) {
    if (!this.active || generation !== this._generation) return false;
    try {
      const recognition = new this.Constructor();
      recognition.lang = 'zh-CN';
      recognition.continuous = true; // Hint only: many mobile browsers ignore this setting.
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      this.recognition = recognition;
      // Guard both the session generation AND this exact browser recognizer instance.
      // Mobile browsers can deliver delayed onresult/onerror/onend from a retired instance.
      const instanceSerial = ++this._recognizerSerial;
      this._activeRecognizerSerial = instanceSerial;
      const isCurrent = () => this.active && generation === this._generation &&
        this.recognition === recognition && this._activeRecognizerSerial === instanceSerial;
      this._seenFinals.clear();
      this._resultOwners.clear();
      recognition.onstart = () => {
        if (!isCurrent()) return;
        this._notify('ok', '正在后台进行中文实时语音识别');
      };
      recognition.onresult = event => {
        if (!isCurrent()) return;
        let interim = ''; 
        for (let i = event.resultIndex || 0; i < (event.results?.length || 0); i++) {
          const res = event.results[i];
          const text = String(res?.[0]?.transcript || '').trim();
          if (!text) continue;
          if (!this._resultOwners.has(i)) this._resultOwners.set(i, this.currentQuestionId);
          const targetId = this._resultOwners.get(i);
          const record = this.ensureQuestionRecord(targetId);
          if (!record || record.sealed) continue;
          if (!res.isFinal) { if (targetId === this.currentQuestionId) interim += text; continue; }
          if (this._seenFinals.has(i)) continue;
          this._seenFinals.add(i);
          record.finalSegments.push({ text, confidence: typeof res?.[0]?.confidence === 'number' ? res[0].confidence : null,
            endMs: this.now(), provider: 'browser' });
          if (!record.hadGap) { record.status = 'ok'; record.error = null; }
          this._restartCount = 0;
        }
        const currentRecord = this.ensureQuestionRecord(this.currentQuestionId);
        if (currentRecord) currentRecord.interimText = interim;
        this.onUpdate(this.getQuestionTranscript(this.currentQuestionId));
      };
      recognition.onerror = event => {
        if (!isCurrent()) return;
        const err = event?.error || 'unknown';
        if (err === 'no-speech') {
          this._notify('listening', '尚未检测到讲话，正在继续尝试识别');
          return;
        }
        if (['not-allowed','service-not-allowed','audio-capture','language-not-supported'].includes(err)) {
          this._markFault(err === 'not-allowed' || err === 'service-not-allowed' ? 'permission_denied' : 'technical_fault', err);
          this.active = false; // Never spin on permission or missing-device errors.
        } else {
          this._markFault('technical_fault', err);
        }
      };
      recognition.onend = () => {
        if (!isCurrent()) return;
        // Retire the instance BEFORE scheduling its successor. No late callback may mutate state.
        this.recognition = null;
        this._activeRecognizerSerial = 0;
        if (this._restartCount >= this.maxAutoRestarts) {
          this._markFault('technical_fault', '自动恢复次数已达上限');
          this.active = false;
          return;
        }
        const affected = this.ensureQuestionRecord(this.currentQuestionId);
        if (affected) { affected.hadGap = true; affected.status = 'technical_fault'; affected.error = '浏览器识别服务中断，可能丢失部分口播'; }
        this._restartCount += 1;
        this._notify('reconnecting', '识别短暂中断，正在尝试恢复（录像继续）');
        this._restartTimer = this.win.setTimeout(() => {
          this._restartTimer = null;
          if (generation === this._generation && this.active) this._startRecognizer(generation);
        }, Math.min(2000, 400 * this._restartCount));
      };
      recognition.start();
      return true;
    } catch (error) {
      this._markFault('technical_fault', error?.message || '启动异常');
      this.active = false;
      return false;
    }
  }

  startSession(firstQuestionId, { consented = false } = {}) {
    this.stopSession();
    this.records.clear();
    this.currentQuestionId = firstQuestionId;
    this.ensureQuestionRecord(firstQuestionId);
    this._restartCount = 0;
    if (!consented) { this._markFault('permission_denied', '未同意浏览器可能联网处理语音'); return false; }
    if (!this.supported) { this._markFault('unsupported', '当前默认浏览器没有 SpeechRecognition'); return false; }
    this.active = true;
    return this._startRecognizer(this._generation);
  }

  _retireRecognizer() {
    // A question boundary is a hard ownership boundary: no previous recognizer callback
    // may ever be treated as speech from the next question.
    this._generation += 1;
    if (this._restartTimer !== null) {
      this.win.clearTimeout(this._restartTimer);
      this._restartTimer = null;
    }
    const previous = this.recognition;
    this.recognition = null;
    this._activeRecognizerSerial = 0;
    if (previous) {
      try { previous.stop(); } catch { try { previous.abort(); } catch {} }
    }
  }

  sealQuestion(questionId = this.currentQuestionId) {
    if (!questionId || questionId !== this.currentQuestionId) {
      throw new Error('不能封存非当前题目的识别记录');
    }
    const record = this.ensureQuestionRecord(questionId);
    if (!record.sealed) {
      if (record.interimText.trim()) {
        // Unconfirmed browser text is NOT final: incomplete answer remains pending.
        record.hadGap = true;
        record.status = 'technical_fault';
        record.error = '切题或结束时仍有未经确认的识别文字，已保留有效片段等待处理';
      }
      record.interimText = '';
      record.sealed = true;
      this._retireRecognizer();
    }
    // Frozen snapshot: further browser callbacks cannot change this question.
    return this.getQuestionTranscript(questionId);
  }

  switchQuestion(nextQuestionId) {
    if (this.currentQuestionId && !this.ensureQuestionRecord(this.currentQuestionId).sealed) {
      this.sealQuestion(this.currentQuestionId);
    }
    this.currentQuestionId = nextQuestionId;
    if (nextQuestionId) this.ensureQuestionRecord(nextQuestionId);
    if (this.active && this.supported && nextQuestionId) {
      this._restartCount = 0;
      return this._startRecognizer(this._generation);
    }
    return false;
  }

  getQuestionTranscript(questionId) {
    const record = this.records.get(questionId);
    const segments = record?.finalSegments || [];
    return {
      questionId, finalText: segments.map(x => x.text).filter(Boolean).join('；'),
      interimText: record?.interimText || '',
      combinedText: [segments.map(x => x.text).join('；'), record?.interimText || ''].filter(Boolean).join(' '),
      provider: 'browser', asrModelVersion: null, sourceAudioHash: null,
      status: record?.status || this.status,
      error: record?.error || null,
      segments: structuredClone(segments)
    };
  }

  pauseListening() {
    this.active = false;
    this._generation += 1;
    this._activeRecognizerSerial = 0;
    if (this._restartTimer !== null) { this.win.clearTimeout(this._restartTimer); this._restartTimer = null; }
    if (this.recognition) {
      try { this.recognition.stop(); } catch {}
      this.recognition = null;
    }
    this._notify('paused', '语音识别已暂停');
  }

  resumeListening({ consented = false } = {}) {
    if (!consented || !this.supported) return false;
    this.active = true;
    this._restartCount = 0;
    return this._startRecognizer(this._generation);
  }

  stopSession() {
    this.active = false;
    this._generation += 1;
    this._activeRecognizerSerial = 0;
    if (this._restartTimer !== null) {
      this.win.clearTimeout(this._restartTimer);
      this._restartTimer = null;
    }
    if (this.recognition) {
      const recognition = this.recognition;
      this.recognition = null;
      try { recognition.stop(); } catch { try { recognition.abort(); } catch {} }
    }
  }
}

// Legacy import compatibility. R6 explicitly forbids sending audio to a cloud transcription gateway.
export async function requestGeminiFallbackTranscription() {
  return { ok: false, status: 'transcription_pending', provider: 'none', transcript: null,
    reason: 'R6 已关闭云端备用语音转写。手机浏览器不能保证重转写历史录像。' };
}
