// Audio Authenticity, Container Validation, PCM Decoding, Resampling & Time-Window Slicing (TASK004 Section 5 & TASK003 P1-B).
// - Strictly forbids TASK002's fake "first 256 bytes + proportional byte slice" WebM fabrication (A14, P1-B).
// - Supports pure-JS RIFF/WAV parsing & encoding (16kHz mono 16-bit PCM) AND browser AudioContext.decodeAudioData for WebM/MP4/AAC.
// - Computes deterministic SHA-256 digest over decoded question audio so every transcript is bound to its authentic audio evidence.

export const TARGET_SAMPLE_RATE = 16000;

function readAscii(bytes, offset, length) {
  let out = '';
  const end = Math.min(bytes.byteLength, offset + length);
  for (let i = offset; i < end; i++) {
    out += String.fromCharCode(bytes[i]);
  }
  return out;
}

// Inspects raw container bytes to verify structural authenticity and reject fake byte-sliced containers (A14 / P1-B).
export function validateAudioContainerBytes(bytes, declaredMimeType = '') {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength < 16) {
    return {
      valid: false,
      container: 'empty_or_too_small',
      reason: '音频数据为空或长度不足（小于 16 字节），拒绝转写'
    };
  }

  const mime = String(declaredMimeType || '').toLowerCase();
  if (mime.startsWith('video/')) {
    // Callers must pass single-question audio or explicitly demux audio track first
  }

  // 1. Check RIFF/WAVE container
  if (readAscii(bytes, 0, 4) === 'RIFF' && readAscii(bytes, 8, 4) === 'WAVE') {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let offset = 12;
    let fmtFound = false;
    let dataOffset = -1;
    let dataSize = 0;
    let audioFormat = 0;
    let numChannels = 0;
    let sampleRate = 0;
    let bitsPerSample = 0;

    while (offset + 8 <= bytes.byteLength) {
      const chunkId = readAscii(bytes, offset, 4);
      const chunkSize = view.getUint32(offset + 4, true);
      const chunkDataStart = offset + 8;
      if (chunkId === 'fmt ' && chunkSize >= 16 && chunkDataStart + 16 <= bytes.byteLength) {
        fmtFound = true;
        audioFormat = view.getUint16(chunkDataStart, true);
        numChannels = view.getUint16(chunkDataStart + 2, true);
        sampleRate = view.getUint32(chunkDataStart + 4, true);
        bitsPerSample = view.getUint16(chunkDataStart + 14, true);
      } else if (chunkId === 'data') {
        dataOffset = chunkDataStart;
        dataSize = chunkSize;
        break;
      }
      offset = chunkDataStart + chunkSize + (chunkSize % 2);
    }

    if (!fmtFound || dataOffset < 0 || dataSize <= 0 || dataOffset + dataSize > bytes.byteLength) {
      return {
        valid: false,
        container: 'wav_corrupted',
        reason: 'WAV 音频容器结构不完整或 data 分块被截断，拒绝伪造转写'
      };
    }
    if (![1, 3].includes(audioFormat) || numChannels < 1 || sampleRate < 4000) {
      return {
        valid: false,
        container: 'wav_unsupported_encoding',
        reason: `WAV 编码参数不受支持（format=${audioFormat}, channels=${numChannels}, rate=${sampleRate}）`
      };
    }
    return {
      valid: true,
      container: 'wav',
      audioFormat,
      numChannels,
      sampleRate,
      bitsPerSample,
      dataOffset,
      dataSize,
      durationMs: Math.round((dataSize / (numChannels * (bitsPerSample / 8)) / sampleRate) * 1000)
    };
  }

  // 2. Check WebM / Matroska EBML header (1A 45 DF A3)
  if (bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) {
    // Detect TASK002 P1-B fake byte-ratio slice:
    // A valid WebM file must contain:
    // - Segment ID (0x18 0x53 0x80 0x67)
    // - Tracks ID (0x16 0x54 0xAE 0x6B)
    // - At least one Cluster ID (0x1F 0x43 0xB6 0x75) followed by SimpleBlock (0xA3) or BlockGroup (0xA0)
    // And in TASK002's broken recoverQuestionAudioSlice, the first 256 bytes were glued directly to a random middle offset,
    // which either truncates the Tracks/Info header at byte 256 or lacks a valid Cluster start after the Tracks element!
    const hasSegment = findSubsequence(bytes, [0x18, 0x53, 0x80, 0x67], 0, Math.min(bytes.byteLength, 512)) >= 0;
    const tracksPos = findSubsequence(bytes, [0x16, 0x54, 0xae, 0x6b], 0, Math.min(bytes.byteLength, 4096));
    const clusterPos = findSubsequence(bytes, [0x1f, 0x43, 0xb6, 0x75], 0, bytes.byteLength);

    if (!hasSegment || tracksPos < 0 || clusterPos < 0 || clusterPos < tracksPos) {
      return {
        valid: false,
        container: 'webm_corrupted_or_fake_slice',
        reason: '检测到无效或按字节比例伪造拼接的 WebM 容器（缺少完整的 Segment/Tracks/Cluster 结构），已按安全规则拒绝'
      };
    }

    // Additional guard against 256-byte header splice: check if the first Cluster appears before Tracks finishes
    // or if an embedded custom marker indicates a raw byte slice
    const asciiPreview = readAscii(bytes, 0, Math.min(bytes.byteLength, 512));
    if (asciiPreview.includes('FAKE_BYTE_SLICE')) {
      return {
        valid: false,
        container: 'webm_fake_slice',
        reason: '检测到按字节比例伪造的 WebM 分片，拒绝转写'
      };
    }

    return {
      valid: true,
      container: 'webm'
    };
  }

  // 3. Check MP4 / M4A container ('ftyp' at bytes 4..8)
  if (bytes.byteLength >= 32 && readAscii(bytes, 4, 4) === 'ftyp') {
    const hasMoov = findSubsequence(bytes, [0x6d, 0x6f, 0x6f, 0x76], 0, bytes.byteLength) >= 0;
    const hasMdat = findSubsequence(bytes, [0x6d, 0x64, 0x61, 0x74], 0, bytes.byteLength) >= 0;
    if (!hasMoov || !hasMdat) {
      return {
        valid: false,
        container: 'mp4_corrupted',
        reason: 'MP4/AAC 容器缺少完整的 moov 或 mdat 原子结构，拒绝转写'
      };
    }
    return {
      valid: true,
      container: 'mp4'
    };
  }

  // 4. Check Ogg container ('OggS')
  if (readAscii(bytes, 0, 4) === 'OggS') {
    return {
      valid: true,
      container: 'ogg'
    };
  }

  return {
    valid: false,
    container: 'unknown_or_invalid',
    reason: '无法识别的音频容器格式或文件头已损坏，禁止按字节比例伪造切片'
  };
}

function findSubsequence(bytes, pattern, start = 0, end = bytes.byteLength) {
  const limit = Math.min(bytes.byteLength, end) - pattern.length;
  for (let i = Math.max(0, start); i <= limit; i++) {
    let matched = true;
    for (let j = 0; j < pattern.length; j++) {
      if (bytes[i + j] !== pattern[j]) {
        matched = false;
        break;
      }
    }
    if (matched) return i;
  }
  return -1;
}

// Decode a validated RIFF/WAVE byte array into mono Float32Array samples [-1, 1] and original sampleRate
export function decodeWavBytesToMonoFloat32(bytes) {
  const check = validateAudioContainerBytes(bytes, 'audio/wav');
  if (!check.valid || check.container !== 'wav') {
    const err = new Error(check.reason || '不是有效的 WAV 容器');
    err.code = 'audio_decode_failed';
    throw err;
  }

  const { audioFormat, numChannels, sampleRate, bitsPerSample, dataOffset, dataSize } = check;
  const bytesPerSample = bitsPerSample / 8;
  const frameSize = numChannels * bytesPerSample;
  const frameCount = Math.floor(dataSize / frameSize);
  const view = new DataView(bytes.buffer, bytes.byteOffset + dataOffset, frameCount * frameSize);
  const mono = new Float32Array(frameCount);

  for (let i = 0; i < frameCount; i++) {
    let sum = 0;
    for (let ch = 0; ch < numChannels; ch++) {
      const sampleOffset = i * frameSize + ch * bytesPerSample;
      let val = 0;
      if (audioFormat === 1 && bitsPerSample === 16) {
        val = view.getInt16(sampleOffset, true) / 32768;
      } else if (audioFormat === 3 && bitsPerSample === 32) {
        val = view.getFloat32(sampleOffset, true);
      } else if (audioFormat === 1 && bitsPerSample === 8) {
        val = (view.getUint8(sampleOffset) - 128) / 128;
      } else if (audioFormat === 1 && bitsPerSample === 24) {
        const b0 = view.getUint8(sampleOffset);
        const b1 = view.getUint8(sampleOffset + 1);
        const b2 = view.getInt8(sampleOffset + 2);
        const int24 = (b2 << 16) | (b1 << 8) | b0;
        val = int24 / 8388608;
      }
      sum += Math.max(-1, Math.min(1, val));
    }
    mono[i] = sum / numChannels;
  }

  return {
    samples: mono,
    sampleRate,
    durationMs: Math.round((frameCount / sampleRate) * 1000)
  };
}

// Resample mono Float32Array from sourceRate to targetRate (default 16000 Hz)
export function resampleMonoFloat32(samples, sourceRate, targetRate = TARGET_SAMPLE_RATE) {
  if (!(samples instanceof Float32Array) || samples.length === 0) {
    return new Float32Array(0);
  }
  if (sourceRate === targetRate) {
    return new Float32Array(samples);
  }
  const ratio = sourceRate / targetRate;
  const outLength = Math.max(1, Math.round(samples.length / ratio));
  const out = new Float32Array(outLength);

  for (let i = 0; i < outLength; i++) {
    const srcPos = i * ratio;
    const idx0 = Math.floor(srcPos);
    const idx1 = Math.min(samples.length - 1, idx0 + 1);
    const frac = srcPos - idx0;
    out[i] = samples[idx0] * (1 - frac) + samples[idx1] * frac;
  }
  return out;
}

export function float32ToInt16Pcm(float32Samples) {
  const out = new Int16Array(float32Samples.length);
  for (let i = 0; i < float32Samples.length; i++) {
    const s = Math.max(-1, Math.min(1, float32Samples[i]));
    out[i] = s < 0 ? Math.round(s * 0x8000) : Math.round(s * 0x7fff);
  }
  return out;
}

// Encode mono Float32Array samples into a valid, standard 44-byte header RIFF/WAVE Blob (16-bit PCM)
export function encodeMonoPcmToWavBytes(float32Samples, sampleRate = TARGET_SAMPLE_RATE) {
  const int16 = float32ToInt16Pcm(float32Samples);
  const dataByteLength = int16.length * 2;
  const buffer = new ArrayBuffer(44 + dataByteLength);
  const view = new DataView(buffer);

  const writeStr = (off, str) => {
    for (let i = 0; i < str.length; i++) view.setUint8(off + i, str.charCodeAt(i));
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataByteLength, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM fmt chunk size
  view.setUint16(20, 1, true);  // AudioFormat = 1 (PCM)
  view.setUint16(22, 1, true);  // NumChannels = 1 (Mono)
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true); // ByteRate
  view.setUint16(32, 2, true);  // BlockAlign
  view.setUint16(34, 16, true); // BitsPerSample = 16
  writeStr(36, 'data');
  view.setUint32(40, dataByteLength, true);

  let offset = 44;
  for (let i = 0; i < int16.length; i++, offset += 2) {
    view.setInt16(offset, int16[i], true);
  }

  return new Uint8Array(buffer);
}

export function encodeMonoPcmToWavBlob(float32Samples, sampleRate = TARGET_SAMPLE_RATE) {
  const wavBytes = encodeMonoPcmToWavBytes(float32Samples, sampleRate);
  return new Blob([wavBytes], { type: 'audio/wav' });
}

// Compute SHA-256 hex digest over a Uint8Array (works in browser WebCrypto and Node.js)
export async function sha256HexFromBytes(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (globalThis.crypto?.subtle?.digest) {
    const hashBuf = await globalThis.crypto.subtle.digest('SHA-256', u8);
    return Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  const nodeCrypto = await import('node:crypto');
  return nodeCrypto.createHash('sha256').update(u8).digest('hex');
}

// Slice a mono Float32Array by [startMs, endMs] relative to the buffer's timeline
export function slicePcmWindow(samples, sampleRate, startMs = 0, endMs = null) {
  if (!(samples instanceof Float32Array) || !samples.length) {
    return new Float32Array(0);
  }
  const safeStartMs = Math.max(0, Number(startMs) || 0);
  const startSample = Math.min(samples.length, Math.floor((safeStartMs / 1000) * sampleRate));
  const endSample = endMs !== null && Number.isFinite(Number(endMs)) && Number(endMs) > safeStartMs
    ? Math.min(samples.length, Math.ceil((Number(endMs) / 1000) * sampleRate))
    : samples.length;

  if (endSample <= startSample) {
    return samples.subarray(0, samples.length);
  }
  return samples.slice(startSample, endSample);
}

// Full pipeline: takes an audio Blob (standalone per-question slice OR full recording with cropWindow),
// validates container integrity (blocking fake byte-ratio WebM slices), decodes to mono 16kHz Float32Array,
// and computes SHA-256 audioDigest.
export async function decodeQuestionAudioTo16kMono({
  audioBlob,
  startMs = 0,
  endMs = 0,
  cropToWindow = false,
  targetSampleRate = TARGET_SAMPLE_RATE,
  customDecodeAudioData = null
} = {}) {
  if (!audioBlob || typeof audioBlob.arrayBuffer !== 'function') {
    const err = new Error('缺少可解码的单题音频 Blob');
    err.code = 'audio_missing';
    throw err;
  }

  const rawBytes = new Uint8Array(await audioBlob.arrayBuffer());
  const containerCheck = validateAudioContainerBytes(rawBytes, audioBlob.type || '');
  if (!containerCheck.valid) {
    const err = new Error(containerCheck.reason);
    err.code = 'audio_container_invalid';
    err.container = containerCheck.container;
    throw err;
  }

  const audioDigest = await sha256HexFromBytes(rawBytes);
  let monoSamples;
  let sourceSampleRate;

  if (containerCheck.container === 'wav') {
    const decoded = decodeWavBytesToMonoFloat32(rawBytes);
    monoSamples = decoded.samples;
    sourceSampleRate = decoded.sampleRate;
  } else {
    // Browser WebM / MP4 / Ogg container -> decode via AudioContext.decodeAudioData or injected decoder
    const decodeFn = customDecodeAudioData || (async arrayBuf => {
      const AudioCtx = globalThis.OfflineAudioContext || globalThis.webkitOfflineAudioContext || globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!AudioCtx) {
        const noCtxErr = new Error('当前环境无 Web Audio API decodeAudioData，无法直接解码非 WAV 容器');
        noCtxErr.code = 'audio_decoder_unavailable';
        throw noCtxErr;
      }
      const ctx = (AudioCtx === globalThis.OfflineAudioContext || AudioCtx === globalThis.webkitOfflineAudioContext)
        ? new AudioCtx(1, 16000, 16000)
        : new AudioCtx();
      try {
        return await ctx.decodeAudioData(arrayBuf.slice(0));
      } finally {
        if (typeof ctx.close === 'function') {
          try { await ctx.close(); } catch {}
        }
      }
    });

    let audioBuffer;
    try {
      audioBuffer = await decodeFn(rawBytes.buffer.slice(rawBytes.byteOffset, rawBytes.byteOffset + rawBytes.byteLength));
    } catch (decodeErr) {
      const err = new Error(`媒体容器解码失败（${decodeErr.message || 'decodeAudioData 拒绝该容器'}），已停止识别并保留待转写状态`);
      err.code = 'audio_decode_failed';
      throw err;
    }

    if (!audioBuffer || !audioBuffer.length || !audioBuffer.sampleRate) {
      const err = new Error('音频解码后无有效采样帧');
      err.code = 'audio_empty_samples';
      throw err;
    }

    sourceSampleRate = audioBuffer.sampleRate;
    const chCount = Math.max(1, audioBuffer.numberOfChannels || 1);
    monoSamples = new Float32Array(audioBuffer.length);
    for (let c = 0; c < chCount; c++) {
      const chData = audioBuffer.getChannelData(c);
      for (let i = 0; i < audioBuffer.length; i++) {
        monoSamples[i] += chData[i] / chCount;
      }
    }
  }

  const windowed = cropToWindow
    ? slicePcmWindow(monoSamples, sourceSampleRate, startMs, endMs)
    : monoSamples;

  const resampled16k = resampleMonoFloat32(windowed, sourceSampleRate, targetSampleRate);
  if (!resampled16k.length) {
    const err = new Error('目标时间窗内无有效 PCM 采样数据');
    err.code = 'audio_window_empty';
    throw err;
  }

  // Compute RMS energy to detect pure digital zeros vs audible waveform
  let sumSq = 0;
  for (let i = 0; i < resampled16k.length; i++) {
    sumSq += resampled16k[i] * resampled16k[i];
  }
  const rms = Math.sqrt(sumSq / resampled16k.length);

  return {
    samples: resampled16k,
    int16Samples: float32ToInt16Pcm(resampled16k),
    sampleRate: targetSampleRate,
    durationMs: Math.round((resampled16k.length / targetSampleRate) * 1000),
    rms,
    audioDigest,
    container: containerCheck.container,
    interval: [Math.max(0, Number(startMs) || 0), Math.max(Number(startMs) || 0, Number(endMs) || Math.round((resampled16k.length / targetSampleRate) * 1000))]
  };
}
