// TASK006: real pinned native inference with durable local integrity evidence.
// This is not remote attestation; see docs/ASR_EVIDENCE_TASK006.md.

import {
  CANDIDATE_MODELS,
  MIN_PRODUCTION_ONNX_BYTES,
  MIN_PRODUCTION_VOCAB_SIZE,
  SHERPA_WASM_RUNTIME_MANIFEST,
  isProductionModelId
} from './model-manifest.js';

import { verifyAssetBytes } from './asset-integrity.js';
import { sha256HexFromBytes, validateAudioContainerBytes } from './audio-preprocess.js';
import { put } from '../../storage/storage.js';
import { evidenceBytes, EVIDENCE_VERSION, LOCAL_ASR_KEY_PREFIX } from './asr-results.js';
let lifecycle = 0;

let recognizerState = {
  ready: false,
  modelId: null,
  modelVersion: null,
  modelType: null,
  sampleRate: 16000,
  vocabSize: 0,
  modelBytesLength: 0,
  sherpaRecognizer: null,
  engineMode: 'uninitialized'
};

export function parseTokensTxt(tokensText) {
  const map = new Map();
  const lines = String(tokensText || '').split(/\r?\n/);
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    const parts = line.split(/\s+/);
    if (parts.length >= 2) {
      const token = parts[0];
      const id = Number(parts[parts.length - 1]);
      if (Number.isInteger(id)) {
        map.set(id, token);
      }
    } else if (parts.length === 1) {
      map.set(map.size, parts[0]);
    }
  }
  return map;
}

// Validates that an ONNX binary has a valid Protobuf ModelProto header and meets minimum production weight size
export function validateOnnxModelBytes(bytes, { minBytes = MIN_PRODUCTION_ONNX_BYTES } = {}) {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength === 0) {
    return { valid: false, code: 'worker_missing_model_files', reason: '缺少 model.int8.onnx 字节数据' };
  }
  if (bytes.byteLength < minBytes) {
    return {
      valid: false,
      code: 'invalid_onnx_model_size',
      reason: `拒绝加载非正式或截断的 ONNX 模型文件（当前仅 ${bytes.byteLength} 字节，正式量化语音模型需 >= ${minBytes} 字节）`
    };
  }
  // ONNX ModelProto starts with field 1 (ir_version, varint tag 0x08) followed by small positive integer version (1..15)
  if (bytes[0] !== 0x08 || bytes[1] < 0x01 || bytes[1] > 0x20) {
    return {
      valid: false,
      code: 'invalid_onnx_header',
      reason: 'model.int8.onnx 文件头不符合 ONNX Protobuf 规范，拒绝加载'
    };
  }
  return { valid: true, byteLength: bytes.byteLength };
}

// Detects pure silence or stationary narrowband pure sine waves (e.g. 370Hz, 520Hz, 770Hz test tones)
// so non-speech test signals never trigger false speech hypotheses.
export function analyzeSpeechSignalCharacteristics(floatSamples, sampleRate = 16000) {
  const frameSize = 400; // 25ms @ 16kHz
  const hopSize = 160;   // 10ms @ 16kHz
  let activeFrames = 0;
  let sumRms = 0;
  const frameZcrs = [];
  const frameRmsList = [];

  for (let offset = 0; offset + frameSize <= floatSamples.length; offset += hopSize) {
    let energy = 0;
    let zcr = 0;
    for (let i = 0; i < frameSize; i++) {
      const s = floatSamples[offset + i];
      if (!Number.isFinite(s)) continue;
      energy += s * s;
      if (i > 0 && ((floatSamples[offset + i - 1] >= 0) !== (s >= 0))) {
        zcr++;
      }
    }
    const rms = Math.sqrt(energy / frameSize);
    sumRms += rms;
    if (rms >= 0.005) {
      activeFrames++;
      frameZcrs.push(zcr);
      frameRmsList.push(rms);
    }
  }

  if (activeFrames === 0) {
    return { isSilence: true, isPureSineWave: false, activeFrames: 0, meanRms: 0 };
  }

  const meanZcr = frameZcrs.reduce((a, b) => a + b, 0) / frameZcrs.length;
  const zcrVariance = frameZcrs.reduce((acc, v) => acc + Math.pow(v - meanZcr, 2), 0) / frameZcrs.length;
  const zcrStdDev = Math.sqrt(zcrVariance);

  const meanRms = sumRms / Math.max(1, frameRmsList.length);
  const rmsVariance = frameRmsList.reduce((acc, v) => acc + Math.pow(v - meanRms, 2), 0) / frameRmsList.length;
  const rmsCv = meanRms > 0 ? Math.sqrt(rmsVariance) / meanRms : 0;

  // A stationary pure sine wave has virtually constant zero-crossing rate and constant envelope across frames
  const isPureSineWave = activeFrames >= 8 && zcrStdDev < 1.5 && rmsCv < 0.08;
  const estimatedHz = Math.round((meanZcr * sampleRate) / (2 * frameSize));

  return {
    isSilence: false,
    isPureSineWave,
    activeFrames,
    meanRms,
    zcrStdDev: Number(zcrStdDev.toFixed(4)),
    rmsCv: Number(rmsCv.toFixed(4)),
    estimatedHz
  };
}

// Resolves runtimeBaseUrl safely across Browser Main Thread, Browser Web Worker (/src/speech/local-asr/sherpa-worker.js), and Node ESM.
export function resolveRuntimeBaseUrl(runtimeBaseUrl = './models/sherpa-onnx/runtime') {
  const cleanBase = String(runtimeBaseUrl || './models/sherpa-onnx/runtime').replace(/\/+$/, '') + '/';
  if (/^(https?:|file:|blob:)/i.test(cleanBase)) {
    return new URL(cleanBase);
  }
  const baseHref = globalThis.location?.href || import.meta.url;
  const baseUrl = new URL(baseHref);
  if (cleanBase.startsWith('/')) {
    return new URL(cleanBase, baseUrl.origin && baseUrl.origin !== 'null' ? baseUrl.origin : baseHref);
  }
  // When executing inside /src/speech/local-asr/sherpa-worker.js (Browser Web Worker or Node ESM)
  if (/\/src\/speech\/local-asr\/[^/]+$/.test(baseUrl.pathname)) {
    const relFromRoot = cleanBase.replace(/^\.\//, '');
    if (baseUrl.protocol === 'file:') {
      return new URL(`../../../public/${relFromRoot}`, baseUrl);
    }
    return new URL(`../../../${relFromRoot}`, baseUrl);
  }
  return new URL(cleanBase, baseHref);
}

// Actively loads the official sherpa-onnx WebAssembly runtime scripts and verifies native Emscripten exports
export async function loadSherpaWasmRuntime({
  runtimeBaseUrl = './models/sherpa-onnx/runtime',
  runtimeLoader = null,
  fetchImpl = globalThis.fetch
} = {}) {
  if (runtimeLoader) throw Object.assign(new Error('不允许调用方注入运行时执行函数'), {code:'unverified_runtime_loader'});
  const resolvedBaseUrl = resolveRuntimeBaseUrl(runtimeBaseUrl);
  const buffers = {};
  const names = Object.fromEntries(SHERPA_WASM_RUNTIME_MANIFEST.files.map(f=>[f.role,f.name]));
  for (const spec of SHERPA_WASM_RUNTIME_MANIFEST.files) {
    if (!/^[a-f0-9]{64}$/i.test(spec.sha256 || '')) {
      throw Object.assign(new Error(`运行时 ${spec.name} 缺少可核实的固定 SHA-256，禁止执行`), {code:'sherpa_runtime_unverified'});
    }
    const url = new URL(spec.name, resolvedBaseUrl);
    let bytes;
    if (url.protocol === 'file:' && globalThis.process?.versions?.node && fetchImpl === globalThis.fetch) {
      const { readFile } = await import('node:fs/promises');
      try {
        bytes = new Uint8Array(await readFile(url));
      } catch {
        throw Object.assign(new Error(`运行时 ${spec.name} HTTP 404`), {code:'sherpa_runtime_unavailable'});
      }
    } else {
      const resp = await fetchImpl(url.href);
      if (!resp?.ok) throw Object.assign(new Error(`运行时 ${spec.name} HTTP ${resp?.status}`), {code:'sherpa_runtime_unavailable'});
      bytes = new Uint8Array(await resp.arrayBuffer());
    }
    const check = await verifyAssetBytes(bytes, spec, {minBytes: spec.name.endsWith('.wasm') ? SHERPA_WASM_RUNTIME_MANIFEST.minWasmBytes : 1024});
    if (!check.valid) throw Object.assign(new Error(`运行时 ${spec.name} SHA-256校验失败`), {code:'sherpa_runtime_corrupted'});
    buffers[spec.name] = bytes;
  }
  // Execute exactly the pinned bytes (no second unverified script fetch, no ambient globals).
  // Emscripten classic scripts share one lexical Module; await native initialization.
  let readyResolve, readyReject;
  const ready = new Promise((resolve,reject) => { readyResolve=resolve; readyReject=reject; });
  const config = {
    wasmBinary: buffers[names['wasm-binary']],
    noInitialRun: true,
    locateFile: name => new URL(name, resolvedBaseUrl).href,
    onRuntimeInitialized: () => readyResolve(),
    onAbort: reason => readyReject(new Error(String(reason)))
  };
  let glue = new TextDecoder().decode(buffers[names['emscripten-glue']]);
  // The pinned official release bundles an unrelated streaming encoder/decoder .data pack.
  // Disable ONLY that known packager preamble; mount our separately hashed offline model later.
  // Never fetch the unpinned .data archive or execute unverified replacement glue.
  const adapter = SHERPA_WASM_RUNTIME_MANIFEST.adapterPreload;
  const glueBytes = buffers[names['emscripten-glue']];
  if (!adapter || !Number.isInteger(adapter.start) || !Number.isInteger(adapter.end) ||
      adapter.start < 0 || adapter.end <= adapter.start || adapter.end >= glueBytes.length ||
      await sha256HexFromBytes(glueBytes.slice(adapter.start,adapter.end)) !== adapter.sha256) {
    throw Object.assign(new Error('未知官方glue预加载布局，拒绝未经核验的运行时适配'), {code:'sherpa_runtime_unavailable'});
  }
  const adaptedBytes = new Uint8Array(adapter.start + glueBytes.length - adapter.end);
  adaptedBytes.set(glueBytes.subarray(0,adapter.start));
  adaptedBytes.set(glueBytes.subarray(adapter.end),adapter.start);
  glue = new TextDecoder().decode(adaptedBytes);
  const helper = new TextDecoder().decode(buffers[names['js-capi-wrapper']]);
  let nodeRequire, nodeDir, nodeFile;
  if (globalThis.process?.versions?.node) {
    const { createRequire } = await import('node:module');
    const { fileURLToPath } = await import('node:url');
    const fileBaseUrl = resolvedBaseUrl.protocol === 'file:' ? resolvedBaseUrl : new URL('./', import.meta.url);
    nodeFile = fileURLToPath(new URL(names['emscripten-glue'], fileBaseUrl));
    nodeDir = fileURLToPath(new URL('.', fileBaseUrl));
    nodeRequire = createRequire(import.meta.url);
  }
  const loaded = new Function('Module', 'require', '__dirname', '__filename', 'module',
    `${glue}\n${helper}\n;return {Module:Object.assign(Module,{FS}), OfflineRecognizer};`)(config, nodeRequire, nodeDir, nodeFile, {exports:{}});
  let timer;
  try {
    await Promise.race([ready, new Promise((_,reject) => {timer=setTimeout(() => reject(new Error('WASM 初始化超时')),30000);})]);
  } finally {clearTimeout(timer);}
  if (!loaded.Module?.FS?.writeFile || typeof loaded.OfflineRecognizer !== 'function' ||
      typeof loaded.Module._SherpaOnnxCreateOfflineRecognizer !== 'function') {
    throw Object.assign(new Error('WASM原生识别器导出缺失'), {code:'sherpa_runtime_unavailable'});
  }
  return loaded;
}

export async function initializeWorkerModel({
  modelId,
  modelVersion,
  modelType = 'paraformer',
  sampleRate = 16000,
  files = {},
  runtimeBaseUrl = './models/sherpa-onnx/runtime',
  runtimeLoader = null,
  fetchImpl = globalThis.fetch,
  simulateOom = false
} = {}) {
  // Always reset state first so failed initialization never leaves stale ready=true state
  disposeWorkerModel();

  if (simulateOom) {
    const oomErr = new WebAssembly.RuntimeError('WebAssembly.Memory(): could not allocate memory (Out of memory)');
    oomErr.code = 'worker_oom';
    throw oomErr;
  }

  if (!isProductionModelId(modelId)) {
    const simErr = new Error(
      `安全阻断：模型标识 "${modelId || ''}" 不属于受信任的正式生产模型（仅允许 paraformer-zh-small-int8 或 sense-voice-zh-small-int8），严禁加载测试或模拟组件`
    );
    simErr.code = 'forbidden_simulated_model';
    throw simErr;
  }

  const modelFile = files['model.int8.onnx'];
  const tokensFile = files['tokens.txt'];
  if (!modelFile?.bytes?.byteLength || !tokensFile?.bytes?.byteLength) {
    const err = new Error('Worker 初始化失败：缺少已校验的 model.int8.onnx 或 tokens.txt 字节数据');
    err.code = 'worker_missing_model_files';
    throw err;
  }

  const onnxBytes = modelFile.bytes instanceof Uint8Array ? modelFile.bytes : new Uint8Array(modelFile.bytes);
  const tokensBytes = tokensFile.bytes instanceof Uint8Array ? tokensFile.bytes : new Uint8Array(tokensFile.bytes);

  const onnxCheck = validateOnnxModelBytes(onnxBytes);
  if (!onnxCheck.valid) {
    const err = new Error(onnxCheck.reason);
    err.code = onnxCheck.code;
    throw err;
  }

  const tokensText = new TextDecoder('utf-8').decode(tokensBytes);
  const tokensMap = parseTokensTxt(tokensText);
  if (tokensMap.size < MIN_PRODUCTION_VOCAB_SIZE) {
    const err = new Error(
      `Worker 初始化失败：tokens.txt 词表条目数（${tokensMap.size}）不足正式中文语音模型最低要求（>= ${MIN_PRODUCTION_VOCAB_SIZE}），拒绝加载测试小词表`
    );
    err.code = 'invalid_tokens_vocab_size';
    throw err;
  }

  const manifest = CANDIDATE_MODELS[modelId];
  if (modelVersion !== manifest.version || modelType !== manifest.modelType) {
    throw Object.assign(new Error('模型版本或类型与固定清单不一致'), {code:'model_version_mismatch'});
  }
  for (const spec of manifest.files) {
    const check = await verifyAssetBytes(files[spec.name]?.bytes || new Uint8Array(), spec, {minBytes:spec.minBytes});
    if (!check.valid) throw Object.assign(new Error(`模型 ${spec.name} 缺少固定SHA-256或字节不匹配`), {code:'model_integrity_failed'});
  }
  // Actively load & verify official sherpa-onnx WebAssembly runtime (NO acoustic fallback permitted!)
  const { Module, OfflineRecognizer } = await loadSherpaWasmRuntime({
    runtimeBaseUrl,
    runtimeLoader,
    fetchImpl
  });

  Module.FS.writeFile('/model.int8.onnx', onnxBytes);
  Module.FS.writeFile('/tokens.txt', tokensBytes);

  const config = {
    featConfig: { samplingRate: sampleRate, featureDim: 80 },
    modelConfig: {
      paraformer: modelType === 'paraformer' ? { model: '/model.int8.onnx' } : { model: '' },
      senseVoice: modelType === 'sense_voice' ? { model: '/model.int8.onnx', language: 'auto', useItn: 1 } : { model: '' },
      tokens: '/tokens.txt',
      numThreads: 1,
      provider: 'cpu',
      debug: 0
    }
  };

  const recognizer = new OfflineRecognizer(config, Module);
  if (
    !recognizer ||
    typeof recognizer.createStream !== 'function' ||
    typeof recognizer.decode !== 'function' ||
    typeof recognizer.getResult !== 'function' ||
    !recognizer.handle
  ) {
    const recErr = new Error('sherpa-onnx createOfflineRecognizer 未返回有效的原生识别器句柄');
    recErr.code = 'invalid_native_recognizer';
    throw recErr;
  }

  recognizerState = {
    ready: true,
    modelId,
    modelVersion: modelVersion || 'verified',
    modelType,
    sampleRate,
    vocabSize: tokensMap.size,
    modelBytesLength: onnxBytes.byteLength,
    sherpaRecognizer: recognizer,
    engineMode: 'sherpa-wasm-native',
    modelAssetHashes: manifest.files.map(f => ({name:f.name,sha256:f.sha256})),
    runtimeAssetHashes: SHERPA_WASM_RUNTIME_MANIFEST.files.map(f => ({name:f.name,sha256:f.sha256}))
  };

  return {
    ready: true,
    modelId: recognizerState.modelId,
    modelVersion: recognizerState.modelVersion,
    vocabSize: recognizerState.vocabSize,
    modelBytesLength: recognizerState.modelBytesLength,
    engineMode: 'sherpa-wasm-native'
  };
}

export async function runWorkerTranscription({
  samples,
  sampleRate = 16000,
  evidenceContext = null
} = {}) {
  if (
    !recognizerState.ready ||
    recognizerState.engineMode !== 'sherpa-wasm-native' ||
    !recognizerState.sherpaRecognizer
  ) {
    const err = new Error('本地 sherpa-onnx 原生识别器尚未就绪（缺少真实 WASM 运行时或 ONNX 模型权重），拒绝执行转写');
    err.code = 'worker_not_initialized';
    throw err;
  }

  const generation = lifecycle;
  if (sampleRate !== recognizerState.sampleRate || (!Array.isArray(samples) && !(samples instanceof Float32Array))) {
    throw Object.assign(new Error('PCM 类型或采样率不合法'), {code:'worker_invalid_pcm'});
  }
  const floatSamples = samples instanceof Float32Array ? samples : new Float32Array(samples);
  if (!floatSamples.every(Number.isFinite)) throw Object.assign(new Error('PCM 含非有限数值'), {code:'worker_invalid_pcm'});
  if (!floatSamples.length) {
    const err = new Error('传入 Worker 的 PCM 采样为空');
    err.code = 'worker_empty_pcm';
    throw err;
  }

  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const audioDurationMs = Math.max(1, (floatSamples.length / sampleRate) * 1000);

  // Guard against silence or pure single-frequency test sine waves (e.g. 370Hz, 520Hz, 770Hz)
  const signalStats = analyzeSpeechSignalCharacteristics(floatSamples, sampleRate);
  if (signalStats.isSilence || signalStats.isPureSineWave) {
    const elapsedMs = Math.max(1, (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0);
    return {
      text: '',
      tokens: [],
      timestamps: [],
      isSilenceOrPureTone: true,
      signalStats,
      modelId: recognizerState.modelId,
      modelVersion: recognizerState.modelVersion,
      engineMode: 'sherpa-wasm-native',
      elapsedMs: Math.round(elapsedMs),
      rtf: Number((elapsedMs / audioDurationMs).toFixed(4))
    };
  }

  const stream = recognizerState.sherpaRecognizer.createStream();
  try {
    stream.acceptWaveform(sampleRate, floatSamples);
    recognizerState.sherpaRecognizer.decode(stream);
    const res = recognizerState.sherpaRecognizer.getResult(stream);
    const elapsedMs = Math.max(1, (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0);
    const output = {
      text: String(res?.text || '').trim(),
      tokens: Array.isArray(res?.tokens) ? res.tokens : [],
      timestamps: Array.isArray(res?.timestamps) ? res.timestamps : [],
      modelId: recognizerState.modelId,
      modelVersion: recognizerState.modelVersion,
      engineMode: 'sherpa-wasm-native',
      elapsedMs: Math.round(elapsedMs),
      rtf: Number((elapsedMs / audioDurationMs).toFixed(4))
    };
    if (!evidenceContext) return output; // benchmark: raw predictions, never a trusted client record
    if (generation !== lifecycle || !output.text) throw Object.assign(new Error('推理生命周期已结束或结果为空'), {code:'empty_transcription'});
    return await sealCompletedInference(output, evidenceContext, floatSamples, generation);
  } finally {
    if (stream && typeof stream.free === 'function') {
      try { stream.free(); } catch {}
    }
  }
}

// Private: callers cannot supply text, initialization claims or arbitrary records to sign.
async function sealCompletedInference(output, ctx, samples, generation) {
  const {sessionId, questionId, audio, startMs, endMs, cropToWindow = false} = ctx || {};
  if (!sessionId || !questionId || !audio?.arrayBuffer || !Number.isFinite(startMs) ||
      !Number.isFinite(endMs) || startMs < 0 || endMs <= startMs) {
    throw Object.assign(new Error('缺少推理对应的会话/题目/真实音频与时间区间'), {code:'invalid_evidence_context'});
  }
  const bytes = new Uint8Array(await audio.arrayBuffer());
  if (!validateAudioContainerBytes(bytes, audio.type).valid) throw new Error('推理音频容器无效');
  const audioDigest = await sha256HexFromBytes(bytes);
  const pcmHash = await sha256HexFromBytes(new Uint8Array(samples.buffer, samples.byteOffset, samples.byteLength));
  // Per-inference signing key; only VERIFY capability survives structured clone/reload.
  const raw = globalThis.crypto.getRandomValues(new Uint8Array(32));
  const signKey = await globalThis.crypto.subtle.importKey('raw', raw, {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  const verifyKey = await globalThis.crypto.subtle.importKey('raw', raw, {name:'HMAC',hash:'SHA-256'}, false, ['verify']);
  raw.fill(0);
  const keyId = globalThis.crypto.randomUUID();
  const record = {
    evidenceVersion:EVIDENCE_VERSION,
    id:`asr-result:${sessionId}:${questionId}`, kind:'local_asr_result',
    session_id:sessionId, question_id:questionId,
    text:output.text, provider:'sherpa-onnx-local', engineMode:'sherpa-wasm-native', status:'completed',
    modelId:recognizerState.modelId, modelVersion:recognizerState.modelVersion,
    asr_model_version:`${recognizerState.modelId}@${recognizerState.modelVersion}`,
    source_audio_hash:audioDigest, audioDigest, pcm_hash:pcmHash,
    interval:[startMs,endMs], cropToWindow:Boolean(cropToWindow),
    elapsedMs:output.elapsedMs, rtf:output.rtf, createdAt:new Date().toISOString(),
    model_asset_hashes:recognizerState.modelAssetHashes,
    runtime_asset_hashes:recognizerState.runtimeAssetHashes,
    proof:{keyId,signature:null}
  };
  const signature = await globalThis.crypto.subtle.sign('HMAC', signKey, evidenceBytes(record));
  record.proof.signature = Array.from(new Uint8Array(signature),b=>b.toString(16).padStart(2,'0')).join('');
  if (generation !== lifecycle || !recognizerState.ready) throw new Error('识别器已被释放，拒绝签发');
  await put('settings',{verifyKey},`${LOCAL_ASR_KEY_PREFIX}${keyId}`);
  return record;
}

export function getWorkerInternalState() {
  return {
    ready: recognizerState.ready,
    modelId: recognizerState.modelId,
    modelVersion: recognizerState.modelVersion,
    vocabSize: recognizerState.vocabSize,
    modelBytesLength: recognizerState.modelBytesLength,
    engineMode: recognizerState.engineMode,
    hasNativeHandle: Boolean(recognizerState.sherpaRecognizer?.handle)
  };
}

export function disposeWorkerModel() {
  lifecycle++;
  if (recognizerState.sherpaRecognizer && typeof recognizerState.sherpaRecognizer.free === 'function') {
    try { recognizerState.sherpaRecognizer.free(); } catch {}
  }
  recognizerState = {
    ready: false,
    modelId: null,
    modelVersion: null,
    modelType: null,
    sampleRate: 16000,
    vocabSize: 0,
    modelBytesLength: 0,
    sherpaRecognizer: null,
    engineMode: 'disposed'
  };
}

// Attach message handler when running inside a browser Web Worker context
if (typeof self !== 'undefined' && typeof self.postMessage === 'function' && typeof window === 'undefined') {
  self.onmessage = async event => {
    const msg = event?.data || {};
    const { requestId, type, payload } = msg;
    try {
      if (type === 'INIT_MODEL') {
        const res = await initializeWorkerModel(payload);
        self.postMessage({ requestId, ok: true, result: res });
      } else if (type === 'TRANSCRIBE_PCM') {
        const res = await runWorkerTranscription(payload);
        self.postMessage({ requestId, ok: true, result: res });
      } else if (type === 'DISPOSE') {
        disposeWorkerModel();
        self.postMessage({ requestId, ok: true, result: { disposed: true } });
      } else {
        self.postMessage({ requestId, ok: false, error: `Unknown worker message type: ${type}` });
      }
    } catch (error) {
      self.postMessage({
        requestId,
        ok: false,
        error: error?.message || String(error),
        code: error?.code || 'worker_error'
      });
    }
  };
}
