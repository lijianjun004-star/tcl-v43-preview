// User-Gesture-Gated Model Installer, Streaming Progress, SHA-256 Verification & Atomic Cache Manager
// (TASK004 Section 3, Section 7, Section 8, A01-A06, A09).
// - Never auto-downloads on page load (A01).
// - Requires explicit user click (userGestureConfirmed: true) before starting network fetch (A02).
// - Streams bytes with real progress (percentage when Content-Length exists; indeterminate bytes when omitted) (A02).
// - Supports AbortSignal cancellation & network interruption without marking partial downloads as installed (A03).
// - Verifies SHA-256 of every downloaded file before atomic activation; preserves old valid cache on mismatch (A04).
// - Reuses cached model on subsequent visits without re-downloading (A05).
// - Checks navigator.storage.estimate() before download and handles cache eviction cleanly without touching V4 IndexedDB data (A06).

import * as db from '../../storage/storage.js';
import {
  CANDIDATE_MODELS,
  getModelManifest,
  validateModelSourceUrl,
  verifyModelLicenseCompliance
} from './model-manifest.js';
import { sha256HexFromBytes } from './audio-preprocess.js';

export const MODEL_CACHE_PREFIX = 'tcl-v43-preview-model-';
export const MODEL_META_SETTINGS_KEY = 'local_asr_models_meta_v1';

// In-memory fallback binary cache for Node test environments without browser Cache Storage
const memoryBinaryCache = new Map();
const inFlightDownloads = new Map();

export function clearMemoryModelCacheForTests() {
  memoryBinaryCache.clear();
  inFlightDownloads.clear();
}

export function evictModelBinariesForTests(modelId) {
  for (const key of Array.from(memoryBinaryCache.keys())) {
    if (key.startsWith(`${modelId}:`)) {
      memoryBinaryCache.delete(key);
    }
  }
}

async function getInstalledRegistry() {
  const saved = await db.get('settings', MODEL_META_SETTINGS_KEY);
  if (saved && typeof saved === 'object' && saved.models) {
    return saved;
  }
  return { version: 1, activeModelId: null, models: {} };
}

async function saveInstalledRegistry(registry) {
  await db.put('settings', registry, MODEL_META_SETTINGS_KEY);
  return registry;
}

// The browser must never label memory-only weights as durable/installed.  In
// Node fixture tests, in-memory storage remains available when explicitly
// running without a DOM; production browsers require a verified Cache Storage
// round-trip before publishing "installed" metadata.
function cacheRequest(modelId, version, fileName) {
  return new Request(`https://local-asr-cache.internal/${encodeURIComponent(modelId)}/${encodeURIComponent(version)}/${encodeURIComponent(fileName)}`);
}

async function storeFileBytesInCache(modelId, version, fileName, bytes, cacheStorage = globalThis.caches, requirePersistentCache = false) {
  const cacheName = `${MODEL_CACHE_PREFIX}${modelId}-${version}`;
  const memKey = `${modelId}:${version}:${fileName}`;
  if (!cacheStorage || typeof cacheStorage.open !== 'function') {
    if (requirePersistentCache) {
      const err = new Error('浏览器不支持持久模型缓存。本次未标记为已安装，请检查隐私模式或存储权限。');
      err.code = 'cache_persistence_failed';
      throw err;
    }
    memoryBinaryCache.set(memKey, new Uint8Array(bytes)); // Node-only fixtures
    return { persisted: false, testMemoryOnly: true };
  }

  try {
    const cache = await cacheStorage.open(cacheName);
    const req = cacheRequest(modelId, version, fileName);
    await cache.put(req, new Response(bytes, {
      status: 200,
      headers: { 'Content-Type': 'application/octet-stream', 'Content-Length': String(bytes.byteLength) }
    }));
    // Read the actual persistent storage; in-memory success is insufficient.
    const written = await cache.match(req);
    if (!written) throw new Error('缓存写入后未能读回');
    const storedBytes = new Uint8Array(await written.arrayBuffer());
    if (storedBytes.byteLength !== bytes.byteLength ||
        await sha256HexFromBytes(storedBytes) !== await sha256HexFromBytes(bytes)) {
      throw new Error('模型缓存写入后内容校验不一致');
    }
    memoryBinaryCache.set(memKey, new Uint8Array(bytes));
    return { persisted: true };
  } catch (cause) {
    if (!requirePersistentCache) {
      memoryBinaryCache.set(memKey, new Uint8Array(bytes)); // legacy test-fixture behavior
      return { persisted: false, testMemoryOnly: true };
    }
    const err = new Error(`模型文件 ${fileName} 无法持久保存并读回校验（${cause.message}）。未标记为安装成功；请检查浏览器剩余空间后重试。`);
    err.code = 'cache_persistence_failed';
    throw err;
  }
}

async function loadFileBytesFromCache(modelId, version, fileName, cacheStorage = globalThis.caches, allowMemoryFallback = true) {
  const cacheName = `${MODEL_CACHE_PREFIX}${modelId}-${version}`;
  if (cacheStorage && typeof cacheStorage.open === 'function') {
    try {
      const hasCache = typeof cacheStorage.has === 'function' ? await cacheStorage.has(cacheName) : true;
      if (hasCache) {
        const cache = await cacheStorage.open(cacheName);
        const match = await cache.match(cacheRequest(modelId, version, fileName));
        if (match) return new Uint8Array(await match.arrayBuffer());
      }
    } catch {
      // For production, absence or denial of persistent cache is never hidden
      // by still-present process memory.
    }
  }
  if (!allowMemoryFallback) return null;
  const memKey = `${modelId}:${version}:${fileName}`;
  const memBytes = memoryBinaryCache.get(memKey);
  return memBytes ? new Uint8Array(memBytes) : null;
}

export class LocalModelInstaller {
  constructor({
    manifestMap = CANDIDATE_MODELS,
    fetchImpl = globalThis.fetch,
    cacheStorage = globalThis.caches,
    storageNavigator = globalThis.navigator?.storage,
    baseOrigin = globalThis.location?.origin || 'http://127.0.0.1',
    requirePersistentCache = typeof globalThis.document !== 'undefined'
  } = {}) {
    this.manifestMap = manifestMap;
    this.fetchImpl = fetchImpl;
    this.cacheStorage = cacheStorage;
    this.storageNavigator = storageNavigator;
    this.baseOrigin = baseOrigin;
    this.requirePersistentCache = Boolean(requirePersistentCache);
  }

  getManifest(modelId) {
    return getModelManifest(modelId, this.manifestMap);
  }

  async listInstalledModelIds() {
    const reg = await getInstalledRegistry();
    const validIds = [];
    for (const [modelId, meta] of Object.entries(reg.models || {})) {
      if (meta?.status === 'installed') {
        const state = await this.getInstallState(modelId);
        if (state.ready) validIds.push(modelId);
      }
    }
    return validIds;
  }

  // Checks install status and verifies that cached binaries have NOT been evicted by browser/OS (A05, A06)
  async getInstallState(modelId = null) {
    const reg = await getInstalledRegistry();
    const targetId = modelId || reg.activeModelId || 'paraformer-zh-small-int8';
    const manifest = this.getManifest(targetId);
    const meta = reg.models?.[targetId];

    if (!meta || meta.status !== 'installed') {
      return {
        ready: false,
        status: meta?.status || 'not_installed',
        evicted: Boolean(meta?.evicted),
        modelId: targetId,
        modelVersion: manifest?.version || null,
        bytes: 0,
        estimatedDownloadBytes: manifest?.estimatedTotalDownloadBytes || null,
        reason: meta?.lastError || '尚未下载安装本地语音识别模型'
      };
    }

    // Verify all files still exist in cache and match recorded SHA-256 / byte length
    let totalCachedBytes = 0;
    const expectedFiles = manifest?.files || [];
    if (!expectedFiles.length || meta.files?.length !== expectedFiles.length ||
        expectedFiles.some(f => !meta.files.some(m => m.name === f.name))) {
      return {ready:false,status:'needs_reinstall',reason:'缓存资源清单不完整，拒绝启用',modelId:targetId};
    }
    for (const fileMeta of meta.files || []) {
      const cachedBytes = await loadFileBytesFromCache(targetId, meta.version, fileMeta.name, this.cacheStorage, !this.requirePersistentCache);
      const expected = expectedFiles.find(f => f.name === fileMeta.name);
      const pinned = meta.version === manifest.version ? expected?.sha256 : fileMeta.sha256;
      const hashOk = cachedBytes && /^[a-f0-9]{64}$/i.test(pinned || '') &&
        (await sha256HexFromBytes(cachedBytes)) === pinned.toLowerCase() && fileMeta.sha256 === pinned;
      if (!cachedBytes || cachedBytes.byteLength !== fileMeta.bytes || !hashOk) {
        // Cache was evicted by browser/OS -> mark needs_reinstall without touching V4 sessions/recordings (A06)
        meta.status = 'needs_reinstall';
        meta.evicted = true;
        meta.lastError = '本地模型缓存缺失或SHA-256校验不通过（题库与录像数据未受影响），请点击重新下载安装';
        await saveInstalledRegistry(reg);
        return {
          ready: false,
          status: 'needs_reinstall',
          evicted: true,
          modelId: targetId,
          modelVersion: meta.version,
          bytes: 0,
          estimatedDownloadBytes: manifest?.estimatedTotalDownloadBytes || null,
          reason: meta.lastError
        };
      }
      totalCachedBytes += cachedBytes.byteLength;
    }

    return {
      ready: true,
      status: 'ready',
      cacheHit: true,
      modelId: targetId,
      modelVersion: meta.version,
      bytes: totalCachedBytes,
      installedAt: meta.installedAt,
      files: meta.files
    };
  }

  async loadInstalledModelFiles(modelId = null) {
    const state = await this.getInstallState(modelId);
    if (!state.ready) {
      const err = new Error(state.reason || '模型尚未安装或缓存已失效');
      err.code = state.status || 'model_not_ready';
      throw err;
    }
    const loadedFiles = {};
    for (const f of state.files || []) {
      const bytes = await loadFileBytesFromCache(state.modelId, state.modelVersion, f.name, this.cacheStorage, !this.requirePersistentCache);
      if (!bytes) {
        const err = new Error(`模型文件 ${f.name} 缓存丢失，请重新安装`);
        err.code = 'needs_reinstall';
        throw err;
      }
      loadedFiles[f.name] = {
        name: f.name,
        bytes,
        sha256: f.sha256
      };
    }
    return {
      modelId: state.modelId,
      modelVersion: state.modelVersion,
      totalBytes: state.bytes,
      files: loadedFiles
    };
  }

  // Strictly user-gesture-gated model download with streaming progress, SHA-256 verification, and atomic activation
  async installWithUserGesture({
    modelId = 'paraformer-zh-small-int8',
    userGestureConfirmed = false,
    secondModelConsentConfirmed = false,
    signal = null,
    onProgress = () => {}
  } = {}) {
    // Rule (Section 3.1 / A01 / A02): Never download without explicit user click confirmation!
    if (userGestureConfirmed !== true) {
      const err = new Error('安全策略阻断：未经主播主动点击确认，禁止在后台自动下载大容量语音识别模型');
      err.code = 'user_gesture_required';
      throw err;
    }

    const manifest = this.getManifest(modelId);
    if (!manifest) {
      const err = new Error(`未找到模型清单定义：${modelId}`);
      err.code = 'unknown_model';
      throw err;
    }

    // Rule (A30): Verify license compliance before downloading or activating
    const compliance = verifyModelLicenseCompliance(manifest);
    if (!compliance.compliant) {
      const err = new Error(compliance.reason);
      err.code = 'license_blocked';
      throw err;
    }

    // Check if already installed and valid in cache (A05: cache hit avoids duplicate download)
    const currentState = await this.getInstallState(modelId);
    if (currentState.ready && currentState.modelVersion === manifest.version) {
      onProgress(currentState.bytes, currentState.bytes, {
        percent: 100,
        indeterminate: false,
        cacheHit: true
      });
      return {
        ok: true,
        cacheHit: true,
        modelId,
        modelVersion: manifest.version,
        bytes: currentState.bytes
      };
    }

    // Rule (Section 3.1 / A09): If another model is already installed, downloading a second model requires explicit second-model consent!
    const installedIds = await this.listInstalledModelIds();
    const otherInstalled = installedIds.filter(id => id !== modelId);
    if (otherInstalled.length > 0 && secondModelConsentConfirmed !== true) {
      const err = new Error(
        `已安装模型（${otherInstalled.join(', ')}）。切换或加装第二款模型「${manifest.displayName}」预计消耗 ${Math.round((manifest.estimatedTotalDownloadBytes || 0) / 1048576)} MB 流量，需主播再次明确授权确认。`
      );
      err.code = 'second_model_consent_required';
      err.estimatedDownloadBytes = manifest.estimatedTotalDownloadBytes;
      throw err;
    }

    // Concurrency deduplication: prevent duplicate parallel downloads of the same model
    if (inFlightDownloads.has(modelId)) {
      return inFlightDownloads.get(modelId);
    }

    const downloadPromise = this._executeAtomicInstall({
      manifest,
      signal,
      onProgress
    });
    inFlightDownloads.set(modelId, downloadPromise);
    try {
      return await downloadPromise;
    } finally {
      inFlightDownloads.delete(modelId);
    }
  }

  async _executeAtomicInstall({ manifest, signal, onProgress }) {
    const modelId = manifest.modelId;

    // 1. Check storage quota headroom (Section 3.5 & A06): never delete V4 recordings/question sets!
    if (typeof this.storageNavigator?.estimate === 'function') {
      try {
        const est = await this.storageNavigator.estimate();
        if (Number.isFinite(est?.quota) && Number.isFinite(est?.usage)) {
          const remaining = est.quota - est.usage;
          const required = (manifest.estimatedTotalDownloadBytes || 0) * 1.2;
          if (remaining < required) {
            const err = new Error(
              `设备剩余可用存储空间不足（剩余 ${(remaining / 1048576).toFixed(1)} MB，模型安装需至少 ${(required / 1048576).toFixed(1)} MB）。为保护已保存的练播录像与题库，已取消模型下载。`
            );
            err.code = 'storage_insufficient';
            throw err;
          }
        }
      } catch (err) {
        if (err.code === 'storage_insufficient') throw err;
        // Graceful fallback if storage.estimate() throws
      }
    }

    if (typeof this.storageNavigator?.persist === 'function') {
      try { await this.storageNavigator.persist(); } catch {}
    }

    // Snapshot previous valid metadata so we can preserve it if the new download/hash fails (A04)
    const regBefore = await getInstalledRegistry();
    const previousValidModelMeta = regBefore.models?.[modelId]?.status === 'installed'
      ? structuredClone(regBefore.models[modelId])
      : null;

    const files = manifest.files || [];
    if (!files.length) {
      const err = new Error(`模型 ${modelId} 清单未包含可下载文件`);
      err.code = 'empty_manifest_files';
      throw err;
    }

    // Validate all URLs and hashes upfront
    for (const fileSpec of files) {
      const urlCheck = validateModelSourceUrl(fileSpec.relativeUrl || fileSpec.upstreamUrl, {
        baseOrigin: this.baseOrigin
      });
      if (!urlCheck.valid) {
        const err = new Error(urlCheck.reason);
        err.code = 'untrusted_model_url';
        throw err;
      }
      if (!fileSpec.sha256 || !/^[a-f0-9]{64}$/i.test(fileSpec.sha256)) {
        const err = new Error(
          `模型文件 ${fileSpec.name} 缺少已核验的固定 SHA-256 校验值（当前状态：${fileSpec.hashStatus || 'UNVERIFIED'}）。按零信任安全规范拒绝盲目下载未锁定哈希的模型权重。`
        );
        err.code = 'unverified_model_hash';
        throw err;
      }
    }

    const stagedFiles = [];
    let cumulativeBytes = 0;
    const manifestExpectedTotal = files.every(f => Number.isFinite(f.expectedBytes) && f.expectedBytes > 0)
      ? files.reduce((acc, f) => acc + f.expectedBytes, 0)
      : undefined;

    try {
      for (const fileSpec of files) {
        if (signal?.aborted) {
          const abortErr = new Error('主播已取消模型下载');
          abortErr.name = 'AbortError';
          abortErr.code = 'download_cancelled';
          throw abortErr;
        }

        const targetUrl = fileSpec.relativeUrl || fileSpec.upstreamUrl;
        const response = await this.fetchImpl(targetUrl, signal ? { signal } : undefined);
        if (!response || !response.ok) {
          const httpErr = new Error(`下载模型文件 ${fileSpec.name} 失败（HTTP ${response?.status || 'NetworkError'}）`);
          httpErr.code = 'download_http_error';
          throw httpErr;
        }

        const contentLengthHeader = response.headers?.get?.('content-length') ?? response.headers?.['content-length'];
        const parsedContentLength = contentLengthHeader !== null && contentLengthHeader !== undefined && contentLengthHeader !== ''
          ? Number(contentLengthHeader)
          : NaN;
        const hasKnownLength = Number.isFinite(parsedContentLength) && parsedContentLength > 0;
        // Never present a verified percent when the server cannot confirm
        // Content-Length. The UI displays received bytes in indeterminate mode.
        const totalForProgress = hasKnownLength
          ? (files.length === 1 ? parsedContentLength : (manifestExpectedTotal || undefined))
          : undefined;

        const chunks = [];
        let fileDownloaded = 0;

        if (response.body && typeof response.body.getReader === 'function') {
          const reader = response.body.getReader();
          while (true) {
            if (signal?.aborted) {
              try { await reader.cancel(); } catch {}
              const abortErr = new Error('主播已取消模型下载');
              abortErr.name = 'AbortError';
              abortErr.code = 'download_cancelled';
              throw abortErr;
            }
            const { done, value } = await reader.read();
            if (done) break;
            if (value && value.byteLength) {
              const u8 = value instanceof Uint8Array ? value : new Uint8Array(value);
              chunks.push(u8);
              fileDownloaded += u8.byteLength;
              cumulativeBytes += u8.byteLength;
              const percent = totalForProgress
                ? Math.min(99, Math.round((cumulativeBytes / totalForProgress) * 100))
                : null;
              onProgress(cumulativeBytes, totalForProgress, {
                fileName: fileSpec.name,
                fileDownloadedBytes: fileDownloaded,
                totalBytes: totalForProgress,
                percent,
                indeterminate: totalForProgress === undefined
              });
            }
          }
        } else if (typeof response.arrayBuffer === 'function') {
          const buf = await response.arrayBuffer();
          if (signal?.aborted) {
            const abortErr = new Error('主播已取消模型下载');
            abortErr.name = 'AbortError';
            abortErr.code = 'download_cancelled';
            throw abortErr;
          }
          const u8 = new Uint8Array(buf);
          chunks.push(u8);
          fileDownloaded += u8.byteLength;
          cumulativeBytes += u8.byteLength;
          const percent = totalForProgress
            ? Math.min(99, Math.round((cumulativeBytes / totalForProgress) * 100))
            : null;
          onProgress(cumulativeBytes, totalForProgress, {
            fileName: fileSpec.name,
            fileDownloadedBytes: fileDownloaded,
            totalBytes: totalForProgress,
            percent,
            indeterminate: totalForProgress === undefined
          });
        }

        if (hasKnownLength && fileDownloaded !== parsedContentLength) {
          const truncErr = new Error(`模型文件 ${fileSpec.name} 下载中断不完整（已收 ${fileDownloaded} B / 期望 ${parsedContentLength} B）`);
          truncErr.code = 'download_incomplete';
          throw truncErr;
        }

        // Concatenate chunks and compute SHA-256 before staging (A04)
        const combined = new Uint8Array(fileDownloaded);
        let offset = 0;
        for (const chunk of chunks) {
          combined.set(chunk, offset);
          offset += chunk.byteLength;
        }

        if (combined.byteLength === 0) {
          const emptyErr = new Error(`模型文件 ${fileSpec.name} 返回了 0 字节空内容`);
          emptyErr.code = 'download_empty';
          throw emptyErr;
        }

        const actualSha256 = await sha256HexFromBytes(combined);
        const expectedSha256 = String(fileSpec.sha256).toLowerCase();
        if (actualSha256.toLowerCase() !== expectedSha256) {
          const hashErr = new Error(
            `模型文件 ${fileSpec.name} SHA-256 校验和不匹配（期望 ${expectedSha256.slice(0, 12)}…，实际 ${actualSha256.slice(0, 12)}…），已拒绝激活并保留原有有效缓存`
          );
          hashErr.code = 'hash_mismatch';
          hashErr.expectedSha256 = expectedSha256;
          hashErr.actualSha256 = actualSha256;
          throw hashErr;
        }

        stagedFiles.push({
          name: fileSpec.name,
          bytes: combined,
          byteLength: combined.byteLength,
          sha256: actualSha256
        });
      }

      // All files verified! Atomically persist binaries and activate metadata
      for (const sf of stagedFiles) {
        await storeFileBytesInCache(modelId, manifest.version, sf.name, sf.bytes, this.cacheStorage, this.requirePersistentCache);
      }

      const regAfter = await getInstalledRegistry();
      regAfter.activeModelId = modelId;
      regAfter.models[modelId] = {
        modelId,
        version: manifest.version,
        officialModelName: manifest.officialModelName,
        status: 'installed',
        evicted: false,
        installedAt: new Date().toISOString(),
        totalBytes: cumulativeBytes,
        lastError: null,
        files: stagedFiles.map(sf => ({
          name: sf.name,
          bytes: sf.byteLength,
          sha256: sf.sha256
        }))
      };
      await saveInstalledRegistry(regAfter);

      onProgress(cumulativeBytes, cumulativeBytes, {
        percent: 100,
        indeterminate: false,
        completed: true
      });

      return {
        ok: true,
        cacheHit: false,
        modelId,
        modelVersion: manifest.version,
        bytes: cumulativeBytes,
        files: regAfter.models[modelId].files
      };
    } catch (error) {
      // Rule (A03, A04): On interruption or hash mismatch, NEVER overwrite a previously valid installed version!
      const regRollback = await getInstalledRegistry();
      if (previousValidModelMeta) {
        regRollback.models[modelId] = previousValidModelMeta;
      } else {
        regRollback.models[modelId] = {
          modelId,
          version: manifest.version,
          status: error.code === 'download_cancelled' ? 'not_installed' : 'install_failed',
          lastError: error.message,
          updatedAt: new Date().toISOString()
        };
      }
      await saveInstalledRegistry(regRollback);
      throw error;
    }
  }
}
