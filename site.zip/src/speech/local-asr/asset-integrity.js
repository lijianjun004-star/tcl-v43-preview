// TASK006: byte integrity is a prerequisite, never a consequence of file size or magic.
// This helper verifies data only. It cannot initialize a model or authenticate a transcript.
import { sha256HexFromBytes } from './audio-preprocess.js';

export function hasPinnedSha256(spec) {
  return typeof spec?.sha256 === 'string' && /^[a-f0-9]{64}$/i.test(spec.sha256);
}

export async function verifyAssetBytes(bytes, spec, { minBytes = 1 } = {}) {
  const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  const actualSha256 = await sha256HexFromBytes(data);
  const expectedSha256 = hasPinnedSha256(spec) ? spec.sha256.toLowerCase() : null;
  const hashMatched = expectedSha256 ? actualSha256 === expectedSha256 : false;
  const sizeOk = data.byteLength >= (spec?.minBytes ?? minBytes);
  const status = !expectedSha256 ? 'UNVERIFIED' : !hashMatched ? 'HASH_MISMATCH' : !sizeOk ? 'INVALID_SIZE' : 'STAGED_AND_VERIFIED';
  return {
    valid: status === 'STAGED_AND_VERIFIED', status,
    actualSha256, expectedSha256, hashMatched, bytes: data.byteLength,
    reason: status === 'STAGED_AND_VERIFIED' ? null : `${spec?.name || 'asset'}: ${status}`
  };
}
