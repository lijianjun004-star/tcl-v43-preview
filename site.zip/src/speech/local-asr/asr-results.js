// Local consistency evidence, not remote attestation. Only the inference worker signs.
// IDB clones/reloads are verified cryptographically against CURRENT saved audio.
import { put, get, getAll, getQuestionAudioSliceFromDB } from '../../storage/storage.js';
import { CANDIDATE_MODELS, SHERPA_WASM_RUNTIME_MANIFEST } from './model-manifest.js';
import { sha256HexFromBytes, validateAudioContainerBytes, decodeQuestionAudioTo16kMono } from './audio-preprocess.js';

const verifiedObjects = new WeakMap();
export const EVIDENCE_VERSION = 'local-asr-evidence-v1';
export const LOCAL_ASR_KEY_PREFIX = 'local-asr-signing-key:';

// Serialization is shared with the worker; this function grants no signing capability.
export function evidenceBytes(r) {
  return new TextEncoder().encode(JSON.stringify([
    r.evidenceVersion, r.id, r.kind, r.session_id, r.question_id, r.text,
    r.provider, r.engineMode, r.status, r.modelId, r.modelVersion,
    r.asr_model_version, r.source_audio_hash, r.audioDigest, r.pcm_hash,
    r.interval, r.cropToWindow, r.elapsedMs, r.rtf, r.createdAt,
    r.model_asset_hashes, r.runtime_asset_hashes, r.proof?.keyId
  ]));
}
function fingerprint(r) {
  return JSON.stringify([Array.from(evidenceBytes(r)), r.proof?.signature]);
}
function hexBytes(s) {
  if (typeof s !== 'string' || !/^[a-f0-9]{64}$/i.test(s)) return null;
  return Uint8Array.from(s.match(/../g), c => parseInt(c, 16));
}
function validShape(r) {
  const model = CANDIDATE_MODELS[r?.modelId];
  if (!model || r?.evidenceVersion !== EVIDENCE_VERSION || r.kind !== 'local_asr_result' ||
      !r.session_id || !r.question_id || r.id !== `asr-result:${r.session_id}:${r.question_id}` ||
      r.status !== 'completed' || r.provider !== 'sherpa-onnx-local' ||
      r.engineMode !== 'sherpa-wasm-native' || r.modelVersion !== model.version ||
      r.asr_model_version !== `${model.modelId}@${model.version}` ||
      !String(r.text || '').trim() || !hexBytes(r.source_audio_hash) ||
      r.audioDigest !== r.source_audio_hash || !hexBytes(r.pcm_hash) ||
      !Array.isArray(r.interval) || r.interval.length !== 2 ||
      !r.interval.every(Number.isFinite) || r.interval[0] < 0 || r.interval[1] <= r.interval[0] ||
      !Number.isFinite(r.elapsedMs) || r.elapsedMs < 0 || !Number.isFinite(r.rtf) || r.rtf < 0 ||
      !hexBytes(r.proof?.signature) || !r.proof?.keyId) return false;
  const match = (specs, hashes) => Array.isArray(hashes) && hashes.length === specs.length &&
    specs.every((f, i) => hexBytes(f.sha256) && hashes[i]?.name === f.name && hashes[i]?.sha256 === f.sha256);
  return match(model.files, r.model_asset_hashes) && match(SHERPA_WASM_RUNTIME_MANIFEST.files, r.runtime_asset_hashes);
}
export function isAuthenticLocalAsrResult(r) {
  return Boolean(r && verifiedObjects.has(r) && validShape(r) && verifiedObjects.get(r) === fingerprint(r));
}
// Kept as a rejecting compatibility stub. Callers cannot mint a record from text.
export function buildVerifiedLocalAsrResult() {
  throw Object.assign(new Error('仅识别 Worker 实际推理完成后可生成本地转写证据'), {code:'forged_asr_result_rejected'});
}
export async function verifyLocalAsrResult(record, { audioBlob = null, sessionId, questionId, interval } = {}) {
  try {
    if (!validShape(record) || (sessionId && sessionId !== record.session_id) ||
        (questionId && questionId !== record.question_id) ||
        (interval && JSON.stringify(interval) !== JSON.stringify(record.interval))) return null;
    const key = await get('settings', `${LOCAL_ASR_KEY_PREFIX}${record.proof.keyId}`);
    if (!key?.verifyKey || key.verifyKey.type !== 'secret' || key.verifyKey.extractable !== false ||
        key.verifyKey.algorithm.name !== 'HMAC' || !key.verifyKey.usages.includes('verify')) return null;
    if (!await globalThis.crypto.subtle.verify('HMAC', key.verifyKey,
      hexBytes(record.proof.signature), evidenceBytes(record))) return null;
    const saved = audioBlob ? null : await getQuestionAudioSliceFromDB(record.session_id, record.question_id);
    const blob = audioBlob || saved?.blob;
    if (!blob) return null;
    // Never trust the digest field stored next to the bytes.
    const bytes = new Uint8Array(await blob.arrayBuffer());
    if (!validateAudioContainerBytes(bytes, blob.type).valid ||
        await sha256HexFromBytes(bytes) !== record.source_audio_hash) return null;
    if (saved && (saved.sessionId !== record.session_id || saved.questionId !== record.question_id ||
        saved.startMs !== record.interval[0] || (saved.endMs > 0 && saved.endMs !== record.interval[1]))) return null;
    const decoded = await decodeQuestionAudioTo16kMono({audioBlob:blob,
      startMs:record.interval[0], endMs:record.interval[1], cropToWindow:record.cropToWindow});
    const pcmHash = await sha256HexFromBytes(new Uint8Array(decoded.samples.buffer, decoded.samples.byteOffset, decoded.samples.byteLength));
    if (pcmHash !== record.pcm_hash) return null;
    const verified = structuredClone(record);
    verifiedObjects.set(verified, fingerprint(verified));
    return verified;
  } catch { return null; }
}
export async function persistLocalAsrResult(resultRecord) {
  const verified = await verifyLocalAsrResult(resultRecord);
  if (!verified) throw Object.assign(new Error('拒绝保存未经推理签名及当前音频校验的转写'), {code:'unverified_asr_persistence_blocked'});
  await put('transcripts', verified);
  return verified;
}
export async function getPersistedLocalAsrResult(sessionId, questionId, options = {}) {
  if (!sessionId || !questionId) return null;
  const stored = await get('transcripts', `asr-result:${sessionId}:${questionId}`);
  return await verifyLocalAsrResult(stored, { ...options, sessionId, questionId });
}
export async function listSessionLocalAsrResults(sessionId) {
  const all = await getAll('transcripts');
  const results = await Promise.all(all.filter(r => r.session_id === sessionId && r.kind === 'local_asr_result')
    .map(r => verifyLocalAsrResult(r)));
  return results.filter(Boolean);
}
