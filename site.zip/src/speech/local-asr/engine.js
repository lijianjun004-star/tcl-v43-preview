// TASK006: real pinned native inference with durable local integrity evidence.
// This is not remote attestation; see docs/ASR_EVIDENCE_TASK006.md.

import {
  CANDIDATE_MODELS,
  MIN_PRODUCTION_ONNX_BYTES,
  formatModelBytes,
  isProductionModelId
} from './model-manifest.js';
import { probeDeviceCapabilities, selectOptimalModel } from './device-selector.js';
import { LocalModelInstaller } from './model-installer.js';
import { decodeQuestionAudioTo16kMono } from './audio-preprocess.js';
import { verifyLocalAsrResult, persistLocalAsrResult } from './asr-results.js';
import { getQuestionAudioSliceFromDB, saveQuestionAudioSlice } from '../../storage/storage.js';
import { initializeWorkerModel, runWorkerTranscription, disposeWorkerModel } from './sherpa-worker.js';

export const ENGINE_STATUS_LABELS = {
  not_installed: '暂未开放本地转写（未安装真实模型与运行时）',
  runtime_unavailable: '暂未开放本地转写（缺少已核验的 sherpa-onnx WASM 运行时或模型权重）',
  downloading: '正在下载并校验语音模型…',
  ready: '本地语音转文字已就绪（sherpa-onnx 离线识别）',
  transcribing: '正在本地识别音频…',
  needs_reinstall: '暂未开放本地转写（本地缓存已清理或校验未通过，需重新安装）',
  unavailable: '暂未开放本地转写（当前仅录制，结束后可选备用转写或保留待转写）'
};

export class LocalASREngine {
  #nativeInitialized = false;
  #verifiedModelKey = null;

  constructor({
    win = globalThis,
    manifestMap = CANDIDATE_MODELS,
    installer = null,
    workerFactory = null,
    runtimeBaseUrl = './models/sherpa-onnx/runtime',
    runtimeLoader = null,
    useInProcessWorkerForTests = typeof globalThis.Worker === 'undefined',
    customDecodeAudioData = null,
    benchmarkSummary = null,
    onStateChange = () => {}
  } = {}) {
    this.win = win;
    this.manifestMap = manifestMap;
    this.installer = installer || new LocalModelInstaller({
      manifestMap,
      fetchImpl: win?.fetch ? win.fetch.bind(win) : globalThis.fetch,
      cacheStorage: win?.caches,
      storageNavigator: win?.navigator?.storage,
      baseOrigin: win?.location?.origin || 'http://127.0.0.1'
    });
    this.workerFactory = workerFactory;
    this.runtimeBaseUrl = runtimeBaseUrl;
    this.runtimeLoader = runtimeLoader;
    this.useInProcessWorkerForTests = Boolean(useInProcessWorkerForTests);
    this.customDecodeAudioData = customDecodeAudioData;
    this.benchmarkSummary = benchmarkSummary;
    this.onStateChange = onStateChange;

    this.state = 'not_installed';
    this.lastError = null;
    this.selectedModelId = 'paraformer-zh-small-int8';
    this.worker = null;
    this.workerFailedPermanently = false;
    this.requestSeq = 0;
    this.pendingWorkerRequests = new Map();
    this.simulateWorkerOomOnce = false;
  }

  isNativeRecognizerVerified() {
    return this.#nativeInitialized;
  }

  _setState(nextState, detail = null) {
    this.state = nextState;
    if (detail) this.lastError = detail;
    try {
      this.onStateChange({
        state: this.state,
        label: ENGINE_STATUS_LABELS[this.state] || this.state,
        detail: this.lastError,
        selectedModelId: this.selectedModelId
      });
    } catch {}
  }

  async getSupport() {
    const capabilities = await probeDeviceCapabilities(this.win);
    const installedIds = await this.installer.listInstalledModelIds();
    const selection = selectOptimalModel({
      capabilities,
      manifestMap: this.manifestMap,
      installedModelIds: installedIds,
      benchmarkSummary: this.benchmarkSummary
    });

    if (selection.selectedModelId) {
      this.selectedModelId = selection.selectedModelId;
    }

    if (!capabilities.supported || !selection.supported) {
      this._setState('unavailable', selection.selectionReason || capabilities.reason);
      return {
        supported: false,
        reason: selection.selectionReason || capabilities.reason,
        capabilities,
        selection
      };
    }

    return {
      supported: true,
      reason: selection.selectionReason,
      selectedModelId: selection.selectedModelId,
      selectedManifest: selection.selectedManifest,
      requiresSecondModelConsent: selection.requiresSecondModelConsent,
      capabilities,
      selection
    };
  }

  async getInstallState(modelId = null) {
    const support = await this.getSupport();
    const targetModelId = modelId || this.selectedModelId || 'paraformer-zh-small-int8';
    const manifest = this.installer.getManifest(targetModelId);

    if (!support.supported) {
      return {
        ready: false,
        status: 'unavailable',
        humanLabel: ENGINE_STATUS_LABELS.unavailable,
        modelId: targetModelId,
        bytes: 0,
        estimatedDownloadBytes: manifest?.estimatedTotalDownloadBytes || null,
        reason: support.reason
      };
    }

    if (!isProductionModelId(targetModelId)) {
      this._setState('unavailable', `模型标识 ${targetModelId} 非正式生产模型，已拒绝启用`);
      return {
        ready: false,
        status: 'unavailable',
        humanLabel: ENGINE_STATUS_LABELS.unavailable,
        modelId: targetModelId,
        bytes: 0,
        estimatedDownloadBytes: null,
        reason: `模型标识 ${targetModelId} 非正式生产模型`
      };
    }

    const st = await this.installer.getInstallState(targetModelId);
    if (st.ready) {
      // Verify that the cached model weight is a full-sized production ONNX graph (>= 10 MB), never a tiny stub
      const onnxFileMeta = (st.files || []).find(f => f.name === 'model.int8.onnx');
      if (!onnxFileMeta || onnxFileMeta.bytes < MIN_PRODUCTION_ONNX_BYTES) {
        this._setState('runtime_unavailable', '缓存的模型文件体积小于正式 ONNX 权重下限（<10MB），暂未开放本地转写');
        return {
          ready: false,
          status: 'runtime_unavailable',
          humanLabel: ENGINE_STATUS_LABELS.runtime_unavailable,
          modelId: targetModelId,
          modelVersion: st.modelVersion,
          bytes: 0,
          estimatedDownloadBytes: manifest?.estimatedTotalDownloadBytes || null,
          reason: '缓存的模型文件非正式完整 ONNX 权重，暂未开放本地转写'
        };
      }

      try { await this._ensureWorkerInitialized(targetModelId); }
      catch (error) {
        return {ready:false,status:'runtime_unavailable',humanLabel:ENGINE_STATUS_LABELS.runtime_unavailable,
          modelId:targetModelId,modelVersion:st.modelVersion,bytes:st.bytes,reason:error.message};
      }
      if (this.state !== 'transcribing') this._setState('ready');
      return {
        ready: true,
        status: 'ready',
        humanLabel: ENGINE_STATUS_LABELS.ready,
        modelId: st.modelId,
        modelVersion: st.modelVersion,
        bytes: st.bytes,
        cacheHit: Boolean(st.cacheHit),
        estimatedDownloadBytes: manifest?.estimatedTotalDownloadBytes || st.bytes,
        displayName: manifest?.displayName || st.modelId
      };
    }

    const mappedStatus = st.status === 'needs_reinstall' ? 'needs_reinstall' : 'not_installed';
    this._setState(mappedStatus, st.reason);
    return {
      ready: false,
      status: mappedStatus,
      evicted: Boolean(st.evicted),
      humanLabel: ENGINE_STATUS_LABELS[mappedStatus] || mappedStatus,
      modelId: targetModelId,
      modelVersion: manifest?.version || null,
      bytes: 0,
      estimatedDownloadBytes: manifest?.estimatedTotalDownloadBytes || null,
      displayName: manifest?.displayName || targetModelId,
      reason: st.reason
    };
  }

  getInstallPromptMetadata(modelId = null) {
    const targetId = modelId || this.selectedModelId || 'paraformer-zh-small-int8';
    const manifest = this.installer.getManifest(targetId);
    const bytes = manifest?.estimatedTotalDownloadBytes;
    return {
      modelId: targetId,
      displayName: manifest?.displayName || targetId,
      officialModelName: manifest?.officialModelName || '',
      version: manifest?.version || '',
      estimatedDownloadBytes: Number.isFinite(bytes) && bytes > 0 ? bytes : null,
      estimatedDownloadLabel: Number.isFinite(bytes) && bytes > 0 ? formatModelBytes(bytes) : '未知（待获取清单）',
      purposeNotice: '用于在您的手机/电脑浏览器本地离线将答题录音转换为文字，录音无需上传第三方服务器。',
      trafficNotice: '首次下载建议在 Wi-Fi 环境下进行；如使用移动数据网络将消耗对应手机流量。下载完成后缓存在本机浏览器中复用（若系统清理缓存则需重新下载）。',
      cancellable: true
    };
  }

  async installWithUserGesture({
    modelId = null,
    userGestureConfirmed = false,
    secondModelConsentConfirmed = false,
    signal = null,
    onProgress = () => {}
  } = {}) {
    const support = await this.getSupport();
    if (!support.supported) {
      this._setState('unavailable', support.reason);
      const err = new Error(support.reason || '当前设备不支持本地语音识别组件');
      err.code = 'device_unsupported';
      throw err;
    }

    const targetId = modelId || this.selectedModelId || 'paraformer-zh-small-int8';
    if (!isProductionModelId(targetId)) {
      this._setState('unavailable', `拒绝安装非正式生产模型：${targetId}`);
      const err = new Error(`安全阻断：模型 ${targetId} 不属于正式生产模型清单，禁止安装模拟或测试组件`);
      err.code = 'forbidden_simulated_model';
      throw err;
    }

    this._setState('downloading');

    try {
      const res = await this.installer.installWithUserGesture({
        modelId: targetId,
        userGestureConfirmed,
        secondModelConsentConfirmed,
        signal,
        onProgress: (loaded, total, meta) => {
          onProgress(loaded, total, meta);
        }
      });
      this.selectedModelId = targetId;
      this.workerFailedPermanently = false;
      await this._ensureWorkerInitialized(targetId);
      this._setState('ready');
      return res;
    } catch (error) {
      const st = await this.installer.getInstallState(targetId);
      // A cached binary does not mean the native recognizer initialized.
      // Never report ready on a failed Worker/WASM startup.
      if (st.ready) {
        this._setState('runtime_unavailable', error.message);
      } else if (st.status === 'needs_reinstall') {
        this._setState('needs_reinstall', error.message);
      } else {
        this._setState('not_installed', error.message);
      }
      throw error;
    }
  }

  async _ensureWorkerInitialized(modelId) {
    if (this.workerFailedPermanently) {
      const err = new Error(this.lastError || '本地识别 Worker 先前发生内存不足或初始化异常，已停止自动重试以保护录像');
      err.code = 'worker_circuit_breaker_open';
      throw err;
    }

    const loaded = await this.installer.loadInstalledModelFiles(modelId);
    const manifest = this.installer.getManifest(loaded.modelId);
    const modelKey = `${loaded.modelId}@${loaded.modelVersion}`;

    if (
      this.#verifiedModelKey === modelKey &&
      this.#nativeInitialized &&
      (this.worker || this.useInProcessWorkerForTests)
    ) {
      return { loaded, manifest };
    }

    const resolvedRuntimeBaseUrl = (() => {
      const raw = String(this.runtimeBaseUrl || './models/sherpa-onnx/runtime').replace(/\/+$/, '') + '/';
      if (this.win?.location?.href && !/^(https?:|file:|blob:)/i.test(raw)) {
        try {
          return new URL(raw, this.win.location.href).href;
        } catch {}
      }
      return this.runtimeBaseUrl;
    })();

    const initPayload = {
      modelId: loaded.modelId,
      modelVersion: loaded.modelVersion,
      modelType: manifest?.modelType || 'paraformer',
      sampleRate: manifest?.sampleRate || 16000,
      files: loaded.files,
      runtimeBaseUrl: resolvedRuntimeBaseUrl,
      runtimeLoader: this.runtimeLoader,
      fetchImpl: this.win?.fetch ? this.win.fetch.bind(this.win) : globalThis.fetch,
      simulateOom: Boolean(this.simulateWorkerOomOnce)
    };
    this.simulateWorkerOomOnce = false;

    try {
      let initRes;
      if (this.useInProcessWorkerForTests) {
        initRes = await initializeWorkerModel(initPayload);
      } else {
        initRes = await this._sendWorkerRequest('INIT_MODEL', {
          modelId: initPayload.modelId,
          modelVersion: initPayload.modelVersion,
          modelType: initPayload.modelType,
          sampleRate: initPayload.sampleRate,
          files: initPayload.files,
          runtimeBaseUrl: initPayload.runtimeBaseUrl,
          simulateOom: initPayload.simulateOom
        });
      }

      // Native initialization grants no public result-minting capability.
      if (!initRes?.ready || initRes.engineMode !== 'sherpa-wasm-native') throw Object.assign(new Error('原生识别器初始化失败'), {code:'unverified_engine_mode'});
      this.#nativeInitialized = true;
      this.#verifiedModelKey = modelKey;
      return { loaded, manifest };
    } catch (error) {
      this.#nativeInitialized = false;
      this.#verifiedModelKey = null;
      await this.dispose();
      this.workerFailedPermanently = true;
      this._setState(
        error.code === 'sherpa_runtime_unavailable' ? 'runtime_unavailable' : 'unavailable',
        `暂未开放本地转写（${error.message}），已安全保留录像与待转写记录`
      );
      const wrapped = new Error(`本地识别引擎未就绪：${error.message}`);
      wrapped.code = error.code || 'worker_init_failed';
      throw wrapped;
    }
  }

  _createBrowserWorker() {
    if (this.workerFactory) return this.workerFactory();
    const WorkerCtor = this.win?.Worker || globalThis.Worker;
    if (typeof WorkerCtor !== 'function') {
      const err = new Error('当前环境不支持 Web Worker');
      err.code = 'worker_unsupported';
      throw err;
    }
    return new WorkerCtor(new URL('./sherpa-worker.js', import.meta.url), { type: 'module' });
  }

  _sendWorkerRequest(type, payload, timeoutMs = 30000) {
    if (!this.worker) {
      this.worker = this._createBrowserWorker();
      this.worker.onmessage = event => {
        const { requestId, ok, result, error, code } = event?.data || {};
        const pending = this.pendingWorkerRequests.get(requestId);
        if (!pending) return;
        this.pendingWorkerRequests.delete(requestId);
        clearTimeout(pending.timer);
        if (ok) {
          pending.resolve(result);
        } else {
          const err = new Error(error || 'Worker 执行失败');
          err.code = code || 'worker_error';
          pending.reject(err);
        }
      };
      this.worker.onerror = event => {
        const msg = event?.message || 'Web Worker 线程崩溃';
        for (const [, p] of this.pendingWorkerRequests.entries()) {
          clearTimeout(p.timer);
          const err = new Error(msg);
          err.code = 'worker_crash';
          p.reject(err);
        }
        this.pendingWorkerRequests.clear();
      };
    }

    const requestId = `req-${++this.requestSeq}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingWorkerRequests.delete(requestId);
        const err = new Error(`本地语音识别 Worker 响应超时（>${timeoutMs}ms）`);
        err.code = 'worker_timeout';
        reject(err);
      }, timeoutMs);
      this.pendingWorkerRequests.set(requestId, { resolve, reject, timer });
      try {
        this.worker.postMessage({ requestId, type, payload });
      } catch (err) {
        clearTimeout(timer);
        this.pendingWorkerRequests.delete(requestId);
        reject(err);
      }
    });
  }

  // Transcribe a single question's persisted, decodable audio Blob (TASK004 & TASK005 P1-01/P1-02)
  async transcribeQuestion({
    sessionId,
    questionId,
    audio,
    startMs = 0,
    endMs = 0,
    cropToWindow = false,
    modelId = null
  } = {}) {
    if (!sessionId || !questionId) {
      const err = new Error('transcribeQuestion 必须提供 sessionId 和 questionId');
      err.code = 'invalid_arguments';
      throw err;
    }

    const targetModelId = modelId || this.selectedModelId || 'paraformer-zh-small-int8';
    const installState = await this.getInstallState(targetModelId);
    if (!installState.ready) {
      const err = new Error(installState.reason || '暂未开放本地转写：本地语音识别模型或运行时尚未安装就绪');
      err.code = installState.status || 'model_not_ready';
      throw err;
    }

    // 1. Validate container & decode to 16kHz mono PCM (rejects fake byte-ratio sliced WebM!)
    const decodedAudio = await decodeQuestionAudioTo16kMono({
      audioBlob: audio,
      startMs,
      endMs,
      cropToWindow,
      targetSampleRate: 16000,
      customDecodeAudioData: this.customDecodeAudioData
    });

    // 2. Ensure Worker & native model are initialized and verified
    await this._ensureWorkerInitialized(targetModelId);
    if (!this.#nativeInitialized) {
      const err = new Error('安全阻断：本地识别器未通过原生 sherpa-wasm-native 校验，拒绝转写');
      err.code = 'unverified_engine_mode';
      throw err;
    }

    this._setState('transcribing');

    try {
      let workerRes;
      if (this.useInProcessWorkerForTests) {
        workerRes = await runWorkerTranscription({
          samples: decodedAudio.samples,
          sampleRate: decodedAudio.sampleRate,
          evidenceContext: {sessionId, questionId, audio, startMs:decodedAudio.interval[0], endMs:decodedAudio.interval[1], cropToWindow}
        });
      } else {
        workerRes = await this._sendWorkerRequest('TRANSCRIBE_PCM', {
          samples: decodedAudio.samples,
          sampleRate: decodedAudio.sampleRate,
          evidenceContext: {sessionId, questionId, audio, startMs:decodedAudio.interval[0], endMs:decodedAudio.interval[1], cropToWindow}
        });
      }

      this._setState('ready');

      if (workerRes?.engineMode !== 'sherpa-wasm-native') {
        const modeErr = new Error(`安全阻断：拒绝非原生识别器输出（engineMode=${workerRes?.engineMode || 'unknown'}）`);
        modeErr.code = 'unverified_engine_mode';
        throw modeErr;
      }

      const text = String(workerRes?.text || '').trim();
      if (!text) {
        const emptyErr = new Error(
          workerRes?.isSilenceOrPureTone
            ? '检测到静音或非人声纯音信号，本地模型未返回任何答题文本（按规则保留待转写状态，不生成答案、不判 0 分）'
            : '本地模型识别返回空文本（音频无有效语音或信噪比过低），按规则不判 0 分，保留待转写状态'
        );
        emptyErr.code = 'empty_transcription';
        emptyErr.audioDigest = decodedAudio.audioDigest;
        throw emptyErr;
      }

      const existingSlice = await getQuestionAudioSliceFromDB(sessionId, questionId);
      if (
        !existingSlice ||
        existingSlice.startMs !== decodedAudio.interval[0] ||
        existingSlice.endMs !== decodedAudio.interval[1]
      ) {
        await saveQuestionAudioSlice({
          sessionId,
          questionId,
          blob: audio,
          startMs: decodedAudio.interval[0],
          endMs: decodedAudio.interval[1],
          mimeType: audio.type,
          requireValidContainer: true
        });
      }
      const verifiedResult = await verifyLocalAsrResult(workerRes, {audioBlob:audio, sessionId, questionId, interval:decodedAudio.interval});
      if (!verifiedResult) throw Object.assign(new Error('识别结果缺少有效推理证据'), {code:'unverified_engine_mode'});
      return await persistLocalAsrResult(verifiedResult);

    } catch (error) {
      if (
        error.code === 'worker_crash' ||
        error.code === 'worker_timeout' ||
        error.code === 'worker_oom' ||
        error.code === 'unverified_engine_mode'
      ) {
        await this.dispose();
        this.workerFailedPermanently = true;
        this._setState('unavailable', error.message);
      } else {
        this._setState('ready');
      }
      throw error;
    }
  }

  async dispose() {
    this.#nativeInitialized = false;
    this.#verifiedModelKey = null;
    for (const [, p] of this.pendingWorkerRequests.entries()) {
      clearTimeout(p.timer);
      const err = new Error('Worker 已释放');
      err.code = 'worker_disposed';
      p.reject(err);
    }
    this.pendingWorkerRequests.clear();

    if (this.useInProcessWorkerForTests) {
      disposeWorkerModel();
    }

    if (this.worker) {
      try {
        this.worker.postMessage({ requestId: 'dispose', type: 'DISPOSE' });
      } catch {}
      try {
        if (typeof this.worker.terminate === 'function') {
          this.worker.terminate();
        }
      } catch {}
      this.worker = null;
    }
  }
}
