// Automatic Device Capability Probe & Model Selector (TASK004 Section 3.1, A07, A08, A09).
// - No manual model parameter tuning UI is exposed to the anchor.
// - Priority order:
//   1. Actual runnability & recording stability (WebAssembly + Worker + AudioContext + Storage headroom)
//   2. Mobile memory / load time constraints (avoids 239MB SenseVoice on <6GB RAM or mobile WebViews)
//   3. Real Chinese & TCL product term recognition benchmark quality (only when verified benchmark data exists)
//   4. Model download size
// - Never selects based solely on User-Agent!
// - Never downloads two models automatically; switching/downloading a second model requires explicit user consent & traffic prompt.

import { CANDIDATE_MODELS, verifyModelLicenseCompliance, formatModelBytes } from './model-manifest.js';

// Minimal valid WebAssembly module containing a 128-bit SIMD v128.const instruction
const WASM_SIMD_PROBE_BYTES = new Uint8Array([
  0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
  0x01, 0x05, 0x01, 0x60, 0x00, 0x01, 0x7b,
  0x03, 0x02, 0x01, 0x00,
  0x0a, 0x16, 0x01, 0x14, 0x00, 0xfd, 0x0c,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x0b
]);

export function probeWasmSimd(wasmGlobal = globalThis.WebAssembly) {
  if (!wasmGlobal || typeof wasmGlobal.validate !== 'function') return false;
  try {
    return Boolean(wasmGlobal.validate(WASM_SIMD_PROBE_BYTES));
  } catch {
    return false;
  }
}

export async function probeDeviceCapabilities(win = globalThis) {
  const nav = win?.navigator || {};
  const ua = String(nav.userAgent || '');
  const wasmSupported = typeof win?.WebAssembly === 'object' && typeof win?.WebAssembly?.instantiate === 'function';
  const wasmSimd = probeWasmSimd(win?.WebAssembly);
  const workerSupported = typeof win?.Worker === 'function';
  const audioDecodeSupported = Boolean(
    win?.AudioContext || win?.webkitAudioContext || win?.OfflineAudioContext || win?.webkitOfflineAudioContext
  );
  const cacheStorageSupported = typeof win?.caches === 'object' && win?.caches !== null;
  const indexedDbSupported = typeof win?.indexedDB === 'object' && win?.indexedDB !== null;
  const opfsSupported = typeof nav?.storage?.getDirectory === 'function';
  const sharedArrayBufferSupported = typeof win?.SharedArrayBuffer === 'function' && Boolean(win?.crossOriginIsolated);

  const hardwareConcurrency = Number.isFinite(nav.hardwareConcurrency) && nav.hardwareConcurrency > 0
    ? Number(nav.hardwareConcurrency)
    : null;
  const deviceMemoryGb = Number.isFinite(nav.deviceMemory) && nav.deviceMemory > 0
    ? Number(nav.deviceMemory)
    : null;

  let storageQuotaBytes = null;
  let storageUsageBytes = null;
  let storageAvailableBytes = null;
  if (typeof nav?.storage?.estimate === 'function') {
    try {
      const est = await nav.storage.estimate();
      if (Number.isFinite(est?.quota)) storageQuotaBytes = est.quota;
      if (Number.isFinite(est?.usage)) storageUsageBytes = est.usage;
      if (storageQuotaBytes !== null && storageUsageBytes !== null) {
        storageAvailableBytes = Math.max(0, storageQuotaBytes - storageUsageBytes);
      }
    } catch {
      // Graceful degradation when storage.estimate() fails or is restricted
    }
  }

  const isWeChat = /MicroMessenger/i.test(ua);
  const isIOS = /iPhone|iPad|iPod/i.test(ua);
  const isAndroid = /Android/i.test(ua);
  const isMobile = isWeChat || isIOS || isAndroid || /Mobile/i.test(ua);

  const reasons = [];
  if (!wasmSupported) reasons.push('当前浏览器不支持 WebAssembly');
  if (!workerSupported) reasons.push('当前浏览器不支持 Web Worker 后台线程，为保护摄像头录制不卡死已禁用同步大图推理');
  if (!cacheStorageSupported && !indexedDbSupported && !opfsSupported) {
    reasons.push('当前环境无可用本地模型缓存存储（Cache Storage / IndexedDB）');
  }

  // Classify hardware tier using multi-factor hardware & runtime signals (NEVER User-Agent alone!)
  let hardwareTier = 'standard';
  const lowMemorySignal = (deviceMemoryGb !== null && deviceMemoryGb < 4) ||
    (hardwareConcurrency !== null && hardwareConcurrency <= 4) ||
    (storageAvailableBytes !== null && storageAvailableBytes < 350 * 1024 * 1024);

  const highSpecSignal = wasmSimd &&
    deviceMemoryGb !== null && deviceMemoryGb >= 8 &&
    hardwareConcurrency !== null && hardwareConcurrency >= 8 &&
    (storageAvailableBytes === null || storageAvailableBytes >= 600 * 1024 * 1024);

  if (lowMemorySignal) {
    hardwareTier = 'low_memory';
  } else if (highSpecSignal) {
    hardwareTier = 'high_spec';
  }

  const supported = wasmSupported && workerSupported && (cacheStorageSupported || indexedDbSupported || opfsSupported);

  return {
    supported,
    reason: supported ? '支持 WebAssembly + Worker 本地离线语音转写架构' : reasons.join('；'),
    wasmSupported,
    wasmSimd,
    workerSupported,
    audioDecodeSupported,
    cacheStorageSupported,
    indexedDbSupported,
    opfsSupported,
    sharedArrayBufferSupported,
    hardwareConcurrency,
    deviceMemoryGb,
    storageQuotaBytes,
    storageUsageBytes,
    storageAvailableBytes,
    hardwareTier,
    environment: {
      isWeChat,
      isIOS,
      isAndroid,
      isMobile
    }
  };
}

export function selectOptimalModel({
  capabilities,
  manifestMap = CANDIDATE_MODELS,
  installedModelIds = [],
  benchmarkSummary = null
} = {}) {
  if (!capabilities?.supported) {
    return {
      supported: false,
      selectedModelId: null,
      selectedManifest: null,
      selectionReason: capabilities?.reason || '当前设备不支持本地 WASM 语音识别',
      selectionStage: 'unsupported',
      requiresSecondModelConsent: false
    };
  }

  const paraformer = manifestMap['paraformer-zh-small-int8'];
  const senseVoice = manifestMap['sense-voice-zh-small-int8'];

  const paraformerCompliance = paraformer ? verifyModelLicenseCompliance(paraformer) : { compliant: false };
  const senseVoiceCompliance = senseVoice ? verifyModelLicenseCompliance(senseVoice) : { compliant: false };

  // Check storage headroom for each model (require at least 1.5x download size to never threaten V4 recordings)
  const availBytes = capabilities.storageAvailableBytes;
  const canFitParaformer = Boolean(
    paraformer &&
    paraformerCompliance.compliant &&
    (availBytes === null || availBytes >= paraformer.estimatedTotalDownloadBytes * 1.5)
  );
  const canFitSenseVoice = Boolean(
    senseVoice &&
    senseVoiceCompliance.compliant &&
    (availBytes === null || availBytes >= senseVoice.estimatedTotalDownloadBytes * 1.8)
  );

  if (!canFitParaformer && !canFitSenseVoice) {
    const why = !paraformerCompliance.compliant && !senseVoiceCompliance.compliant
      ? '候选模型许可证状态均未通过合规校验'
      : '设备剩余可用存储空间不足，为保护已有练播录像与题库，已禁止下载大模型';
    return {
      supported: false,
      selectedModelId: null,
      selectedManifest: null,
      selectionReason: why,
      selectionStage: 'blocked_storage_or_license',
      requiresSecondModelConsent: false
    };
  }

  // Determine whether SenseVoice is genuinely proven superior AND safe for this device's hardware metrics
  // Rule (A08): Never select SenseVoice based on User-Agent alone; must verify hardwareConcurrency/deviceMemory/SIMD
  // AND verified benchmark superiority!
  const senseVoiceBenchmarkVerified = Boolean(
    benchmarkSummary &&
    benchmarkSummary.status === 'VERIFIED_REAL_BENCHMARK' &&
    benchmarkSummary.senseVoiceOutperformsParaformer === true &&
    Number.isFinite(benchmarkSummary.senseVoiceRtf) &&
    benchmarkSummary.senseVoiceRtf <= 0.35
  );

  const hardwareSupportsHeavyModel =
    capabilities.hardwareTier === 'high_spec' &&
    capabilities.wasmSimd === true &&
    (capabilities.deviceMemoryGb !== null && capabilities.deviceMemoryGb >= 6) &&
    (capabilities.hardwareConcurrency !== null && capabilities.hardwareConcurrency >= 6);

  let chosen = paraformer;
  let selectionStage = 'trial_candidate_pending_benchmark';
  let selectionReason =
    `默认选用轻量候选 ${paraformer?.displayName || 'Paraformer Small INT8'}（预计下载 ${formatModelBytes(paraformer?.estimatedTotalDownloadBytes)}）：兼顾手机端内存安全与录制稳定性（试验默认候选，待真机与同语料基准测试最终签署）。`;

  if (!canFitParaformer && canFitSenseVoice && hardwareSupportsHeavyModel) {
    chosen = senseVoice;
    selectionStage = senseVoiceBenchmarkVerified ? 'verified_benchmark_choice' : 'fallback_candidate';
    selectionReason = `因轻量模型不可用且当前设备具备高内存/多核 SIMD 能力，选用 ${senseVoice.displayName}。`;
  } else if (canFitSenseVoice && hardwareSupportsHeavyModel && senseVoiceBenchmarkVerified) {
    chosen = senseVoice;
    selectionStage = 'verified_benchmark_choice';
    selectionReason =
      `检测到高规格硬件（内存 ${capabilities.deviceMemoryGb}GB / ${capabilities.hardwareConcurrency} 核 / WASM SIMD）且经实测基准验证 SenseVoice 中文口语与产品词综合表现更优，自动匹配 ${senseVoice.displayName}。`;
  }

  const alreadyInstalled = new Set(installedModelIds || []);
  const otherModelInstalled = alreadyInstalled.size > 0 && !alreadyInstalled.has(chosen.modelId);

  return {
    supported: true,
    selectedModelId: chosen.modelId,
    selectedManifest: chosen,
    selectionStage,
    selectionReason,
    // Rule (Section 3.1 & A09): If another model is already installed, switching to a second model MUST obtain explicit user consent & traffic confirmation!
    requiresSecondModelConsent: otherModelInstalled,
    existingInstalledModelIds: Array.from(alreadyInstalled)
  };
}
