// Authoritative Model & Runtime Manifest for TCL Streamer V4.3 Local ASR (TASK004 & TASK005).
// All URLs, file compositions, sizes, SHA-256 digests, and license classifications are grounded in
// official k2-fsa/sherpa-onnx documentation, GitHub Releases, Hugging Face repositories, and FunASR MODEL_LICENSE.
// TASK005 P1-01 & P1-02:
// - Strictly forbids any synthetic/test model (such as `pipeline-verify-int8`) in the production manifest.
// - Enforces minimum production ONNX weight size (>= 10 MB) and vocabulary size (>= 500 tokens).

export const MODEL_MANIFEST_VERSION = '2026-11-01-task006-v1';

export const MIN_PRODUCTION_ONNX_BYTES = 10 * 1024 * 1024; // 10 MB minimum for real int8 ASR ONNX graph
export const MIN_PRODUCTION_VOCAB_SIZE = 500; // Real Mandarin ASR vocabularies have 8,404+ tokens

export const PRODUCTION_MODEL_IDS = new Set([
  'paraformer-zh-small-int8',
  'sense-voice-zh-small-int8'
]);

export function isProductionModelId(modelId) {
  // Do not consult the exported compatibility Set: Set.add() survives Object.freeze.
  return ['paraformer-zh-small-int8', 'sense-voice-zh-small-int8'].includes(String(modelId || '').trim());
}

export const TRUSTED_MODEL_ORIGINS = [
  'self', // Same-origin static assets (/models/sherpa-onnx/...)
  'https://github.com/k2-fsa/sherpa-onnx/',
  'https://release-assets.githubusercontent.com/',
  'https://huggingface.co/csukuangfj/'
];

export const SHERPA_WASM_RUNTIME_MANIFEST = {
  runtimeId: 'sherpa-onnx-wasm-simd-v1.12.23-vad-offline-asr',
  name: 'sherpa-onnx WebAssembly Offline ASR Runtime',
  version: '1.12.23',
  upstreamRepo: 'https://github.com/k2-fsa/sherpa-onnx',
  wasmDocsUrl: 'https://k2-fsa.github.io/sherpa/onnx/wasm/hf-spaces.html',
  license: 'Apache-2.0',
  licenseUrl: 'https://github.com/k2-fsa/sherpa-onnx/blob/master/LICENSE',
  commercialUsePermitted: true,
  redistributionPermitted: true,
  officialReleaseArchiveUrl: 'https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.12.23/sherpa-onnx-wasm-simd-1.12.23-vad-asr-zh_en_ja_ko_cantonese-sense_voice_small.tar.bz2',
  officialReleaseArchiveSha256: 'f01fdff421bdd6e6c94c8876b6d51e547aa818f549dd93d5805660a59a8bba04',
  officialReleaseArchiveBytes: 165754360,
  provenanceDocument: 'docs/ASSET_PROVENANCE_TASK006.md',
  requiredNativeExports: ['_SherpaOnnxCreateOfflineRecognizer', '_SherpaOnnxDecodeOfflineStream'],
  adapterPreload: { start: 48, end: 4963, sha256: '24ab1e99bcccf984476938249b7a0c08d82a9d205b544fe79ee434d833cf571a' },
  minWasmBytes: 1024 * 1024, // >= 1 MB for real compiled sherpa-onnx WASM binary
  files: [
    {
      name: 'sherpa-onnx-asr.js',
      role: 'js-capi-wrapper',
      relativeUrl: './models/sherpa-onnx/runtime/sherpa-onnx-asr.js',
      expectedBytes: 45335,
      sha256: 'f9b7d3813a2a982184e0d2314864ffbd9a766c642fcfc1845f853bafa60afd5a',
      status: 'PINNED_FROM_VERIFIED_OFFICIAL_RELEASE_ARCHIVE'
    },
    {
      name: 'sherpa-onnx-wasm-main-vad-asr.js',
      role: 'emscripten-glue',
      relativeUrl: './models/sherpa-onnx/runtime/sherpa-onnx-wasm-main-vad-asr.js',
      expectedBytes: 95318,
      sha256: '24313a1a8550add3673c72a636234ecd768c97d13ba989b82e6f0951aeb8376d',
      status: 'PINNED_FROM_VERIFIED_OFFICIAL_RELEASE_ARCHIVE'
    },
    {
      name: 'sherpa-onnx-wasm-main-vad-asr.wasm',
      role: 'wasm-binary',
      relativeUrl: './models/sherpa-onnx/runtime/sherpa-onnx-wasm-main-vad-asr.wasm',
      expectedBytes: 11642324,
      sha256: '0289717bcfcc2e728179c303c5bac3bbac426dcabe53ed0ed1fe9ab942ae32e9',
      status: 'PINNED_FROM_VERIFIED_OFFICIAL_RELEASE_ARCHIVE'
    }
  ]
};

export const CANDIDATE_MODELS = {
  'paraformer-zh-small-int8': {
    modelId: 'paraformer-zh-small-int8',
    displayName: '中文 Paraformer Small INT8（保守初始轻量候选）',
    officialModelName: 'csukuangfj/sherpa-onnx-paraformer-zh-small-2024-03-09',
    modelType: 'paraformer',
    version: '2024-03-09-int8',
    hfRevision: '5e2d6883a5b9c3bd7bdf39d7ddb55c732e78109e',
    officialDocsUrl: 'https://k2-fsa.github.io/sherpa/onnx/pretrained_models/offline-paraformer/paraformer-models.html',
    officialRepoUrl: 'https://huggingface.co/csukuangfj/sherpa-onnx-paraformer-zh-small-2024-03-09/tree/5e2d6883a5b9c3bd7bdf39d7ddb55c732e78109e',
    officialReleaseArchiveUrl: 'https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-paraformer-zh-small-2024-03-09.tar.bz2',
    upstreamConversionSourceUrl: 'https://www.modelscope.cn/models/crazyant/speech_paraformer_asr_nat-zh-cn-16k-common-vocab8358-onnx/summary',
    languages: ['zh-CN', 'en'],
    sampleRate: 16000,
    channels: 1,
    sampleFormat: 'int16_or_float32_mono',
    featureDim: 80,
    supportsTimestamps: false,
    selectionRole: 'conservative_initial_lightweight_default',
    selectionNote: '基于包体积与移动端内存占用的保守初始候选；未经相同真人口播语料与同设备实测对比前，严禁宣称为识别准确率最优模型。',
    estimatedTotalDownloadBytes: 81904027, // 81,828,675 B model + 75,352 B tokens
    estimatedArchiveBytes: 77900000, // .tar.bz2 (~77.9 MB)
    estimatedRamMb: 240,
    minRecommendedDeviceMemoryGb: 2,
    minRecommendedCores: 2,
    licenseInfo: {
      runtimeLicense: 'Apache-2.0 (k2-fsa/sherpa-onnx)',
      weightsLicense: 'FunASR Model Open Source License Agreement v1.1 / Apache-2.0 (Upstream ModelScope/FunASR Paraformer)',
      licenseUrl: 'https://github.com/modelscope/FunASR/blob/main/MODEL_LICENSE',
      standaloneLicenseFileInHfRepo: false,
      commercialUsePermitted: true,
      redistributionConditions: '需保留阿里巴巴达摩院 FunASR / ModelScope 与 sherpa-onnx 出处、作者署名及模型名称（FunASR MODEL_LICENSE v1.1 第 2.2 条）；HF 转换仓库根目录未单独附带 LICENSE 文件，生产环境分发前需法务确认归属声明。',
      complianceStatus: 'CONDITIONAL_ATTRIBUTION_REQUIRED',
      bundleInSourceZipAllowed: false
    },
    files: [
      {
        name: 'model.int8.onnx',
        relativeUrl: './models/sherpa-onnx/paraformer-zh-small-int8/model.int8.onnx',
        upstreamUrl: 'https://huggingface.co/csukuangfj/sherpa-onnx-paraformer-zh-small-2024-03-09/resolve/5e2d6883a5b9c3bd7bdf39d7ddb55c732e78109e/model.int8.onnx',
        expectedBytes: 81828675,
        minBytes: MIN_PRODUCTION_ONNX_BYTES,
        // Fixed-revision upstream LFS SHA-256; see docs/ASSET_PROVENANCE_TASK006.md.
        sha256: '3ef6c19369b912f7caf3cef8e545c5ccd1a33d9d7ec792a46668dc41c4b229ec',
        hashStatus: 'PINNED_FROM_UPSTREAM_FIXED_REVISION'
      },
      {
        name: 'tokens.txt',
        relativeUrl: './models/sherpa-onnx/paraformer-zh-small-int8/tokens.txt',
        upstreamUrl: 'https://huggingface.co/csukuangfj/sherpa-onnx-paraformer-zh-small-2024-03-09/resolve/5e2d6883a5b9c3bd7bdf39d7ddb55c732e78109e/tokens.txt',
        expectedBytes: 75352,
        minBytes: 10240,
        sha256: '4b2d964e18b9cf139b473003b6698fb2ed9a2a5ec55b93daa677b28f578897aa',
        hashStatus: 'COMPUTED_FROM_UPSTREAM_FIXED_REVISION'
      }
    ]
  },

  'sense-voice-zh-small-int8': {
    modelId: 'sense-voice-zh-small-int8',
    displayName: 'SenseVoice-Small INT8（多语言/口语高配候选）',
    officialModelName: 'csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17',
    modelType: 'sense_voice',
    version: '2024-07-17-int8',
    hfRevision: '2365baeacb507f821a0c8120fcee3d484dba7a07',
    upstreamWeightsRevision: '3847d57b6bdf2dd8875cb1508d2af43d80a16bf7',
    officialDocsUrl: 'https://k2-fsa.github.io/sherpa/onnx/sense-voice/pretrained.html',
    officialRepoUrl: 'https://huggingface.co/csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17/tree/2365baeacb507f821a0c8120fcee3d484dba7a07',
    officialReleaseArchiveUrl: 'https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17.tar.bz2',
    officialReleaseArchiveBytes: 163002883,
    officialReleaseArchiveSha256: '7d1efa2138a65b0b488df37f8b89e3d91a60676e416f515b952358d83dfd347e',
    upstreamConversionSourceUrl: 'https://huggingface.co/FunAudioLLM/SenseVoiceSmall',
    languages: ['zh', 'yue', 'en', 'ja', 'ko'],
    sampleRate: 16000,
    channels: 1,
    sampleFormat: 'int16_or_float32_mono',
    featureDim: 80,
    supportsTimestamps: true,
    useItnDefault: true,
    selectionRole: 'high_spec_optional_candidate',
    selectionNote: '权重文件达 239 MB，Android 实测峰值内存约 570–773 MB（k2-fsa/sherpa-onnx#4056）；仅在高内存桌面或高端设备上、经真实语料基准证明更优且获用户二次授权流量后可选用。',
    estimatedTotalDownloadBytes: 239549735, // 239,233,841 B model + 315,894 B tokens
    estimatedArchiveBytes: 163002883,
    estimatedRamMb: 650,
    minRecommendedDeviceMemoryGb: 6,
    minRecommendedCores: 6,
    licenseInfo: {
      runtimeLicense: 'Apache-2.0 (k2-fsa/sherpa-onnx) + MIT (QwenAudio/SenseVoice code)',
      weightsLicense: 'FunASR Model Open Source License Agreement Version 1.1',
      licenseUrl: 'https://github.com/modelscope/FunASR/blob/main/MODEL_LICENSE',
      clarificationIssueUrl: 'https://github.com/QwenAudio/SenseVoice#license',
      standaloneLicenseFileInHfRepo: true,
      commercialUsePermitted: true,
      redistributionConditions: '必须遵守 FunASR 模型开源协议 v1.1 第 2.2 条（注明阿里巴巴 FunAudioLLM/FunASR 出处、作者信息并保留 SenseVoiceSmall 模型名称）；第 3 条为免责声明（见 QwenAudio/SenseVoice 官方澄清），第三方 ONNX 转换产物分发需同步附上协议全文与归属说明。',
      complianceStatus: 'CONDITIONAL_ATTRIBUTION_REQUIRED',
      bundleInSourceZipAllowed: false
    },
    files: [
      {
        name: 'model.int8.onnx',
        relativeUrl: './models/sherpa-onnx/sense-voice-zh-small-int8/model.int8.onnx',
        upstreamUrl: 'https://huggingface.co/csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17/resolve/2365baeacb507f821a0c8120fcee3d484dba7a07/model.int8.onnx',
        expectedBytes: 239233841,
        minBytes: MIN_PRODUCTION_ONNX_BYTES,
        sha256: 'c71f0ce00bec95b07744e116345e33d8cbbe08cef896382cf907bf4b51a2cd51',
        hashStatus: 'VERIFIED_FROM_UPSTREAM_RECORD'
      },
      {
        name: 'tokens.txt',
        relativeUrl: './models/sherpa-onnx/sense-voice-zh-small-int8/tokens.txt',
        upstreamUrl: 'https://huggingface.co/csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17/resolve/2365baeacb507f821a0c8120fcee3d484dba7a07/tokens.txt',
        expectedBytes: 315894,
        minBytes: 10240,
        sha256: 'f449eb28dc567533d7fa59be34e2abca8784f771850c78a47fb731a31429a1dc',
        hashStatus: 'VERIFIED_FROM_UPSTREAM_RECORD'
      }
    ]
  }
};

export function getModelManifest(modelId, customManifestMap = null) {
  const registry = customManifestMap || CANDIDATE_MODELS;
  return registry[modelId] || null;
}

export function listCandidateModels(customManifestMap = null) {
  const registry = customManifestMap || CANDIDATE_MODELS;
  return Object.values(registry);
}

// Supply-chain security check (Section 8.3 & A30):
// Blocks arbitrary script URLs, path traversal, unverified mirrors, and non-compliant licenses.
export function validateModelSourceUrl(urlStr, { baseOrigin = 'http://127.0.0.1', allowedOrigins = TRUSTED_MODEL_ORIGINS } = {}) {
  const raw = String(urlStr || '').trim();
  if (!raw) {
    return { valid: false, reason: '模型资源 URL 不能为空' };
  }
  if (raw.includes('..') || raw.includes('\\')) {
    return { valid: false, reason: `安全阻断：模型路径包含非法路径穿越字符 (${raw})` };
  }
  if (/^(javascript|data|file|vbscript|blob):/i.test(raw)) {
    return { valid: false, reason: `安全阻断：禁止使用非受控协议加载模型 (${raw})` };
  }

  let parsed;
  try {
    parsed = new URL(raw, baseOrigin);
  } catch {
    return { valid: false, reason: `无效的模型 URL：${raw}` };
  }

  if (parsed.pathname.includes('..')) {
    return { valid: false, reason: `安全阻断：模型 URL 路径穿越被拒绝 (${parsed.pathname})` };
  }

  const base = new URL(baseOrigin);
  if (parsed.origin === base.origin && allowedOrigins.includes('self')) {
    return { valid: true, resolvedUrl: parsed.href, isSameOrigin: true };
  }

  if (parsed.protocol !== 'https:') {
    return { valid: false, reason: `安全阻断：跨源模型下载必须使用 HTTPS (${parsed.href})` };
  }

  const isTrusted = allowedOrigins.some(prefix => prefix !== 'self' && parsed.href.startsWith(prefix));
  if (!isTrusted) {
    return {
      valid: false,
      reason: `供应链安全阻断：拒绝从未授权第三方镜像下载模型 (${parsed.origin})`
    };
  }

  return { valid: true, resolvedUrl: parsed.href, isSameOrigin: false };
}

export function verifyModelLicenseCompliance(modelManifest) {
  if (!modelManifest || typeof modelManifest !== 'object') {
    return { compliant: false, reason: '缺少模型清单定义' };
  }
  const lic = modelManifest.licenseInfo;
  if (!lic || !lic.runtimeLicense || !lic.weightsLicense || !lic.licenseUrl) {
    return {
      compliant: false,
      reason: `模型 ${modelManifest.modelId || ''} 缺少完整的运行库或许可证出处记录，按合规门禁拒绝启用`
    };
  }
  if (lic.commercialUsePermitted !== true || lic.complianceStatus === 'NON_COMMERCIAL_BLOCKED') {
    return {
      compliant: false,
      reason: `模型 ${modelManifest.modelId} 许可证不支持商业训练场景或状态为阻断（${lic.complianceStatus || '未知'}），已停止默认加载`
    };
  }
  return {
    compliant: true,
    runtimeLicense: lic.runtimeLicense,
    weightsLicense: lic.weightsLicense,
    licenseUrl: lic.licenseUrl,
    redistributionConditions: lic.redistributionConditions
  };
}

export function formatModelBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '大小待核实';
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  if (bytes >= 1024) {
    return `${(bytes / 1024).toFixed(1)} KB`;
  }
  return `${bytes} B`;
}

// Trusted production constants are immutable. Test fixtures must use an explicit
// separate manifest object instead of editing these defaults at runtime.
function deepFreezeManifest(value) {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.values(value).forEach(deepFreezeManifest);
    Object.freeze(value);
  }
  return value;
}
deepFreezeManifest(SHERPA_WASM_RUNTIME_MANIFEST);
deepFreezeManifest(CANDIDATE_MODELS);
deepFreezeManifest(TRUSTED_MODEL_ORIGINS);
