// Lossless IndexedDB storage upgrade from V4 'live-practice-v1' (v1 -> v2)
// Preserves legacy stores ('settings', 'sessions', 'chunks') without wiping old data.
// Adds 'question_sets', 'question_snapshots', 'transcripts', 'scoring_queue', 'upload_queue', 'audit_logs'.
//
// TASK003 P1-B & TASK004 Section 5 Fixes:
// 1. Strictly eliminates TASK002's broken `first 256 bytes + proportional byte slice` WebM fabrication!
// 2. Validates container structure in saveQuestionAudioSlice & getQuestionAudioSliceFromDB.
// 3. When standalone per-question slice is missing, recoverQuestionAudioSlice ONLY recovers if the full recording
//    can be genuinely decoded (e.g., RIFF/WAV PCM slicing or verified AudioContext / FFmpeg demuxing into valid audio/wav);
//    otherwise it fails closed (returns null, keeping the full recording and marking transcription_pending).
// 4. Explicit error reporting on audio slice persistence failure (never silently swallowed by empty catch) (P1-B, A15).

import { uid } from '../training/core.js';
import {
  validateAudioContainerBytes,
  decodeWavBytesToMonoFloat32,
  slicePcmWindow,
  encodeMonoPcmToWavBytes,
  sha256HexFromBytes
} from '../speech/local-asr/audio-preprocess.js';

export const DB_NAME = 'tcl-r7ab-v09-r7-sandbox';
export const DB_VERSION = 2;

const ALL_STORES = [
  'settings',
  'sessions',
  'chunks',
  'question_sets',
  'question_snapshots',
  'transcripts',
  'scoring_queue',
  'upload_queue',
  'audit_logs'
];

// In-memory store for Node test environments without native IndexedDB
const memoryStores = new Map(ALL_STORES.map(name => [name, new Map()]));
let forceMemoryFallback = typeof globalThis.indexedDB === 'undefined';
let simulateNextSlicePersistFailure = false;

export function useMemoryStorageForTests(enable = true) {
  forceMemoryFallback = Boolean(enable);
}

export function clearMemoryStorageForTests() {
  for (const map of memoryStores.values()) map.clear();
  simulateNextSlicePersistFailure = false;
}

export function setSimulateSlicePersistFailureForTests(enable = true) {
  simulateNextSlicePersistFailure = Boolean(enable);
}

let dbPromise;

export function upgradeDatabaseSchema(db, oldVersion) {
  if (oldVersion < 1) {
    if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings');
    if (!db.objectStoreNames.contains('sessions')) db.createObjectStore('sessions', { keyPath: 'id' });
    if (!db.objectStoreNames.contains('chunks')) {
      const chunks = db.createObjectStore('chunks', { keyPath: 'id' });
      chunks.createIndex('sessionId', 'sessionId');
      chunks.createIndex('segmentId', 'segmentId');
    }
  }
  if (oldVersion < 2) {
    // Non-destructive V4.3 upgrade: never delete or recreate existing 'settings', 'sessions', or 'chunks'!
    if (!db.objectStoreNames.contains('question_sets')) {
      const qs = db.createObjectStore('question_sets', { keyPath: 'id' });
      qs.createIndex('updatedAt', 'updatedAt');
      qs.createIndex('title', 'title');
    }
    if (!db.objectStoreNames.contains('question_snapshots')) {
      const snap = db.createObjectStore('question_snapshots', { keyPath: 'id' });
      snap.createIndex('questionSetId', 'questionSetId');
      snap.createIndex('hash', 'hash');
    }
    if (!db.objectStoreNames.contains('transcripts')) {
      const tr = db.createObjectStore('transcripts', { keyPath: 'id' });
      tr.createIndex('sessionId', 'sessionId');
      tr.createIndex('questionId', 'questionId');
    }
    if (!db.objectStoreNames.contains('scoring_queue')) {
      const sq = db.createObjectStore('scoring_queue', { keyPath: 'id' });
      sq.createIndex('sessionId', 'sessionId');
      sq.createIndex('idempotencyKey', 'idempotencyKey');
      sq.createIndex('status', 'status');
    }
    if (!db.objectStoreNames.contains('upload_queue')) {
      const uq = db.createObjectStore('upload_queue', { keyPath: 'id' });
      uq.createIndex('sessionId', 'sessionId');
      uq.createIndex('status', 'status');
    }
    if (!db.objectStoreNames.contains('audit_logs')) {
      const al = db.createObjectStore('audit_logs', { keyPath: 'id' });
      al.createIndex('sessionId', 'sessionId');
      al.createIndex('createdAt', 'createdAt');
    }
  }
}

export function openDB() {
  if (forceMemoryFallback) return Promise.resolve({ isMemoryFallback: true });
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      let request;
      try {
        request = indexedDB.open(DB_NAME, DB_VERSION);
      } catch (err) {
        forceMemoryFallback = true;
        dbPromise = null;
        resolve({ isMemoryFallback: true });
        return;
      }
      request.onupgradeneeded = event => {
        const db = request.result;
        upgradeDatabaseSchema(db, event.oldVersion || 0);
      };
      request.onsuccess = () => {
        request.result.onversionchange = () => {
          request.result.close();
          dbPromise = null;
        };
        resolve(request.result);
      };
      request.onerror = () => {
        const err = request.error;
        if (err?.name === 'SecurityError' || err?.name === 'InvalidStateError') {
          forceMemoryFallback = true;
          dbPromise = null;
          resolve({ isMemoryFallback: true });
          return;
        }
        dbPromise = null;
        reject(err);
      };
      request.onblocked = () => {
        dbPromise = null;
        reject(new Error('数据库升级被其他标签页阻挡，请关闭其他练播房标签页后重试'));
      };
    });
  }
  return dbPromise;
}

async function transaction(storeNames, mode, action) {
  const db = await openDB();
  if (db.isMemoryFallback) {
    return action({
      isMemoryFallback: true,
      objectStore(name) {
        const map = memoryStores.get(name);
        return {
          put(val, key) {
            const k = key !== undefined ? key : val?.id;
            map.set(k, structuredClone(val));
          },
          get(key) {
            return { result: structuredClone(map.get(key)) };
          },
          getAll() {
            return { result: Array.from(map.values()).map(v => structuredClone(v)) };
          },
          delete(key) {
            map.delete(key);
          }
        };
      }
    });
  }
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeNames, mode);
    let result;
    tx.oncomplete = () => resolve(result);
    tx.onerror = tx.onabort = () => reject(tx.error || new Error('本地存储事务失败'));
    try {
      result = action(tx);
    } catch (error) {
      tx.abort();
      reject(error);
    }
  });
}

export async function put(store, value, key) {
  return transaction([store], 'readwrite', tx => {
    if (key !== undefined) tx.objectStore(store).put(value, key);
    else tx.objectStore(store).put(value);
  });
}

export async function get(store, key) {
  let request;
  await transaction([store], 'readonly', tx => {
    request = tx.objectStore(store).get(key);
  });
  return request.result;
}

export async function getAll(store) {
  let request;
  await transaction([store], 'readonly', tx => {
    request = tx.objectStore(store).getAll();
  });
  return request.result || [];
}

export async function remove(store, key) {
  return transaction([store], 'readwrite', tx => {
    tx.objectStore(store).delete(key);
  });
}

export async function allSessions() {
  const list = await getAll('sessions');
  return list.sort((a, b) => (b.startedAt || 0) - (a.startedAt || 0));
}

export async function allQuestionSets() {
  const list = await getAll('question_sets');
  return list.sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')));
}

export async function saveQuestionSet(questionSet) {
  const clean = {
    id: questionSet.id,
    title: questionSet.title,
    sourceFileName: questionSet.sourceFileName,
    version: questionSet.version,
    hash: questionSet.hash,
    createdAt: questionSet.createdAt,
    updatedAt: questionSet.updatedAt,
    summary: questionSet.summary,
    questions: (questionSet.questions || []).map(q => ({
      id: q.id,
      question_text: q.question_text,
      reference_answer: q.reference_answer,
      question_type: q.question_type,
      status: q.status,
      status_reason: q.status_reason,
      source_locator: q.source_locator
    }))
  };
  await put('question_sets', clean);
  return clean;
}

export async function createQuestionSetSnapshot(questionSet) {
  const snapshot = {
    id: `${questionSet.id}@v${questionSet.version}-${questionSet.hash.slice(0, 8)}`,
    questionSetId: questionSet.id,
    title: questionSet.title,
    version: questionSet.version,
    hash: questionSet.hash,
    saved_at: new Date().toISOString(),
    questions: structuredClone(questionSet.questions || [])
  };
  await put('question_snapshots', snapshot);
  return snapshot;
}

// ============================================================================
// TASK003 P1-B & TASK004 Section 5 / A14 / A15:
// Persist and recover authentic, decodable per-question audio slices across page reloads.
// - Explicit error throwing/reporting when persistence fails (never swallowed by empty catch!).
// - Never fabricates `256-byte WebM header + byte ratio slice`!
// ============================================================================

export async function saveQuestionAudioSlice({
  sessionId,
  questionId,
  blob,
  startMs = 0,
  endMs = 0,
  mimeType = '',
  requireValidContainer = false
} = {}) {
  if (!sessionId || !questionId || !blob) {
    const err = new Error('保存单题音频分片失败：缺少 sessionId、questionId 或音频数据');
    err.code = 'slice_invalid_args';
    throw err;
  }

  if (simulateNextSlicePersistFailure) {
    simulateNextSlicePersistFailure = false;
    const quotaErr = new Error('QuotaExceededError: 本地存储空间不足，无法写入单题音频分片');
    quotaErr.name = 'QuotaExceededError';
    quotaErr.code = 'slice_persist_failed';
    throw quotaErr;
  }

  let bytes;
  if (blob instanceof Uint8Array) {
    bytes = blob;
  } else if (typeof blob.arrayBuffer === 'function') {
    bytes = new Uint8Array(await blob.arrayBuffer());
  } else {
    const err = new Error('保存单题音频分片失败：不支持的音频数据类型');
    err.code = 'slice_unsupported_blob';
    throw err;
  }

  if (!bytes.byteLength) {
    const err = new Error('保存单题音频分片失败：音频字节长度为 0');
    err.code = 'slice_empty_bytes';
    throw err;
  }

  const resolvedMime = String(mimeType || blob.type || 'audio/webm').split(';')[0].trim().toLowerCase();
  const containerCheck = validateAudioContainerBytes(bytes, resolvedMime);
  if (requireValidContainer && !containerCheck.valid) {
    const err = new Error(containerCheck.reason || '单题音频容器无效，拒绝持久化伪造分片');
    err.code = 'slice_invalid_container';
    throw err;
  }

  const audioDigest = await sha256HexFromBytes(bytes);
  const record = {
    id: `audio-slice:${sessionId}:${questionId}`,
    kind: 'question_audio_slice',
    sessionId,
    questionId,
    mimeType: resolvedMime.startsWith('audio/') ? resolvedMime : (containerCheck.container === 'wav' ? 'audio/wav' : 'audio/webm'),
    container: containerCheck.container,
    containerValid: containerCheck.valid,
    startMs,
    endMs,
    byteLength: bytes.byteLength,
    audioDigest,
    audioBytes: bytes,
    savedAt: new Date().toISOString()
  };

  await put('transcripts', record);
  return record;
}

export async function getQuestionAudioSliceFromDB(sessionId, questionId) {
  if (!sessionId || !questionId) return null;
  const rec = await get('transcripts', `audio-slice:${sessionId}:${questionId}`);
  if (!rec || !rec.audioBytes) return null;
  const bytes = rec.audioBytes instanceof Uint8Array
    ? rec.audioBytes
    : new Uint8Array(Object.values(rec.audioBytes));
  if (!bytes.byteLength) return null;

  const mime = rec.mimeType || 'audio/webm';
  const blob = new Blob([bytes], { type: mime });
  return {
    id: rec.id,
    sessionId: rec.sessionId,
    questionId: rec.questionId,
    mimeType: mime,
    container: rec.container || null,
    containerValid: rec.containerValid,
    startMs: rec.startMs ?? 0,
    endMs: rec.endMs ?? 0,
    byteLength: bytes.byteLength,
    audioDigest: rec.audioDigest || null,
    blob
  };
}

// TASK003 P1-B & TASK004 Section 5.2 Fix:
// Recover a question's playable audio slice across page refreshes WITHOUT ever using proportional byte slicing!
// 1. Primary path: return persisted standalone per-question audio slice if present and valid.
// 2. Secondary path: if the full session recording is a valid RIFF/WAV container OR if a verified audio demuxer/decoder
//    (`decodeFullMediaToQuestionWav`) is provided/available, decode and extract the exact [startMs, endMs] PCM window
//    and package it into a standard RIFF `audio/wav` container.
// 3. Fail-closed path: if the full recording is an opaque/un-demuxed WebM/MP4 without a verified decoder, return `null`
//    so the session safely stays in `transcription_pending` and retains the original full video recording!
export async function recoverQuestionAudioSlice(sessionRecord, questionId, {
  decodeFullMediaToQuestionWav = null
} = {}) {
  const sessionId = sessionRecord?.session_id || sessionRecord?.id;
  if (!sessionId || !questionId) return null;

  // 1. Prefer dedicated persisted per-question audio slice
  const direct = await getQuestionAudioSliceFromDB(sessionId, questionId);
  if (direct && direct.blob?.size > 0) {
    const rawBytes = new Uint8Array(await direct.blob.arrayBuffer());
    const check = validateAudioContainerBytes(rawBytes, direct.mimeType);
    if (check.valid) {
      return direct;
    }
  }

  // 2. Attempt verified time-window extraction from the saved session recording ONLY via true decoding/demuxing
  const q = (sessionRecord?.questions || []).find(item => (item.question_id || item.id) === questionId);
  const segment = (sessionRecord?.segments || [])[0];
  if (!q || !segment?.id) return null;

  const fullBlob = await segmentBlob(segment);
  if (!fullBlob || !fullBlob.size) return null;

  const totalDurationMs = Math.max(1, Number(segment.durationMs || sessionRecord.totalMs || 1000));
  const startMs = Math.max(0, Number(q.answer_start_ms ?? q.barrage_start_ms ?? 0));
  const endMs = Math.max(startMs + 100, Number(q.answer_end_ms ?? q.barrage_end_ms ?? totalDurationMs));

  const fullBytes = new Uint8Array(await fullBlob.arrayBuffer());
  const fullCheck = validateAudioContainerBytes(fullBytes, fullBlob.type || segment.mime || '');

  // Path 2A: If full recording is a valid RIFF/WAVE container, slice on exact sample boundaries and wrap in valid RIFF header
  if (fullCheck.valid && fullCheck.container === 'wav') {
    try {
      const decoded = decodeWavBytesToMonoFloat32(fullBytes);
      const windowedPcm = slicePcmWindow(decoded.samples, decoded.sampleRate, startMs, endMs);
      if (!windowedPcm.length) return null;
      const wavBytes = encodeMonoPcmToWavBytes(windowedPcm, decoded.sampleRate);
      const wavBlob = new Blob([wavBytes], { type: 'audio/wav' });
      await saveQuestionAudioSlice({
        sessionId,
        questionId,
        blob: wavBlob,
        startMs,
        endMs,
        mimeType: 'audio/wav',
        requireValidContainer: true
      });
      return await getQuestionAudioSliceFromDB(sessionId, questionId);
    } catch {
      return null;
    }
  }

  // Path 2B: If a verified media decoder/demuxer (e.g., Web Audio decodeAudioData in browser or FFmpeg in Node test) is available
  const decoderFn = decodeFullMediaToQuestionWav || (typeof globalThis.AudioContext !== 'undefined' || typeof globalThis.OfflineAudioContext !== 'undefined'
    ? async (rawBytes, sMs, eMs) => {
        const AudioCtx = globalThis.OfflineAudioContext || globalThis.AudioContext || globalThis.webkitAudioContext;
        if (!AudioCtx) return null;
        const ctx = (AudioCtx === globalThis.OfflineAudioContext)
          ? new AudioCtx(1, 16000, 16000)
          : new AudioCtx();
        try {
          const audioBuf = await ctx.decodeAudioData(rawBytes.buffer.slice(rawBytes.byteOffset, rawBytes.byteOffset + rawBytes.byteLength));
          const sr = audioBuf.sampleRate;
          const chCount = Math.max(1, audioBuf.numberOfChannels || 1);
          const mono = new Float32Array(audioBuf.length);
          for (let c = 0; c < chCount; c++) {
            const ch = audioBuf.getChannelData(c);
            for (let i = 0; i < audioBuf.length; i++) mono[i] += ch[i] / chCount;
          }
          const winSamples = slicePcmWindow(mono, sr, sMs, eMs);
          if (!winSamples.length) return null;
          return encodeMonoPcmToWavBytes(winSamples, sr);
        } finally {
          if (typeof ctx.close === 'function') {
            try { await ctx.close(); } catch {}
          }
        }
      }
    : null);

  if (typeof decoderFn === 'function') {
    try {
      const wavBytes = await decoderFn(fullBytes, startMs, endMs);
      if (wavBytes && wavBytes.byteLength > 44) {
        const verifyWav = validateAudioContainerBytes(wavBytes, 'audio/wav');
        if (verifyWav.valid && verifyWav.container === 'wav') {
          const wavBlob = new Blob([wavBytes], { type: 'audio/wav' });
          await saveQuestionAudioSlice({
            sessionId,
            questionId,
            blob: wavBlob,
            startMs,
            endMs,
            mimeType: 'audio/wav',
            requireValidContainer: true
          });
          return await getQuestionAudioSliceFromDB(sessionId, questionId);
        }
      }
    } catch {
      // Decoder failed -> fall through to fail-closed return null
    }
  }

  // Fail-closed: NEVER slice WebM by byte ratio or prepend 256-byte headers!
  return null;
}

export async function deleteQuestionAudioSlice(sessionId, questionId) {
  if (!sessionId || !questionId) return;
  await remove('transcripts', `audio-slice:${sessionId}:${questionId}`);
}

export async function deleteSessionAudioSlices(sessionId) {
  if (!sessionId) return;
  const all = await getAll('transcripts');
  for (const item of all) {
    if (item.sessionId === sessionId && item.kind === 'question_audio_slice') {
      await remove('transcripts', item.id);
    }
  }
}

export async function segmentBlob(segment) {
  if (!segment?.id) return new Blob([]);
  const db = await openDB();
  if (db.isMemoryFallback) {
    const map = memoryStores.get('chunks');
    const chunks = Array.from(map.values())
      .filter(c => c.segmentId === segment.id)
      .sort((a, b) => a.sequence - b.sequence);
    const type = segment.mime || chunks.find(c => c.blob?.type)?.blob.type || '';
    return new Blob(chunks.map(c => c.blob), type ? { type } : undefined);
  }
  let request;
  await transaction(['chunks'], 'readonly', tx => {
    request = tx.objectStore('chunks').index('segmentId').getAll(segment.id);
  });
  const chunks = (request.result || []).sort((a, b) => a.sequence - b.sequence);
  const type = segment.mime || chunks.find(c => c.blob?.type)?.blob.type || '';
  return new Blob(chunks.map(c => c.blob), type ? { type } : undefined);
}

export async function deleteSessionChunksOnly(sessionId) {
  const db = await openDB();
  if (db.isMemoryFallback) {
    const map = memoryStores.get('chunks');
    for (const [k, v] of map.entries()) {
      if (v.sessionId === sessionId) map.delete(k);
    }
    return;
  }
  return transaction(['chunks'], 'readwrite', tx => {
    const request = tx.objectStore('chunks').index('sessionId').openCursor(IDBKeyRange.only(sessionId));
    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };
  });
}

export async function deleteSession(id) {
  await deleteSessionAudioSlices(id);
  await remove('scoring_queue', `score-job:${id}`).catch(() => {});
  const db = await openDB();
  if (db.isMemoryFallback) {
    memoryStores.get('sessions').delete(id);
    await deleteSessionChunksOnly(id);
    return;
  }
  return transaction(['sessions', 'chunks'], 'readwrite', tx => {
    tx.objectStore('sessions').delete(id);
    const request = tx.objectStore('chunks').index('sessionId').openCursor(IDBKeyRange.only(id));
    request.onsuccess = () => {
      const cursor = request.result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };
  });
}

// V4.3 Video & Audio Slice Retention & Cleanup Contract:
// - Cancelled mid-session: delete temporary video chunks AND temporary audio slices of this session.
// - Pending AI scoring / pending transcription: retain video chunks AND retain needed per-question audio slices!
// - Legitimately scored & FAILED: persist text results, then delete local video chunks AND temporary audio slices, and log 90-day audit entry.
// - Legitimately scored & PASSED: retain local video chunks (7-day retention), clean up temporary per-question audio slices (since transcription is done), and enqueue in 'upload_queue'.
export async function applyPostAssessmentStoragePolicy(sessionRecord) {
  const status = sessionRecord?.assessment?.status;
  const now = Date.now();
  const sevenDaysIso = new Date(now + 7 * 24 * 3600 * 1000).toISOString();
  const ninetyDaysIso = new Date(now + 90 * 24 * 3600 * 1000).toISOString();

  if (status === 'cancelled') {
    await deleteSessionChunksOnly(sessionRecord.id);
    await deleteSessionAudioSlices(sessionRecord.id);
    sessionRecord.recording = {
      ...(sessionRecord.recording || {}),
      status: 'deleted_after_cancel',
      deleted_at: new Date(now).toISOString()
    };
    sessionRecord.recordingStatus = 'none';
    await put('sessions', sessionRecord);
    return sessionRecord;
  }

  if (status === 'fail' && sessionRecord.assessment?.passed === false) {
    sessionRecord.recording = {
      ...(sessionRecord.recording || {}),
      status: 'deleted_after_fail_policy',
      contains_barrage: false,
      deleted_at: new Date(now).toISOString(),
      retention_expires_at: sevenDaysIso,
      video_download_permission: 'none'
    };
    sessionRecord.recordingStatus = 'none';
    (sessionRecord.segments || []).forEach(s => { s.status = 'deleted_after_fail_policy'; s.bytes = 0; });
    await put('sessions', sessionRecord);

    await deleteSessionChunksOnly(sessionRecord.id);
    await deleteSessionAudioSlices(sessionRecord.id);

    await put('audit_logs', {
      id: uid(),
      sessionId: sessionRecord.id,
      action: 'delete_failed_exam_video_local',
      reason: '考核未通过（正式AI评分已完成且文字记录已持久化），按规范清理本地录像分块与临时语音分片',
      createdAt: new Date(now).toISOString(),
      retentionExpiresAt: ninetyDaysIso,
      timezonePolicy: 'Asia/Shanghai (云端每日18:00定时清理待接入CloudBase后启用)'
    });
    return sessionRecord;
  }

  if (status === 'pass' && sessionRecord.assessment?.passed === true) {
    sessionRecord.recording = {
      ...(sessionRecord.recording || {}),
      status: 'local_retained_pass_pending_cloud',
      contains_barrage: false,
      retention_expires_at: sevenDaysIso,
      video_download_permission: 'operator_and_admin_only_when_cloud_connected'
    };
    await put('sessions', sessionRecord);
    // Transcription and scoring are complete -> clean up intermediate per-question audio slices while keeping whole video
    await deleteSessionAudioSlices(sessionRecord.id);
    await put('upload_queue', {
      id: `upload:${sessionRecord.id}`,
      sessionId: sessionRecord.id,
      status: 'pending_cloudbase_integration',
      createdAt: new Date(now).toISOString(),
      retentionExpiresAt: sevenDaysIso,
      note: '考核已通过，原片（不含弹幕）与独立弹幕时间轴已本地保留；当前阶段未连接 CloudBase，不执行云上传'
    });
    return sessionRecord;
  }

  // Pending transcription or pending scoring: strictly retain local video chunks and needed audio slices!
  sessionRecord.recording = {
    ...(sessionRecord.recording || {}),
    status: 'local_pending_scoring',
    contains_barrage: false
  };
  await put('sessions', sessionRecord);
  return sessionRecord;
}

export async function enqueueScoringJob(job) {
  const existing = await get('scoring_queue', job.id || `score-job:${job.sessionId}`);
  const technicalAttempts = job.technicalAttempts !== undefined
    ? job.technicalAttempts
    : (job.attempts !== undefined ? job.attempts : (existing?.technicalAttempts ?? existing?.attempts ?? 0));
  const quotaDeferrals = job.quotaDeferrals !== undefined
    ? job.quotaDeferrals
    : (existing?.quotaDeferrals ?? 0);
  const dailyRequestCount = job.dailyRequestCount !== undefined
    ? job.dailyRequestCount
    : (existing?.dailyRequestCount ?? 0);

  const nextRetryAfterMs = job.nextRetryAfterMs ?? existing?.nextRetryAfterMs ?? 0;

  const item = {
    id: job.id || `score-job:${job.sessionId}`,
    sessionId: job.sessionId,
    idempotencyKey: job.idempotencyKey || existing?.idempotencyKey || `score:${job.sessionId}:${job.snapshotHash || 'v1'}`,
    status: job.status || 'scoring_pending_quota',
    attempts: technicalAttempts,
    technicalAttempts,
    quotaDeferrals,
    dailyRequestCount,
    nextRetryAfterMs,
    next_eligible_at: nextRetryAfterMs > 0 ? new Date(nextRetryAfterMs).toISOString() : null,
    lastQuotaCode: job.lastQuotaCode ?? existing?.lastQuotaCode ?? null,
    lastRateLimitedAt: job.lastRateLimitedAt ?? existing?.lastRateLimitedAt ?? null,
    lastError: job.lastError ?? existing?.lastError ?? null,
    updatedAt: new Date().toISOString(),
    payload: job.payload || existing?.payload
  };
  await put('scoring_queue', item);
  return item;
}

export async function getPendingScoringJobs() {
  const all = await getAll('scoring_queue');
  return all.filter(j => ['scoring_pending_quota', 'scoring_retry_required', 'pending'].includes(j.status));
}

export async function storageHealth() {
  const estimate = await globalThis.navigator?.storage?.estimate?.();
  if (estimate?.quota && estimate.usage / estimate.quota > 0.85) {
    throw new Error('本地存储已超过 85%，请先导出/下载通过录像并清理旧记录后再开始录制');
  }
  return estimate;
}

export function storageError(error) {
  return error?.name === 'QuotaExceededError'
    ? '本地空间已满，录像未完整保存。请下载可用录像并清理旧记录后再重试。'
    : `本地保存失败：${error?.message || error}。请勿刷新，先下载可用录像或导出记录。`;
}
