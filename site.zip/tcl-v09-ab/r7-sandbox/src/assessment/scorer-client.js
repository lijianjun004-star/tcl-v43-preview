// TASK006: restores signed local inference evidence against current audio before scoring.
// Local consistency checks do not replace server identity/audio verification.

import {
  validateScoringRequestPayload,
  validateAndComputeAssessment,
  SCORING_POLICY_VERSION,
  FORBIDDEN_SIMULATED_PATTERNS,
  VALID_PRODUCTION_LOCAL_ASR_VERSION_RE
} from './schema.js';
import {
  enqueueScoringJob,
  getPendingScoringJobs,
  get,
  put,
  recoverQuestionAudioSlice,
  deleteQuestionAudioSlice,
  applyPostAssessmentStoragePolicy
} from '../storage/storage.js';
import { requestGeminiFallbackTranscription } from '../speech/speech.js';
import {
  isAuthenticLocalAsrResult,
  getPersistedLocalAsrResult
} from '../speech/local-asr/asr-results.js';

export const MAX_AUTO_RECOVERY_ATTEMPTS = 3;
export const BASE_RECOVERY_BACKOFF_MS = 2000;
export const MAX_DAILY_SCORING_REQUESTS_PER_JOB = 25;

export const RECOVERABLE_QUOTA_CODES = new Set([
  'rate_limited_429',
  'rpm_exhausted',
  'rpd_exhausted',
  'rate_limit_cooldown',
  'concurrency_limit',
  'unverified_no_key',
  'unverified_free_tier',
  'blocked_billing_linked',
  'unconfigured_model'
]);

export async function fetchGatewayCapabilities(gatewayBaseUrl = '', fetchImpl = globalThis.fetch) {
  try {
    if (globalThis.__TCL_AB_SANDBOX === true) throw new Error('隔离 A/B 沙盒禁用远端AI评分');
    const res = await fetchImpl(`${gatewayBaseUrl || '.'}/api/ai/capabilities`, { method: 'GET' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (error) {
    return {
      ok: false,
      enabled: false,
      status: 'gateway_unreachable',
      free_tier_verified: false,
      billing_linked: null,
      score_model: null,
      transcribe_model: null,
      reason: `本地隔离 AI 网关未启动或不可达（${error.message}），所有非 AI 功能均可正常使用，考核完成后将安全保存为「待评分」状态。`
    };
  }
}

export function buildAnonymizedScoringRequest(sessionRecord) {
  // Explicitly omit anchor.display_name_local_only, operator_id, manual_note_untrusted, and any video blobs!
  return {
    session_id: sessionRecord.session_id || sessionRecord.id,
    snapshot_hash: sessionRecord.question_set_snapshot?.hash || 'unhashed',
    policy_version: SCORING_POLICY_VERSION,
    questions: (sessionRecord.questions || []).map(q => ({
      question_id: q.question_id || q.id,
      question_text: q.question_text || q.content,
      reference_answer: q.reference_answer || q.reference,
      transcript: q.skipped_by_anchor ? '' : String(q.transcript || ''),
      transcription_provider: q.skipped_by_anchor ? 'none' : (q.transcription_provider || 'browser'),
      asr_model_version: q.asr_model_version || q.transcript_evidence?.asr_model_version || null,
      source_audio_hash: q.source_audio_hash || q.transcript_evidence?.source_audio_hash || null,
      engine_mode: q.transcript_evidence?.engine_mode || q.transcript_evidence?.engineMode || null,
      skipped_by_anchor: Boolean(q.skipped_by_anchor),
      transcription_status: q.transcription_status || 'completed'
    }))
  };
}

// TASK004 Section 2.1 & TASK005 P1-01:
// Batch-transcribe pending questions at the end of the exam using the locally installed sherpa-onnx WASM Worker engine.
// Strictly verifies `isAuthenticLocalAsrResult(asrOut)` and refuses any simulated or unverified output!
export async function transcribeSessionWithLocalAsr(sessionRecord, localAsrEngine, {
  decodeFullMediaToQuestionWav = null
} = {}) {
  if (!sessionRecord || !localAsrEngine) {
    return { attempted: false, transcribedCount: 0, remainingCount: 0, reason: '未提供本地 ASR 引擎实例' };
  }

  const sessionId = sessionRecord.session_id || sessionRecord.id;
  const pendingQuestions = (sessionRecord.questions || []).filter(
    q => !q.skipped_by_anchor && (!q.transcript || q.transcription_status === 'technical_fault' || q.transcription_status === 'pending' || q.transcription_status === 'transcription_pending')
  );

  if (!pendingQuestions.length) {
    return { attempted: false, transcribedCount: 0, remainingCount: 0, reason: '无待转写题目' };
  }

  const installState = await localAsrEngine.getInstallState();
  if (!installState.ready) {
    return {
      attempted: false,
      transcribedCount: 0,
      remainingCount: pendingQuestions.length,
      reason: installState.reason || '暂未开放本地转写：本地 sherpa-onnx 模型或运行时尚未安装就绪'
    };
  }

  let transcribedCount = 0;
  let lastError = null;

  for (const fq of pendingQuestions) {
    const qid = fq.question_id || fq.id;
    const sliceRecord = await recoverQuestionAudioSlice(sessionRecord, qid, { decodeFullMediaToQuestionWav });
    if (!sliceRecord?.blob) {
      fq.transcription_status = 'technical_fault';
      fq.reasoning_summary = '未找到可解码的单题音频分片（已禁止字节比例伪造切片），保留待转写状态';
      lastError = fq.reasoning_summary;
      continue;
    }

    try {
      const asrOut = await localAsrEngine.transcribeQuestion({
        sessionId,
        questionId: qid,
        audio: sliceRecord.blob,
        startMs: fq.answer_start_ms ?? sliceRecord.startMs ?? 0,
        endMs: fq.answer_end_ms ?? sliceRecord.endMs ?? 0
      });

      // Verify this object passed signature/audio validation after native inference.
      if (!isAuthenticLocalAsrResult(asrOut)) {
        const authErr = new Error(
          `安全阻断：拒绝非真实 sherpa-wasm-native 引擎产出的转写结果（provider=${asrOut?.provider}, mode=${asrOut?.engineMode}, model=${asrOut?.modelId}）`
        );
        authErr.code = 'forged_or_simulated_asr_rejected';
        throw authErr;
      }

      if (Array.isArray(asrOut.interval) && asrOut.interval.length === 2) {
        fq.answer_start_ms = asrOut.interval[0];
        fq.answer_end_ms = asrOut.interval[1];
      }
      fq.transcript = asrOut.text;
      fq.transcription_provider = 'sherpa-onnx-local';
      fq.asr_model_version = asrOut.asr_model_version || `${asrOut.modelId}@${asrOut.modelVersion}`;
      fq.source_audio_hash = asrOut.audioDigest;
      fq.transcription_status = 'completed';
      fq.completed = true;
      fq.transcript_evidence = {
        ...(fq.transcript_evidence || {}),
        provider: 'sherpa-onnx-local',
        model_id: asrOut.modelId,
        model_version: asrOut.modelVersion,
        asr_model_version: fq.asr_model_version,
        source_audio_hash: asrOut.audioDigest,
        engine_mode: 'sherpa-wasm-native',
        interval: asrOut.interval,
        elapsed_ms: asrOut.elapsedMs,
        rtf: asrOut.rtf
      };
      transcribedCount++;
    } catch (error) {
      fq.transcript = null;
      fq.transcription_status = 'technical_fault';
      fq.reasoning_summary = `本地语音识别未完成（${error.message}），已安全保留单题音频与原片待恢复`;
      lastError = error.message;
      if (
        error.code === 'worker_circuit_breaker_open' ||
        error.code === 'worker_init_failed' ||
        error.code === 'worker_oom' ||
        error.code === 'sherpa_runtime_unavailable' ||
        error.code === 'forged_or_simulated_asr_rejected'
      ) {
        break;
      }
    }
  }

  await put('sessions', sessionRecord);
  return {
    attempted: true,
    transcribedCount,
    remainingCount: pendingQuestions.length - transcribedCount,
    lastError
  };
}

// Recover persisted single-question audio slices from IndexedDB (even after page refresh!)
// and run consent-controlled Gemini fallback transcription when user explicitly consents for this session.
export async function recoverSessionPendingTranscriptions(sessionRecord, {
  userConsented = false,
  gatewayBaseUrl = '',
  fetchImpl = globalThis.fetch,
  localAsrEngine = null,
  decodeFullMediaToQuestionWav = null
} = {}) {
  const sessionId = sessionRecord?.session_id || sessionRecord?.id;
  if (sessionRecord?.anchor?.identity_scope === 'local_preview') {
    return { ok: false, pendingCount: (sessionRecord.questions || []).length, recoveredCount: 0,
      reason: '本机体验禁止使用外部 Gemini 音频转写网关' };
  }

  // 1. Always try local sherpa-onnx first if installed & ready (no third-party upload needed!)
  if (localAsrEngine) {
    await transcribeSessionWithLocalAsr(sessionRecord, localAsrEngine, { decodeFullMediaToQuestionWav });
  }

  const faultQuestions = (sessionRecord?.questions || []).filter(
    q => !q.skipped_by_anchor && (!q.transcript || q.transcription_status === 'technical_fault' || q.transcription_status === 'pending' || q.transcription_status === 'transcription_pending')
  );
  if (!faultQuestions.length) {
    return { ok: true, pendingCount: 0, recoveredCount: (sessionRecord?.questions || []).length };
  }

  if (userConsented !== true) {
    return {
      ok: false,
      pendingCount: faultQuestions.length,
      recoveredCount: 0,
      reason: '主播未授予单次备用语音转写同意，已安全保留单题音频分片与「待转写」状态（零音频外传）'
    };
  }

  let recoveredCount = 0;
  for (const fq of faultQuestions) {
    const qid = fq.question_id || fq.id;
    const sliceRecord = await recoverQuestionAudioSlice(sessionRecord, qid, { decodeFullMediaToQuestionWav });
    if (!sliceRecord?.blob) {
      fq.transcription_status = 'technical_fault';
      fq.reasoning_summary = '未找到可恢复且可解码的单题音频分片，保持待转写状态';
      continue;
    }

    const res = await requestGeminiFallbackTranscription({
      questionId: qid,
      sessionId,
      audioBlob: sliceRecord.blob,
      startMs: fq.answer_start_ms ?? sliceRecord.startMs,
      endMs: fq.answer_end_ms ?? sliceRecord.endMs,
      userConsented: true,
      gatewayBaseUrl,
      fetchImpl
    });

    if (res.ok && res.transcript) {
      fq.transcript = res.transcript;
      fq.transcription_provider = 'gemini-fallback';
      fq.transcription_status = 'completed';
      fq.completed = true;
      fq.transcript_evidence = {
        ...(fq.transcript_evidence || {}),
        provider: 'gemini-fallback',
        recovered_from_persisted_slice: true,
        source_audio_hash: sliceRecord.audioDigest || null
      };
      // Delete temporary per-question audio slice once transcription succeeds
      await deleteQuestionAudioSlice(sessionId, qid);
      recoveredCount++;
    } else {
      fq.transcription_status = 'technical_fault';
      fq.reasoning_summary = res.reason;
    }
  }

  await put('sessions', sessionRecord);
  return {
    ok: recoveredCount === faultQuestions.length,
    pendingCount: faultQuestions.length - recoveredCount,
    recoveredCount
  };
}

export async function submitSessionForScoring(sessionRecord, {
  gatewayBaseUrl = '',
  fetchImpl = globalThis.fetch,
  now = () => Date.now()
} = {}) {
  const sessionId = sessionRecord.session_id || sessionRecord.id;
  const questions = sessionRecord.questions || [];

  // TASK010: Experience-only records can never be submitted as real Gemini scores.
  // This guard also covers manual retries and automatic scoring queue recovery.
  if (sessionRecord.anchor?.identity_scope === 'local_preview') {
    sessionRecord.assessment = {
      status: 'scoring_pending_quota', passed: null, average_raw: null,
      average_display: null, source: 'pending',
      reason: '本机体验记录未绑定真实运营身份，禁止正式评分与云端同步。'
    };
    return sessionRecord.assessment;
  }

  // TASK005 P1-01 Pre-scoring Audit:
  // Inspect every question claiming `sherpa-onnx-local` (or any simulated provider) and quarantine unverified transcripts
  // into `transcription_pending` so simulated/forged text NEVER enters formal AI scoring or gets scored 0!
  for (const q of questions) {
    if (q.skipped_by_anchor) continue;
    const provider = String(q.transcription_provider || '');
    const modelVer = String(q.asr_model_version || q.transcript_evidence?.asr_model_version || '');
    const engineMode = String(q.transcript_evidence?.engine_mode || q.transcript_evidence?.engineMode || '');

    if (FORBIDDEN_SIMULATED_PATTERNS.test(provider) || FORBIDDEN_SIMULATED_PATTERNS.test(modelVer) || engineMode === 'sherpa-wasm-worker-acoustic') {
      q.transcript = null;
      q.transcription_status = 'transcription_pending';
      q.reasoning_summary = `安全阻断：检测到模拟或测试识别来源（provider=${provider}, model=${modelVer}, mode=${engineMode}），已拒绝采信并回退为待转写状态`;
      continue;
    }

    if (provider === 'sherpa-onnx-local') {
      const qid = q.question_id || q.id;
      const expectedInterval = Number.isFinite(q.answer_start_ms) && Number.isFinite(q.answer_end_ms)
        ? [q.answer_start_ms, q.answer_end_ms] : undefined;
      const persistedAsr = await getPersistedLocalAsrResult(sessionId, qid, { interval: expectedInterval });
      const validPersisted = Boolean(
        persistedAsr &&
        isAuthenticLocalAsrResult(persistedAsr) &&
        persistedAsr.text === String(q.transcript || '').trim() &&
        persistedAsr.source_audio_hash === q.source_audio_hash &&
        persistedAsr.asr_model_version === modelVer &&
        (!engineMode || engineMode === persistedAsr.engineMode)
      );
      if (
        !VALID_PRODUCTION_LOCAL_ASR_VERSION_RE.test(modelVer) ||
        !/^[a-f0-9]{64}$/i.test(String(q.source_audio_hash || '')) ||
        !validPersisted
      ) {
        q.transcript = null;
        q.transcription_status = 'transcription_pending';
        q.reasoning_summary = '安全阻断：该题声明为 sherpa-onnx-local，但缺少经过真实推理签名、当前音频字节与 SHA-256 绑定的转写记录，已回退为待转写状态';
      }
    }
  }

  const hasPendingTranscription = questions.some(
    q => !q.skipped_by_anchor && (!q.transcript || q.transcription_status === 'technical_fault' || q.transcription_status === 'pending' || q.transcription_status === 'transcription_pending')
  );
  if (hasPendingTranscription) {
    sessionRecord.assessment = {
      ...sessionRecord.assessment,
      status: 'transcription_pending',
      passed: null,
      average_raw: null,
      average_display: null,
      source: 'pending',
      reason: '存在待语音转写题目（本地 sherpa-onnx 真实模型未安装/未就绪且尚未完成备用转写），为保证正式考核转写真实性且不误判 0 分，本场已安全保存为「等待语音转写」状态，单题音频分片与录像完整保留。'
    };
    await applyPostAssessmentStoragePolicy(sessionRecord);
    return sessionRecord.assessment;
  }

  // If every question in the exam was actively skipped by the anchor, all questions are deterministically 0 points
  if (questions.length > 0 && questions.every(q => q.skipped_by_anchor === true)) {
    const nowIso = new Date(now()).toISOString();
    questions.forEach(q => {
      q.score = 0;
      q.score_status = 'scored_skip_zero';
      q.reasoning_summary = '主播主动跳过本题且未作答，记 0 分。';
      q.semantic_matches = [];
      q.missing_or_incorrect = ['未作答全部核心要点'];
      q.severe_product_misinformation = false;
    });
    sessionRecord.assessment = {
      status: 'fail',
      average_raw: 0,
      average_display: 0,
      score: 0,
      passed: false,
      scored_at: nowIso,
      scoring_policy_version: SCORING_POLICY_VERSION,
      model_id: 'rule:all-skipped-zero',
      source: 'rule_skip_zero',
      reason: '全部题目均为主播主动跳题未作答，综合得分 0 分（未通过）。'
    };
    await applyPostAssessmentStoragePolicy(sessionRecord);
    return sessionRecord.assessment;
  }

  const payload = buildAnonymizedScoringRequest(sessionRecord);
  const payloadCheck = validateScoringRequestPayload(payload);
  if (!payloadCheck.valid) {
    sessionRecord.assessment = {
      ...sessionRecord.assessment,
      status: 'scoring_retry_required',
      passed: null,
      average_raw: null,
      average_display: null,
      source: 'pending',
      reason: `评分请求校验未通过：${payloadCheck.errors.join('；')}`
    };
    await applyPostAssessmentStoragePolicy(sessionRecord);
    return sessionRecord.assessment;
  }

  const idempotencyKey = `score:${payload.session_id}:${payload.snapshot_hash}`;
  const existingJob = await get('scoring_queue', `score-job:${payload.session_id}`);
  const prevTechnicalAttempts = existingJob?.technicalAttempts ?? existingJob?.attempts ?? 0;
  const prevQuotaDeferrals = existingJob?.quotaDeferrals ?? 0;
  const prevDailyRequests = existingJob?.dailyRequestCount ?? 0;

  await enqueueScoringJob({
    sessionId: payload.session_id,
    idempotencyKey,
    status: 'scoring_pending_quota',
    technicalAttempts: prevTechnicalAttempts,
    quotaDeferrals: prevQuotaDeferrals,
    dailyRequestCount: prevDailyRequests,
    payload
  });

  try {
    if (globalThis.__TCL_AB_SANDBOX === true) throw new Error('A/B 沙盒不允许向任何正式评分网关提交');
    const res = await fetchImpl(`${gatewayBaseUrl || '.'}/api/ai/score`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Idempotency-Key': idempotencyKey
      },
      body: JSON.stringify(payload)
    });
    const body = await res.json();

    if (!res.ok || !body.ok) {
      const code = body?.code || (res.status === 429 ? 'rate_limited_429' : null);
      const isQuotaOrConfigDeferral =
        res.status === 429 ||
        RECOVERABLE_QUOTA_CODES.has(code) ||
        (res.status === 503 && body?.status === 'scoring_pending_quota');

      const isNoKeyOrConfig = ['unverified_no_key', 'unverified_free_tier', 'blocked_billing_linked', 'unconfigured_model'].includes(code);

      // TASK003 P1-A Fix:
      // Quota / 429 / RPD / RPM deferrals MUST NOT increment `technicalAttempts` (`attempts`)!
      const nextTechnicalAttempts = isQuotaOrConfigDeferral ? prevTechnicalAttempts : prevTechnicalAttempts + 1;
      const nextQuotaDeferrals = isQuotaOrConfigDeferral && !isNoKeyOrConfig ? prevQuotaDeferrals + 1 : prevQuotaDeferrals;
      const nextDailyRequests = isNoKeyOrConfig ? prevDailyRequests : prevDailyRequests + 1;

      const backoffPower = isQuotaOrConfigDeferral ? Math.min(5, nextQuotaDeferrals) : Math.min(4, nextTechnicalAttempts);
      const backoffMs = isNoKeyOrConfig ? 0 : BASE_RECOVERY_BACKOFF_MS * Math.pow(2, backoffPower);
      const nextEligibleAtMs = backoffMs ? now() + backoffMs : 0;

      const pendingStatus = body?.status === 'scoring_retry_required' && !isQuotaOrConfigDeferral
        ? 'scoring_retry_required'
        : 'scoring_pending_quota';

      sessionRecord.assessment = {
        ...sessionRecord.assessment,
        status: pendingStatus,
        passed: null,
        average_raw: null,
        average_display: null,
        source: 'pending',
        next_eligible_at: nextEligibleAtMs ? new Date(nextEligibleAtMs).toISOString() : null,
        quota_code: code,
        reason: body?.reason || body?.error || 'AI 语义评分暂不可用（无免费 Key 或配额受限），已安全保留为「待评分」状态。'
      };
      await enqueueScoringJob({
        sessionId: payload.session_id,
        idempotencyKey,
        status: pendingStatus,
        technicalAttempts: nextTechnicalAttempts,
        quotaDeferrals: nextQuotaDeferrals,
        dailyRequestCount: nextDailyRequests,
        nextRetryAfterMs: nextEligibleAtMs,
        lastQuotaCode: code,
        lastRateLimitedAt: isQuotaOrConfigDeferral && !isNoKeyOrConfig ? new Date(now()).toISOString() : (existingJob?.lastRateLimitedAt || null),
        lastError: sessionRecord.assessment.reason,
        payload
      });
      await applyPostAssessmentStoragePolicy(sessionRecord);
      return sessionRecord.assessment;
    }

    sessionRecord.raw_ai_response = body.raw_result || body.result;
    const verified = validateAndComputeAssessment(payload, body.result);

    if (!verified.valid) {
      const nextTechnicalAttempts = prevTechnicalAttempts + 1;
      const backoffMs = BASE_RECOVERY_BACKOFF_MS * Math.pow(2, Math.min(4, nextTechnicalAttempts));
      sessionRecord.assessment = {
        ...sessionRecord.assessment,
        status: 'scoring_retry_required',
        passed: null,
        average_raw: null,
        average_display: null,
        source: 'schema_rejected',
        reason: `AI 评分返回结构未通过 Schema 校验（${verified.errors.join('；')}），拒绝生成通过/未通过结论，已标记为需重试。`
      };
      await enqueueScoringJob({
        sessionId: payload.session_id,
        idempotencyKey,
        status: 'scoring_retry_required',
        technicalAttempts: nextTechnicalAttempts,
        quotaDeferrals: prevQuotaDeferrals,
        dailyRequestCount: prevDailyRequests + 1,
        nextRetryAfterMs: now() + backoffMs,
        lastError: sessionRecord.assessment.reason,
        payload
      });
      await applyPostAssessmentStoragePolicy(sessionRecord);
      return sessionRecord.assessment;
    }

    const qResultMap = new Map(verified.question_results.map(r => [r.question_id, r]));
    for (const q of sessionRecord.questions) {
      const qr = qResultMap.get(q.question_id || q.id);
      if (!qr) continue;
      q.score = qr.score;
      q.score_status = 'verified';
      q.reasoning_summary = qr.analysis;
      q.semantic_matches = qr.semantic_matches || [];
      q.missing_or_incorrect = qr.missing_or_incorrect || [];
      q.errors = qr.missing_or_incorrect || [];
      q.evidence_quote = qr.evidence_quote || '';
      q.severe_product_misinformation = Boolean(qr.critical_false_claim);
      q.critical_false_claim_reason = qr.critical_false_claim_reason || null;
      q.model_id = verified.model_id;
      q.scored_at = verified.scored_at;
    }

    const isSimulation = body.source === 'test_simulation';
    sessionRecord.assessment = {
      status: verified.status,
      average_raw: verified.average_raw,
      average_display: verified.average_display,
      score: verified.average_display,
      passed: verified.passed,
      has_critical_false_claim: verified.has_critical_false_claim,
      veto_reason: verified.veto_reason,
      scored_at: verified.scored_at,
      scoring_policy_version: verified.policy_version,
      model_id: verified.model_id,
      source: isSimulation ? 'test_simulation' : 'real_ai',
      reason: verified.veto_reason
        ? verified.veto_reason
        : `${isSimulation ? '【测试模拟夹具·非真实AI联调】' : '【真实 AI 语义评分】'}综合均分 ${verified.average_raw.toFixed(2)} 分（显示 ${verified.average_display} 分），${verified.passed ? '达到 80 分标准，考核通过' : '未达到 80 分标准，考核未通过'}。`
    };

    await enqueueScoringJob({
      sessionId: payload.session_id,
      idempotencyKey,
      status: 'completed',
      technicalAttempts: prevTechnicalAttempts,
      quotaDeferrals: prevQuotaDeferrals,
      dailyRequestCount: prevDailyRequests + 1,
      nextRetryAfterMs: 0,
      lastError: null,
      payload
    });
    await applyPostAssessmentStoragePolicy(sessionRecord);
    return sessionRecord.assessment;
  } catch (error) {
    const nextTechnicalAttempts = prevTechnicalAttempts + 1;
    const backoffMs = BASE_RECOVERY_BACKOFF_MS * Math.pow(2, Math.min(4, nextTechnicalAttempts));
    sessionRecord.assessment = {
      ...sessionRecord.assessment,
      status: 'scoring_pending_quota',
      passed: null,
      average_raw: null,
      average_display: null,
      source: 'pending',
      reason: `评分请求网络或服务暂不可达（${error.message}），已安全保留本地录像与「待评分」状态，页面恢复后可幂等重试。`
    };
    await enqueueScoringJob({
      sessionId: payload.session_id,
      idempotencyKey,
      status: 'scoring_pending_quota',
      technicalAttempts: nextTechnicalAttempts,
      quotaDeferrals: prevQuotaDeferrals,
      dailyRequestCount: prevDailyRequests + 1,
      nextRetryAfterMs: now() + backoffMs,
      lastError: error.message,
      payload
    });
    await applyPostAssessmentStoragePolicy(sessionRecord);
    return sessionRecord.assessment;
  }
}

let recoveryInFlight = null;

export async function recoverPendingScoringJobs({
  gatewayBaseUrl = '',
  fetchImpl = globalThis.fetch,
  isOnline = () => (typeof navigator !== 'undefined' ? navigator.onLine !== false : true),
  now = () => Date.now(),
  maxTechnicalAttempts = MAX_AUTO_RECOVERY_ATTEMPTS,
  maxDailyRequests = MAX_DAILY_SCORING_REQUESTS_PER_JOB,
  onSessionRecovered = () => {}
} = {}) {
  if (recoveryInFlight) {
    return recoveryInFlight;
  }

  recoveryInFlight = (async () => {
    if (!isOnline()) {
      return { triggered: false, reason: 'offline', processed: 0, succeeded: 0 };
    }

    const pendingJobs = await getPendingScoringJobs();
    if (!pendingJobs.length) {
      return { triggered: false, reason: 'no_pending_jobs', processed: 0, succeeded: 0 };
    }

    const caps = await fetchGatewayCapabilities(gatewayBaseUrl, fetchImpl);
    if (!caps?.enabled) {
      return {
        triggered: false,
        reason: caps?.status || 'capabilities_disabled',
        detail: caps?.reason || '当前无可用免费 AI 额度或未配置 Free Tier 密钥，跳过自动重试',
        pendingCount: pendingJobs.length,
        processed: 0,
        succeeded: 0
      };
    }

    let processed = 0;
    let succeeded = 0;
    const currentMs = now();

    for (const job of pendingJobs) {
      const techAttempts = job.technicalAttempts ?? job.attempts ?? 0;
      if (techAttempts >= maxTechnicalAttempts) {
        continue;
      }
      if ((job.dailyRequestCount || 0) >= maxDailyRequests) {
        continue;
      }
      if (job.nextRetryAfterMs && currentMs < job.nextRetryAfterMs) {
        continue;
      }

      const sessionRecord = await get('sessions', job.sessionId);
      if (!sessionRecord) {
        await enqueueScoringJob({ ...job, status: 'abandoned_no_session' });
        continue;
      }
      if (['pass', 'fail'].includes(sessionRecord.assessment?.status)) {
        await enqueueScoringJob({ ...job, status: 'completed' });
        continue;
      }

      processed++;
      const assessment = await submitSessionForScoring(sessionRecord, {
        gatewayBaseUrl,
        fetchImpl,
        now
      });

      if (['pass', 'fail'].includes(assessment?.status)) {
        succeeded++;
        try { onSessionRecovered(sessionRecord); } catch {}
      } else if (assessment?.status === 'scoring_pending_quota') {
        break;
      }
    }

    return {
      triggered: true,
      reason: 'completed_cycle',
      pendingCount: pendingJobs.length,
      processed,
      succeeded
    };
  })();

  try {
    return await recoveryInFlight;
  } finally {
    recoveryInFlight = null;
  }
}
