// Isolated V2.3 subsite cache. A slow network has a bounded fallback window.
const CACHE = 'tcl-r7ab-v09-subsite-shell-v2.3';
const NETWORK_TIMEOUT_MS = 5000;
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith('tcl-r7ab-v09-subsite-shell-') && name !== CACHE) await caches.delete(name);
    }
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url), scope = new URL(self.registration.scope);
  if (e.request.method !== 'GET' || url.origin !== scope.origin || !url.pathname.startsWith(scope.pathname)) return;
  if (url.pathname.includes('/api/') || url.pathname.includes('/assets/offline-asr/') || url.pathname.endsWith('/ready.json')) return;
  const networkOrFallback = (async () => {
    const controller = new AbortController();
    let timer;
    try {
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => { controller.abort(); reject(new Error('network-timeout')); }, NETWORK_TIMEOUT_MS);
      });
      const response = await Promise.race([fetch(e.request, { signal: controller.signal }), timeout]);
      return { response, cacheResponse: response?.ok && response.status === 200 ? response.clone() : null };
    } catch {
      try {
        const cache = await caches.open(CACHE);
        const cached = await cache.match(e.request, { ignoreSearch: true });
        if (cached) return { response: cached };
      } catch {}
      return { response: new Response('网络暂不可用且当前版本尚无缓存：请联网重试。本地训练进度不会丢失。', {
        status: 503, headers: { 'Content-Type': 'text/plain;charset=utf-8' }
      }) };
    } finally {
      if (timer != null) clearTimeout(timer);
    }
  })();
  // Register lifetime extension during event dispatch, before network awaits.
  e.waitUntil(networkOrFallback.then(({ cacheResponse }) => cacheResponse
    ? caches.open(CACHE).then(cache => cache.put(e.request, cacheResponse))
    : undefined).catch(() => {}));
  e.respondWith(networkOrFallback.then(({ response }) => response));
});
