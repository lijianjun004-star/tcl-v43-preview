// TCL v0.6 independent on-device speech recognition worker.
// Inference: browser WASM, multilingual Whisper Tiny; no metered API / audio upload.
// Runtime and open model are downloaded on first use and cached by browser.
// CDN/model availability, storage, and iOS memory are NOT guaranteed.
// v0.7 release gate: strictly use self-hosted runtime, never fetch from third-party CDN.
const MODEL_ID = 'Xenova/whisper-tiny'; // multilingual; NEVER use .en for Chinese
const RATE = 16000;
let localBundle = null;
let modelPromise = null;
let transcriber = null;
async function load() {
  if (!modelPromise) {
    modelPromise = (async () => {
      self.postMessage({ type:'status', message:'准备本地识别库（首次需要联网下载）' });
      if (!localBundle?.runtimeURL || !localBundle?.modelsPath || !localBundle?.wasmPath) throw Error('未部署完整模型资源：请先执行独立ASR资源安装及校验');
      const { pipeline, env } = await import(localBundle.runtimeURL);
      env.allowRemoteModels = false;
      env.allowLocalModels = true;
      if (localBundle) {
        env.localModelPath = localBundle.modelsPath;
        env.backends.onnx.wasm.wasmPaths = localBundle.wasmPath;
      }
      env.backends.onnx.wasm.numThreads = 1; // CloudBase static hosting need not supply cross-origin isolated headers.
      env.useBrowserCache = true;
      const t = await pipeline('automatic-speech-recognition', MODEL_ID, {
        device: 'wasm', dtype: 'q8',
        progress_callback: p => {
          if (p?.status === 'progress' && Number.isFinite(p.progress)) {
            self.postMessage({ type:'progress', progress: Math.max(0,Math.min(100,p.progress)) });
          } else if (p?.status) self.postMessage({ type:'status', message:'模型初始化：'+String(p.status).slice(0,32) });
        }
      });
      transcriber = t;
      return t;
    })().catch(err => { modelPromise = null; throw err; });
  }
  return modelPromise;
}
self.onmessage = async ({data}) => {
  if (data?.type === 'configure') {
    if (!modelPromise) localBundle = data.localBundle || null;
    return;
  }
  if (!data || data.type !== 'transcribe' || !Number.isInteger(data.id)) return;
  const id = data.id;
  try {
    if (!(data.samples instanceof Float32Array)) throw Error('音频数据必须是16kHz单声道浮点采样');
    if (data.samples.length < RATE || data.samples.length > RATE * 180) throw Error('单段音频长度需在1到180秒之间');
    let energy=0;for(let k=0;k<data.samples.length;k++) energy+=data.samples[k]*data.samples[k];
    if (Math.sqrt(energy/data.samples.length)<0.001) throw Error('录音过于安静，无法证明有人声；请重新录音');
    const t = await load();
    const chunks = Math.ceil(data.samples.length / (RATE*18));
    const out = [];
    for (let i=0; i<chunks; i++) {
      self.postMessage({type:'status',message:`本机正在识别 ${i+1}/${chunks} 段（音频未上传）`});
      const block = data.samples.slice(i*RATE*18,(i+1)*RATE*18);
      const result = await t(block,{language:'chinese',task:'transcribe',return_timestamps:false});
      if (typeof result?.text !== 'string') throw Error('识别模型没有返回文字');
      const text = result.text.replace(/<\\|.*?\\|>/g,'').trim();
      if (text) out.push(text);
    }
    const text = out.join('，').trim();
    if (text.length < 2 || !/[\u3400-\u9fff]/u.test(text)) throw Error('模型未能可靠识别中文，请重录；不会生成替代文字');
    self.postMessage({type:'result',id,text,model:MODEL_ID,engine:'wasm_on_device',audioUploaded:false});
  } catch(err) {
    self.postMessage({type:'error',id,message: String(err?.message || err).slice(0,350)});
  }
};
