export * from './src/training/core.js';
export * from './src/files/question-set.js';
export * from './src/files/parser.js';

import { uid } from './src/training/core.js';

// Preserved & upgraded from V4 knowledge.js for backward compatibility
export function parseKnowledge(text, name) {
  if (new TextEncoder().encode(text).length > 2 * 1048576) throw new Error('资料超过 2 MB，请分段导入');
  const lower = String(name || '').toLowerCase();
  if (lower.endsWith('.doc')) {
    throw new Error('不支持旧版 .doc 格式，请另存为 .docx 后再导入');
  }
  const json = lower.endsWith('.json');
  let title = name, questions = [], facts = [];
  if (json) {
    let data;
    try { data = JSON.parse(text); } catch { throw new Error('JSON格式错误，旧资料未被替换'); }
    if (!data || Array.isArray(data) || typeof data !== 'object') throw new Error('JSON必须包含title、questions等字段的对象');
    title = typeof data.title === 'string' ? data.title.slice(0, 120) : name;
    questions = (data.questions || []).map(q => ({
      question: String(q?.question || '').trim(),
      reference: String(q?.reference || '').trim()
    }));
    facts = (data.facts || []).map(f => ({ key: String(f?.key || ''), value: String(f?.value || '') }));
  } else {
    let q = null;
    for (const line of text.split(/\r?\n/)) {
      const match = line.match(/^\s*(问题|题目|问|参考答案|标准答案|参考|答案|答)[：:]\s*(.+)$/);
      if (!match) continue;
      if (['问题', '题目', '问'].includes(match[1])) q = match[2].trim();
      else if (q) { questions.push({ question: q, reference: match[2].trim() }); q = null; }
    }
  }
  if (!text.trim()) throw new Error('文件没有可读取的文字');
  const conflicts = [], values = new Map();
  for (const f of facts) {
    if (values.has(f.key) && values.get(f.key) !== f.value) conflicts.push(`参数「${f.key}」存在不同值`);
    values.set(f.key, f.value);
  }
  for (const q of questions) {
    const k = '问题:' + q.question;
    if (values.has(k) && values.get(k) !== q.reference) conflicts.push(`同一问题存在不同参考内容：${q.question}`);
    values.set(k, q.reference);
  }
  // Note: Do not persist raw full text into IndexedDB question sets
  return {
    id: uid(),
    name,
    title,
    importedAt: Date.now(),
    questions,
    facts,
    conflicts,
    status: conflicts.length ? 'conflict' : 'ready',
    parser: 'v4.3-explicit-structure'
  };
}

export function knowledgeQuestions(k) {
  if (k.status !== 'ready') throw new Error('资料存在矛盾，请修正文件后再加入题库');
  return k.questions.map((q, i) => ({
    id: uid(),
    name: `观众${i + 1}`,
    content: q.question,
    question_text: q.question,
    reference: q.reference,
    reference_answer: q.reference,
    knowledgeId: k.id,
    product: k.title,
    stage: '产品知识',
    question_type: 'oral_qa',
    status: q.reference ? 'ready' : 'incomplete'
  }));
}
