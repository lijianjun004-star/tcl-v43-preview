import { parseDocumentFile } from './lib/parser.js';
import { extractQA, detectReviewConflicts } from './lib/qa-import.js';

const STORE_NAME='tcl-specialty-v3';
const BOARDS_RAW=await (await fetch('./training-boards.json')).json();
const LEGACY_RAW=await (await fetch('./legacy-65.json')).json();
const BOARDS=BOARDS_RAW.boards;
const ELEM=(id)=>document.getElementById(id);
const ESC=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>crypto?.randomUUID?.()||'id-'+Date.now()+'-'+Math.random().toString(16).slice(2);
const norm=(s)=>String(s||'').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
const containsPII=(s)=>/(?:1[3-9]\d{9})|(?:\b\d{16,19}\b)|(?:[\w.+-]+@[\w.-]+\.[a-z]{2,})/i.test(String(s||''));
const boardById=(id)=>BOARDS.find(x=>x.id===String(id))||BOARDS[0];
const iconFor=(s)=>/电视/.test(s)?'▣':/空调/.test(s)?'❄':/冰箱/.test(s)?'▤':/洗衣/.test(s)?'◎':/显示器/.test(s)?'▥':/门锁/.test(s)?'⌘':/生活/.test(s)?'⌖':'◈';
const nowIso=()=>new Date().toISOString();
let page='home', selectedBoard='01', activePlatform='京东', activeQuestionIndex=0, questions=[], recChunks=[], currentRecorder=null, micStream=null, camStream=null, answerAudioURL='', chatTimer=null, liveStarted=false, importCandidate=[], localEntries=[], localRecords=[], legacyCards=LEGACY_RAW.cards, cloud={base:'',token:'',role:'',name:''}, librarySearch='', importBoardId='01', importScope='platform', importPlatform='京东', selectedLibraryBoard='all', selectedLegacyFilter='all', uploadedFileName='';
let roomPhase='check', deviceCheckSeq=0, deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false}, lastDeviceError='';
let localDB=null, memoryFallback=false, cameraBusy=false;
let capturePending=false, captureSeq=0, sessionRecorder=null, sessionMicStream=null, sessionVideoStream=null, sessionChunks=[], sessionVideoBlob=null, sessionVideoURL='', sessionCaptureNote='', sessionVideoMeta=null;
let transcriptSeq=0, transcriptBusy=false, offlineTranscriber=null, chatQuestionSeq=0;
let videoRecorderFinalizing=false, sessionVideoDownloaded=false,ttsSpeaking=false,ttsToken=0;
// V3.3.6 mobile-safe pilot limits. Longer 30–60 minute sessions need incremental disk persistence and real-device QA.
const MAX_CAPTURE_BYTES=64*1024*1024, CAPTURE_WARN_BYTES=48*1024*1024;
const captureMaxMs=()=>Math.min(8*60*1000,Math.max(500,Number(window.__CAPTURE_MAX_MS)||8*60*1000));
let captureLimitTimer=null,sessionStopReason='',audioDecodeJob=null,modelLoadJob=null,asrInferJob=null,exitGuardInstalled=false;
function clearCaptureLimit(){if(captureLimitTimer!==null){clearTimeout(captureLimitTimer);captureLimitTimer=null;}}
function needsExitWarning(){return !!(capturePending||sessionRecorder?.state==='recording'||videoRecorderFinalizing||(sessionVideoBlob&&!sessionVideoDownloaded));}
function guardUnload(e){if(!needsExitWarning())return;e.preventDefault();e.returnValue='';}
function syncExitWarning(){const needed=needsExitWarning();if(needed===exitGuardInstalled)return;exitGuardInstalled=needed;window[needed?'addEventListener':'removeEventListener']('beforeunload',guardUnload);}
function recordedSeconds(blob){
 if(blob!==sessionVideoBlob||!sessionVideoMeta?.startedAt)return null;
 const endWall=sessionVideoMeta.stoppedAt??Date.now();
 if(endWall<sessionVideoMeta.startedAt)return -1;
 const wallSec=(endWall-sessionVideoMeta.startedAt)/1000;
 const monoSec=(Number.isFinite(sessionVideoMeta.startedMono)&&Number.isFinite(sessionVideoMeta.stoppedMono)&&sessionVideoMeta.stoppedMono>=sessionVideoMeta.startedMono)?(sessionVideoMeta.stoppedMono-sessionVideoMeta.startedMono)/1000:0;
 return Math.max(wallSec,monoSec);
}
function ensureDecodeBudget(blob){
 if(!blob?.size)throw new Error('原始录像不存在');
 // Check metadata before allocating an ArrayBuffer or starting an AudioContext.
 const seconds=recordedSeconds(blob);
 if(seconds!==null&&seconds<0)throw new Error('录像起止时间戳异常（可能发生系统时钟跳变），为保护内存已拒绝直接解码，请先下载原视频');
 if(seconds!==null&&seconds>180)throw new Error(`本机录后识别/音轨提取最多180秒，本次约${Math.ceil(seconds)}秒。请下载原录像后分段处理`);
 if(blob.size>48*1024*1024)throw new Error('录像超过48MB本机解码安全额度。请下载原录像后使用离线工具提取音轨');
}

const memStores={items:new Map(),records:new Map(),prefs:new Map()};
const dbOpen=()=>new Promise((resolve,reject)=>{
 if(!('indexedDB' in window))return reject(new Error('IndexedDB unavailable'));
 let settled=false;
 const timeoutMs=typeof window.__IDB_TIMEOUT_MS==='number'?window.__IDB_TIMEOUT_MS:10000;
 const timer=setTimeout(()=>{if(!settled){settled=true;reject(new Error('IndexedDB open timeout'));}},timeoutMs);
 const done=(fn,val)=>{if(!settled){settled=true;clearTimeout(timer);fn(val);}};
 try{
  const req=indexedDB.open(STORE_NAME,1);
  req.onupgradeneeded=()=>{const db=req.result;for(const name of ['items','records','prefs'])if(!db.objectStoreNames.contains(name))db.createObjectStore(name,{keyPath:'id'});};
  req.onsuccess=()=>{if(settled){try{req.result?.close?.();}catch{}return;}done(resolve,req.result);};
  req.onerror=()=>done(reject,req.error||new Error('IDB open error'));
  req.onblocked=()=>done(reject,new Error('IDB open blocked'));
 }catch(e){done(reject,e);}
});
const dbAll=(store)=>memoryFallback?Promise.resolve([...(memStores[store]?.values()||[])]):new Promise((resolve,reject)=>{const req=localDB.transaction(store,'readonly').objectStore(store).getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
const dbPut=(store,obj)=>memoryFallback?(memStores[store]?.set(obj.id,obj),Promise.resolve(obj.id)):new Promise((resolve,reject)=>{const req=localDB.transaction(store,'readwrite').objectStore(store).put(obj);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
const dbDelete=(store,id)=>memoryFallback?(memStores[store]?.delete(id),Promise.resolve()):new Promise((resolve,reject)=>{const req=localDB.transaction(store,'readwrite').objectStore(store).delete(id);req.onsuccess=()=>resolve();req.onerror=()=>reject(req.error);});
const toast=(message)=>{const el=ELEM('toast');el.textContent=message;el.classList.add('show');clearTimeout(toast.tm);toast.tm=setTimeout(()=>el.classList.remove('show'),3400)};
const categoryType=(b)=>b.category;
const platformOptions=(b)=>b.platforms;
const matchEntry=(entry,board,platform)=>entry.status==='published' && ((entry.scope==='category' && entry.category===board.category)||(entry.boardId===board.id && (entry.platform==='全部平台'||entry.platform===platform||entry.platform==='京东/天猫'&&['京东','天猫'].includes(platform)||board.id==='12'&&platform==='抖音'&&entry.platform==='抖音生活服务')));
function defaultEntries(){const rows=[];for(const b of BOARDS){for(const [index,e] of b.exercises.entries()){rows.push({id:`seed-${b.id}-${index}`,boardId:b.id,category:b.category,scope:'board',platform:'全部平台',question:e.question,answer:'',keyPoints:e.semantic_points||[],pointKeywords:e.semantic_keywords||[],source:'16板块研究底稿 · 教学示例（不作为正式标准答案）',status:'published',kind:'seed',reviewStatus:'教学示例 · 缺少经核准的标准答案',createdAt:nowIso()});}}return rows;}
const getEntries=()=>[...defaultEntries(),...localEntries];
const allPublishedFor=(board,platform)=>getEntries().filter(e=>matchEntry(e,board,platform));
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));

// V3.4 public-only simulation. Private workbook contents MUST NOT be bundled.
const DANMU_TEMPLATES=BOARDS_RAW.barrage_templates?.templates||[];
const COMPLIANCE_RULES=BOARDS_RAW.compliance_rules?.rules||[];
const MODEL_NAMES=BOARDS_RAW.public_model_names||{};
const platformGroup=p=>(p==='京东'||p==='天猫'||p==='京东/天猫')?'jd_tmall':'douyin';
const TRIGRAM=(s)=>{const n=norm(s);return [...new Set(Array.from({length:Math.max(0,n.length-1)},(_,i)=>n.slice(i,i+2)))]};
const fuzzyPoint=(point,text,aliases=[])=>{
  const p=norm(point),t=norm(text),alts=[p,...(Array.isArray(aliases)?aliases:[]).map(norm)].filter(Boolean);
  if(!p||!t)return false;
  const neg=p.match(/^(不|不要|不得|禁止|严禁|避免|不可|不能)/)?.[0]||'';
  const aliasHit=(a)=>a.length>=2&&t.includes(a);
  if(neg){
   // A negative/verification cue must govern the matched concept, not merely occur
   // somewhere nearby. Exact negative wording remains valid even for short points.
   if(t.includes(p))return true;
   const cueGoverns=(a)=>{
    if(!aliasHit(a))return false;
    let from=0;
    while(true){
     const idx=t.indexOf(a,from);if(idx<0)return false;
     const before=t.slice(Math.max(0,idx-8),idx);
     const after=t.slice(idx+a.length,Math.min(t.length,idx+a.length+12));
     const negPrefix=/(?:不|不会|不再|别|勿|莫|避免|禁止|严禁|不可|不能|不得|不要)(?:直接|轻易|随意|明确|主动|一概)?(?:承诺|保证|宣称|夸大|虚构)?$/;
     const negSuffix=/^(?:也要|要)?(?:不|不会|不再|别|勿|莫|避免|禁止|严禁|不可|不能|不得|不要)(?:直接|轻易|随意|明确|主动|一概)?(?:承诺|保证|宣称|夸大|虚构)/;
     const verifyBefore=/(?:需要|先|分别)核对$/;
     const verifyAfter=/^(?:(?:也要|要)?以.{0,6}为准|(?:需要|先|分别)核对)/;
     if(negPrefix.test(before)||negSuffix.test(after)||verifyBefore.test(before)||verifyAfter.test(after))return true;
     from=idx+Math.max(1,a.length);
    }
   };
   if(Array.isArray(aliases)&&aliases.length){
    const selfSafeAlias=(a)=>/^(?:不|别|勿|莫|避免|禁止|严禁|不可|不能|不得|不要)/.test(a)||/(?:核对|为准)$/.test(a)||a==='每类不同';
    return alts.some(a=>aliasHit(a)&&(selfSafeAlias(a)||cueGoverns(a)));
   }
   // Uploaded/reviewed questions have no controlled aliases. First try the full
   // concept (also preserves short paraphrases such as 禁止夸大→严禁夸大), then
   // fall back to legacy fuzzy chunks while keeping the cue bound to a chunk.
   const concept=p.slice(neg.length);
   if(concept.length>=2&&cueGoverns(concept))return true;
   if(concept.length<4)return false;
   const chunks=TRIGRAM(concept),matched=chunks.filter(c=>t.includes(c));
   if(chunks.length<=1||matched.length/chunks.length<0.66)return false;
   return matched.some(cueGoverns);
  }
  if(alts.some(aliasHit))return true;
  // For seed questions, semantic_keywords provide controlled synonyms. If none hit,
  // retain the legacy fuzzy fallback for uploaded/reviewed questions only.
  if(Array.isArray(aliases)&&aliases.length)return false;
  if(p.length<4)return false;
  const chunks=TRIGRAM(p);
  return chunks.length>1&&chunks.filter(c=>t.includes(c)).length/chunks.length>=0.66;
};
const complianceHints=(text,platform)=>{
 const group=platformGroup(platform),found=[];
 for(const rule of COMPLIANCE_RULES){
  if(rule.platform_group!=='common'&&rule.platform_group!==group)continue;
  try{
   const match=new RegExp(rule.pattern,'i').exec(String(text||''));
   if(match)found.push({id:rule.id,category:rule.category,matched:match[0],level:rule.level,
    manual:!!rule.manual_review,suggestion:rule.suggestion});
  }catch(e){console.warn('invalid public compliance rule',rule.id)}
 }
 if(group==='jd_tmall'){
  const cross=platform==='京东'?/(天猫|淘宝|某宝)/i:platform==='天猫'?/(京东|某东)/i:null;
  const match=cross?.exec(String(text||''));
  if(match){
   const base=COMPLIANCE_RULES.find(r=>r.id==='CR07');
   found.push({id:'CR07',category:base?.category||'提及/比较其他平台',matched:match[0],level:base?.level||'P0',manual:true,suggestion:base?.suggestion||'当前直播间不提其他平台，不做平台比较'});
  }
 }
 return found;
};
const randomOf=(arr)=>arr[Math.floor(Math.random()*arr.length)];
const modelCategory=(category)=>/冰箱/.test(category)?'冰箱':/空调/.test(category)?'空调':/洗衣/.test(category)?'洗衣机':/显示器/.test(category)?'显示器':/电视/.test(category)?'电视':'';
// Public model names were already present in V3.4; never load private product talk tracks.
// Each question must point to a real public-listed model/series or use a category-level fallback.
const parsePublicModels=(label,category)=>{
 const raw=String(label||'').replace(/\s*\n\s*/g,' ').trim();
 if(!raw)return [];
 if(category!=='电视')return [raw];
 // Single size-prefixed labels are ambiguous SKU-style entries: drop rather than invent a series name.
 if(/^\d{2,3}[A-Za-z]/.test(raw))return [];
 const stripped=raw.replace(/^(?:\d{2,3}\/)+\d{2,3}\s*/,'').trim();
 if(!stripped||/^\d{2,3}(?:\/\d{2,3})*$/.test(stripped))return [];
 return stripped.split('/').map(x=>x.trim()).filter(x=>x&&/[A-Za-z]/.test(x)&&!/^\d{2,3}$/.test(x));
};
const cleanPublicModel=(label,category)=>parsePublicModels(label,category)[0]||'';
const publicModels=(category)=>[...new Set((MODEL_NAMES[category]||[]).flatMap(x=>parsePublicModels(x,category)).filter(Boolean))];
const modelContext=(board)=>{
 const categoryName=String(board?.category||'');
 // There is no verified ThunderBird brand model list in V3.4. Never use TCL models here.
 if(/雷鸟/.test(categoryName))return {label:categoryName,second:'',hasModel:false,productCategory:''};
 let category=modelCategory(categoryName);
 if(/全品类/.test(categoryName)){
  const categories=['电视','冰箱','空调','洗衣机','显示器'].filter(k=>publicModels(k).length);
  category=categories.length?randomOf(categories):'';
 }
 const candidates=category?publicModels(category):[];
 if(!candidates.length)return {label:categoryName||'家电',second:'',hasModel:false,productCategory:category};
 const model=randomOf(candidates);
 const others=candidates.filter(name=>name!==model);
 const prefix=/全品类/.test(categoryName)?`TCL${category} `:'';
 return {label:prefix+model,second:others.length?prefix+randomOf(others):'',hasModel:true,productCategory:category};
};
const templateText=(pattern,board,ctx=modelContext(board),platform='')=>{
 const product=ctx.productCategory||modelCategory(board.category);
 const sizes=product==='显示器'?[24,27,32]:[55,65,75,85];
 const parameter={电视:'HDMI接口',显示器:'刷新率',空调:'能效与制冷',冰箱:'容量与保鲜',洗衣机:'洗涤程序'}[product]||(/智能门锁/.test(board.category)?'开锁方式和电池状态':'使用条件');
 const scene={电视:'看电影',显示器:'办公或游戏',空调:'卧室制冷',冰箱:'家庭食材存储',洗衣机:'日常洗护'}[product]||(/智能门锁/.test(board.category)?'家庭入户安全':'日常使用');
 const values={型号:ctx.label,对比型号:ctx.second||ctx.label,尺寸:String(randomOf(sizes)),数字:String(randomOf([3,4,5])),参数:parameter,场景:scene,平台:platform||'当前平台'};
 // Defensive migration for any historical templates that still used "{n}号".
 return String(pattern).replace(/\{n\}号/g,ctx.label).replace(/\{n\}/g,ctx.label)
  .replace(/\{(型号|对比型号|尺寸|数字|参数|场景|平台)\}/g,(_,key)=>values[key]);
};
const pickDanmu=(board,platform,mode='question')=>{
 if(mode==='question'&&/本地生活/.test(board.category)){
  const text=randomOf(['套餐具体包含哪些项目？','哪些门店可以使用这个套餐？','购买后怎么预约和核销？','有效期和使用限制在哪里核实？']);
  return {id:uid(),text,needsAnswer:true,priority:false,templateId:'local-life-safe'};
 }
 if(mode==='question'&&/智能门锁/.test(board.category)){
  const text=randomOf(['这类智能门锁支持哪些开锁方式？','安装前需要确认哪些门体条件？','电池续航和低电量提醒怎么查看？','安装和售后服务在哪里核实？']);
  return {id:uid(),text,needsAnswer:true,priority:false,templateId:'smart-lock-safe'};
 }
 let pool=DANMU_TEMPLATES.filter(t=>t.platform_group===platformGroup(platform));
 if(mode==='question')pool=pool.filter(t=>t.needs_answer&&!t.priority);
 else if(mode==='chatter')pool=pool.filter(t=>!t.needs_answer);
 else if(mode==='complaint')pool=pool.filter(t=>t.priority);
 if(!/电视|显示器/.test(board.category))pool=pool.filter(t=>!/\{尺寸\}|英寸/.test(t.text));
 // No SKU claim in a category without verified public models.
 const ctx=modelContext(board);
 if(!ctx.hasModel)pool=pool.filter(t=>!t.requires_multiple_models);
 const t=pool.length?randomOf(pool):{id:'fallback',text:'{型号}有哪些需要了解的功能？',needs_answer:true,priority:false};
 // No verified models for this brand/category? Ask useful general questions instead of
 // implying a specific live product, cart number, price or promotion exists.
 const genericQuestions={
  ask_price:'{型号}现在有哪些系列可以了解？',
  ask_model:'{型号}现在有哪些系列？',
  ask_feature:'{型号}主要有哪些功能？',
  ask_discount:'{型号}的活动信息在哪里核实？',
  ask_compare:'{型号}不同系列有什么区别？',
  ask_followup:'{型号}适合哪些使用场景？安装和售后怎么了解？'
 };
 const type=t.id.split('-').slice(1).join('-');
 const pattern=!ctx.hasModel&&(genericQuestions[type]||null)||
  (t.requires_multiple_models&&!ctx.second?'{型号}有哪些功能？':t.text);
 const text=templateText(pattern,board,ctx,platform);
 return {id:uid(),text,needsAnswer:!!t.needs_answer,priority:!!t.priority,templateId:t.id};
};
// Per-question records use an immutable turn ID; audio bytes remain only in memory.
let runId='',activeTurn=null,sessionTurns=[],recordingTurn=null,oneShotAsrJob=null;
const perQuestionAudio=new Map();
let questionAsrQueue=[],voskPreloadSeq=0;
let chatExtraTimers=[];
function cancelVoskPreload(){voskPreloadSeq++;}
function resetRunState({cancelPreload=true}={}){
 runId='';activeTurn=null;sessionTurns=[];recordingTurn=null;questionAsrQueue=[];perQuestionAudio.clear();activeQuestionIndex=-1;
 if(cancelPreload)cancelVoskPreload();
}
function setVoskPreloadUi(message,busy=false){
 const status=ELEM('transcribeStatus'),tip=ELEM('preLiveVoskTip'),pre=ELEM('preloadBeforeStart'),review=ELEM('preloadVoskBtn');
 if(status&&message)status.textContent=message;if(tip&&message)tip.textContent=message;
 if(pre){pre.disabled=busy;pre.textContent=voskModel?'✓ Vosk 中文模型已就绪':busy?'正在下载/校验 Vosk…':'预下载/校验Vosk（约48MB）';}
 if(review){review.disabled=busy||transcriptBusy;review.textContent=voskModel?'✓ Vosk 中文模型已就绪':busy?'正在下载/校验 Vosk…':'预下载/校验 Vosk 中文模型（48MB）';}
}

function saveCurrentTypedAnswer({asDraft=true}={}){
 const turn=activeTurn,field=ELEM('answerText');
 if(!turn||!field||page!=='training'||turn.runId!==runId||turn.boardId!==selectedBoard||turn.platform!==activePlatform)return;
 const entered=field.value.trim();
 if(!entered||entered===turn.answer)return;
 turn.answer=entered;
 turn.compliance=complianceHints(entered,turn.platform);
 turn.pointsHit=(turn.keyPoints||[]).filter((point,i)=>fuzzyPoint(point,entered,turn.pointKeywords?.[i]||[]));
 if(asDraft)turn.asrStatus=turn.transcript?'已编辑识别文字（草稿已存）':'手动填写（草稿已存）';
 void saveTurn(turn);renderQuestionSummary();
}
function enqueueRecordedQuestions(){
 if(!voskModel||page!=='training'||!runId)return;
 for(const turn of sessionTurns){
  if(turn.runId===runId&&perQuestionAudio.has(turn.id)&&!turn.transcript)enqueueQuestionAsr(turn.id);
 }
}
const saveTurn=async(turn)=>{
 if(!turn||page!=='training'||turn.runId!==runId||turn.boardId!==selectedBoard||turn.platform!==activePlatform)return;
 const record={id:turn.id,boardId:turn.boardId,category:turn.category,platform:turn.platform,
  question:turn.prompt,trainingHint:turn.trainingHint,answer:turn.answer||'',transcript:turn.transcript||'',rawTranscript:turn.rawTranscript||'',
  responseSeconds:turn.responseSeconds??null,durationSeconds:turn.durationSeconds??null,
  compliance:turn.compliance||[],matchedKeywords:turn.pointsHit?.length||0,
  keywordTotal:turn.keyPoints?.length||0,asrStatus:turn.asrStatus||'待录音',
  result:'训练记录（仅提示，未进行正式AI评分）',createdAt:turn.createdAt};
 try{
  await dbPut('records',record);
  if(page!=='training'||runId!==turn.runId||selectedBoard!==turn.boardId||activePlatform!==turn.platform)return;
  const pos=localRecords.findIndex(r=>r.id===record.id);
  if(pos>=0)localRecords[pos]=record;else localRecords.unshift(record);
 }catch(e){toast('本题记录保存失败，请导出个人记录备份：'+(e.message||e))}
};
function renderTurnStatus(turn){
 if(!turn)return;
 if(activeTurn?.id===turn.id){
  const status=ELEM('turnStatus');
  if(status)status.textContent=`弹幕响应：${turn.responseSeconds===null?'待回答':turn.responseSeconds+'秒'} · 回答时长：${turn.durationSeconds===null?'待录音':turn.durationSeconds+'秒'} · ${turn.asrStatus||'待录音'}`;
  const answer=ELEM('answerText');
  if(answer&&turn.transcript&&!answer.value.trim())answer.value=turn.transcript;
  const hints=ELEM('turnHints');
  if(hints){
   const flags=(turn.compliance||[]).map(x=>`${x.manual?'需人工复核':'风险提示'}｜${x.category}：${x.matched}；${x.suggestion}`).join('；');
   hints.textContent=`参考要点覆盖 ${turn.pointsHit?.length||0}/${turn.keyPoints?.length||0}（关键词/同义表达自查，非AI评分）${flags?'；'+flags:'；未触发内置风险词'}`;
  }
 }
 const summary=ELEM('questionSummary');if(summary)renderQuestionSummary();
}
function renderQuestionSummary(){
 const el=ELEM('questionSummary');if(!el)return;
 el.replaceChildren();
 if(!sessionTurns.length){el.textContent='本场尚无逐题回答。';return;}
 const table=document.createElement('table');table.className='question-summary-table';
 const head=document.createElement('thead');head.innerHTML='<tr><th>弹幕问题</th><th>响应用时</th><th>回答时长</th><th>回答文字（可人工校正）</th><th>转写状态 / 操作</th></tr>';
 table.append(head);
 const body=document.createElement('tbody');
 for(const turn of sessionTurns){
  const tr=document.createElement('tr');
  for(const value of [turn.prompt,turn.responseSeconds==null?'—':turn.responseSeconds+'秒',turn.durationSeconds==null?'—':turn.durationSeconds+'秒']){
   const td=document.createElement('td');td.textContent=value;tr.append(td);
  }
  const answerCell=document.createElement('td');
  answerCell.textContent=turn.answer||turn.transcript||(perQuestionAudio.has(turn.id)?'已录音，尚未获得文字':'尚无文字，请填写回答或录音');
  if(turn.rawTranscript){
   const details=document.createElement('details'),summary=document.createElement('summary'),raw=document.createElement('div');
   summary.textContent='查看模型识别原文';raw.textContent=turn.rawTranscript;
   details.append(summary,raw);answerCell.append(details);
  }
  tr.append(answerCell);
  const actions=document.createElement('td');
  const status=document.createElement('div');status.textContent=turn.asrStatus||'待录音';actions.append(status);
  if(perQuestionAudio.has(turn.id)&&!turn.transcript){
   const btn=document.createElement('button');btn.type='button';btn.className='btn soft';
   btn.textContent=voskModel?'补转写':'准备Vosk并补转写';
   btn.disabled=!!oneShotAsrJob||!!transcriptBusy||!!voskLoadJob;
   btn.onclick=()=>voskModel?transcribeQuestion(turn.id):preloadVoskModel();actions.append(btn);
  }
  tr.append(actions);body.append(tr);
 }
 table.append(body);el.append(table);
}

function enqueueQuestionAsr(turnId){
 const turn=sessionTurns.find(t=>t.id===turnId);
 if(!turn||!perQuestionAudio.has(turnId)||turn.transcript||!voskModel)return;
 if(!questionAsrQueue.includes(turnId))questionAsrQueue.push(turnId);
 turn.asrStatus=(oneShotAsrJob||audioDecodeJob||asrInferJob||transcriptBusy)?'排队等待转写':'待自动转写';
 renderTurnStatus(turn);void drainQuestionAsrQueue();
}
async function drainQuestionAsrQueue(){
 if(oneShotAsrJob||audioDecodeJob||asrInferJob||transcriptBusy||!voskModel)return;
 if(recorderPending||recorderFinalizing||currentRecorder?.state==='recording')return;
 const next=questionAsrQueue.shift();if(!next)return;
 await transcribeQuestion(next,{queued:true});
}
async function transcribeQuestion(turnId,{queued=false}={}){
 const turn=sessionTurns.find(t=>t.id===turnId),audio=perQuestionAudio.get(turnId);
 if(!turn||!audio)return toast('当前题目没有可补转写的音频');
 if(recorderPending||recorderFinalizing||currentRecorder?.state==='recording')return toast('正在录音或整理音频，结束后才能补转写');
 if(!voskModel){turn.asrStatus='模型未就绪，点击准备Vosk并补转写';renderTurnStatus(turn);if(!queued)await preloadVoskModel();return;}
 if(oneShotAsrJob||audioDecodeJob||asrInferJob||transcriptBusy){
  if(queued){if(!questionAsrQueue.includes(turnId))questionAsrQueue.push(turnId);turn.asrStatus='排队等待转写';renderTurnStatus(turn);}
  else toast('已有识别任务，不能同时解码另一题');
  return;
 }
 const ownerRun=turn.runId,ownerBoard=turn.boardId,ownerPlatform=turn.platform,ownerAudioRevision=turn.audioRevision||0,ownerAsrRevision=turn.asrRevision||0;
 const valid=()=>runId===ownerRun&&page==='training'&&selectedBoard===ownerBoard&&activePlatform===ownerPlatform&&perQuestionAudio.get(turnId)===audio&&(turn.audioRevision||0)===ownerAudioRevision&&(turn.asrRevision||0)===ownerAsrRevision;
 turn.asrStatus='正在录后转写…';renderTurnStatus(turn);
 const job=(async()=>{
  try{
   const raw=await awaitBounded(decodeAudioCopy(audio),Number(window.__ASR_DECODE_TIMEOUT_MS)||60000,'单题音频解码');
   if(!valid())return;
   const trimmed=trimAsrSilence(raw,16000);
   if(!trimmed.hasSpeech)throw new Error('有效语音不足1秒');
   const result=await awaitBounded(recognizeVosk(voskModel,trimmed.pcm,valid),Number(window.__ASR_INFER_TIMEOUT_MS)||240000,'单题Vosk识别');
   if(!valid())return;
   const assessed=assessAsrText(String(result?.text||''));
   if(!assessed.text)throw new Error('模型没有返回有效中文文字');
   const numeric=normalizeSpokenNumbers(assessed.text);
   turn.transcript=numeric.text;turn.rawTranscript=String(result?.text||'').trim();
   if(!turn.answer)turn.answer=numeric.text;
   turn.asrWarnings=[...(assessed.warnings||[]),...(numeric.changes?['已规范化'+numeric.changes+'处明确的口述数值，请重点核对数字/型号']:[])];
   if(/(?:\d|[零〇○一二两三四五六七八九十百千万点]{1,20}(?:英寸|寸|匹|元|块钱|块|秒|分钟|度|瓦|赫兹|公斤|千克|升|厘米|毫米|平方米|平米))/.test(turn.transcript)&&!turn.asrWarnings.some(x=>x.includes('数字'))){turn.asrWarnings.push('数字与型号请对照音频核对，识别错误不会自动猜测修正');}
   turn.compliance=complianceHints(turn.answer||turn.transcript,turn.platform);
   turn.pointsHit=(turn.keyPoints||[]).filter((point,i)=>fuzzyPoint(point,turn.answer||turn.transcript,turn.pointKeywords?.[i]||[]));
   turn.asrStatus=turn.asrWarnings.length?'已转写（请核对文本；'+turn.asrWarnings.join('；')+'）':'已转写（请核对文本）';
   await saveTurn(turn);if(valid())renderTurnStatus(turn);
  }catch(e){
   if(!valid())return;
   turn.asrStatus='转写未完成：'+(e?.message||e);
   await saveTurn(turn);renderTurnStatus(turn);
  }
 })();
 oneShotAsrJob=job;
 try{await job}finally{if(oneShotAsrJob===job)oneShotAsrJob=null;if(valid())renderQuestionSummary();void drainQuestionAsrQueue();}
}

function closeMenu(){ELEM('sidebar')?.classList.remove('open');ELEM('menuBtn')?.setAttribute('aria-expanded','false');ELEM('menuScrim')?.classList.remove('visible')}
function toggleMenu(){const expanded=!ELEM('sidebar')?.classList.contains('open');ELEM('sidebar')?.classList.toggle('open',expanded);ELEM('menuScrim')?.classList.toggle('visible',expanded);ELEM('menuBtn')?.setAttribute('aria-expanded',String(expanded))}
function closeDrawer(){ELEM('trainingControls')?.classList.remove('show-live-controls');ELEM('drawerScrim')?.classList.remove('visible');ELEM('focusReview')?.setAttribute('aria-expanded','false')}
function setTitle(t){ELEM('pageTitle').textContent=t;document.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));closeMenu();}
function updateMode(){const online=!!cloud.base&&!!cloud.token;ELEM('modeDot').classList.toggle('online',online);ELEM('modeText').textContent=online?'已连接云端（需查询同步）':memoryFallback?'本机内存临时预览（受浏览器限制未持久化）':'本机独立预览 · 未云同步';}
async function remote(path,method='GET',body){if(!cloud.base)throw new Error('尚未配置云端 API');const res=await fetch(cloud.base+path,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(cloud.token?{'Authorization':'Bearer '+cloud.token}:{})},...(body?{body:JSON.stringify(body)}:{})});let j;try{j=await res.json()}catch{throw new Error(`服务器返回非JSON（HTTP ${res.status}）`)}if(!res.ok)throw new Error(j.error||`请求失败：${res.status}`);return j;}
function canLeaveRecording(){
 if(capturePending||roomPhase==='live')return toast('请先结束直播，确保录像封装完成后再离开'),false;
 if(videoRecorderFinalizing)return toast('录像封装中，请等到下载按钮出现后再切换'),false;
 if(sessionVideoBlob&&!sessionVideoDownloaded&&!window.confirm('当前原始录像还没有下载。继续切换将丢失本页录像，确定离开？'))return false;
 return true;
}
function discardVideoArchive(){cancelTranscript();if(sessionVideoURL){URL.revokeObjectURL(sessionVideoURL);sessionVideoURL=''}sessionVideoBlob=null;sessionVideoMeta=null;sessionVideoDownloaded=false;sessionCaptureNote='';sessionChunks=[];syncExitWarning();}
function nav(to){if(!canLeaveRecording())return;resetRunState();deviceCheckSeq++;stopScene();captureSeq++;discardVideoArchive();exitFocus();if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}roomPhase='check';deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};page=to;render();window.scrollTo({top:0,behavior:'instant'});}
function home(){setTitle('品类专项训练');const total=localEntries.filter(x=>x.status==='published').length;ELEM('view').innerHTML=`
<section class="hero"><div><span class="eyebrow">NEW STREAMER PRACTICE STUDIO</span><h2>从真实弹幕出发，练出你的直播应答能力</h2><p>按品类与平台进入专项训练；运营上传顾客真实提问及优秀回答，审核后进入知识库。直播间只保留竖屏画面和模拟用户弹幕，摄像头可选，训练结果单独保存。</p></div><button class="btn primary" id="startFirst">开始专项训练 →</button></section>
<section class="stats"><div class="stat"><span>专项训练板块</span><b>16</b><small>结构固定 · 无真人姓名</small></div><div class="stat"><span>基础训练场景</span><b>48</b><small>教学提纲，不冒充正式答案</small></div><div class="stat"><span>已审核新增问答（本机）</span><b>${total}</b><small>开启云端后需单独同步</small></div><div class="stat"><span>历史拓展话术卡</span><b>65</b><small>保留原文 · 未获合规审核</small></div></section>
<section class="section-title" id="boardChooser"><div><h2>选择训练品类与平台</h2><p>16 个板块全部开放，不限定完成顺序。雷鸟显示器为单独入口，内部切换三个平台。</p></div></section>
<div class="board-grid">${BOARDS.map(b=>`<button class="board-card" data-open-board="${b.id}"><span class="count">NO. ${b.id}</span><span class="mini-icon">${iconFor(b.category)}</span><strong>${ESC(b.category)}</strong><small>${ESC(b.display_platform)}</small><span class="enter">进入训练 →</span></button>`).join('')}</div>
<section class="section-title"><h2>进阶拓展中心</h2></section><div class="panel"><strong>原 12 周养成 · 65 张历史话术卡</strong><p class="muted">与专项训练并列开放，保留原始卡片和学习结构。涉及价格、政策、赠品、时限及产品参数的历史内容未审核，不作为直接直播或正式自动评分答案。</p><button class="btn dark" id="toLegacy">进入拓展学习</button></div>
<p class="footer-note">当前为独立测试站。原站没有改动；模拟弹幕仅来自训练资料，不与任何真实直播间、账号或互动数据连接。</p>`;
ELEM('startFirst').onclick=()=>ELEM('boardChooser').scrollIntoView({behavior:'smooth',block:'start'});ELEM('toLegacy').onclick=()=>nav('legacy');document.querySelectorAll('[data-open-board]').forEach(b=>b.onclick=()=>openBoard(b.dataset.openBoard));}
function openBoard(id){if(!canLeaveRecording())return;resetRunState();deviceCheckSeq++;stopScene();captureSeq++;discardVideoArchive();exitFocus();if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}selectedBoard=id;activePlatform=boardById(id).platforms[0];roomPhase='check';deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};page='training';render();}
function quickSwitchBoard(id,platform=''){if(!BOARDS.some(b=>b.id===id)){if(ELEM('quickBoardSelect'))ELEM('quickBoardSelect').value=selectedBoard;return;}openBoard(id);if(selectedBoard!==id||roomPhase!=='check'){if(ELEM('quickBoardSelect'))ELEM('quickBoardSelect').value=selectedBoard;return;}const b=boardById(id);if(platform&&b.platforms.includes(platform)){activePlatform=platform;trainingHome();}}
function categoryPlatformChoices(b){const same=BOARDS.filter(q=>q.category===b.category);const opts=[];for(const x of same){for(const p of x.platforms){opts.push({boardId:x.id,platform:p,selected:x.id===b.id&&p===activePlatform,label:p==='抖音生活服务'?'抖音':p});}}return opts;}
function trainingHome(){
const b=boardById(selectedBoard);
setTitle(`${b.category} · 开播准备`);
ELEM('view').innerHTML=`
<div class="intro-block slim-intro"><button class="ghost-btn" id="backBoard">← 返回16个板块</button><h2>${ESC(b.category)} · 直播训练</h2><p class="muted">先检查设备，进入开播准备，再点击「开始直播」切换到真正的竖屏模拟直播间。不连接抖音，不会推流。</p></div>
<div class="quick-select"><label for="quickBoardSelect">自由选择专项</label><select id="quickBoardSelect" aria-label="选择16个专项训练板块">${BOARDS.map(x=>`<option value="${ESC(x.id)}" ${x.id===b.id?'selected':''}>${ESC(x.id)} · ${ESC(x.category)} · ${ESC(x.display_platform)}</option>`).join('')}</select><button type="button" id="showAllBoards" class="btn soft">全部16个板块 ▾</button></div>
<div class="board-quick-panel hidden" id="boardQuickPanel">${BOARDS.map(x=>`<button type="button" data-switch-board="${ESC(x.id)}">${ESC(x.id)} · ${ESC(x.category)} · ${ESC(x.display_platform)}</button>`).join('')}</div>
<div class="toolbar"><div class="segmented" id="platforms">${categoryPlatformChoices(b).map(x=>`<button data-board-p="${ESC(x.boardId)}" data-p="${ESC(x.platform)}" class="${x.selected?'selected':''}">${ESC(x.label)}</button>`).join('')}</div></div>
<div class="live-layout danmu-layout room-flow">
  <div class="live-phone danmu-phone" id="livePhone" aria-label="竖屏模拟直播间">
    <div class="live-bg"></div><div class="camera-nine-sixteen" aria-label="9比16原始画面完整显示"><video class="live-video" muted autoplay playsinline webkit-playsinline id="liveCam"></video></div>
    <div class="room-placeholder" id="roomPlaceholder"><div class="room-icon">◎</div><strong>主播画面预览</strong><p>设备检测后显示摄像头画面<br>仅模拟练播，不会真实开播</p></div>
    <div class="live-head"><div class="live-profile"><span class="live-avatar">T</span><span><strong>模拟训练直播间</strong><small>${ESC(b.category)} · ${ESC(activePlatform)}</small></span></div><span class="live-badge" id="liveStatus">● 开播前</span><span class="viewer" id="viewer">模拟观众 · 0</span></div>
    <span class="room-live-mark">训练模拟 · 非真实开播</span>
    <div class="barrage" id="barrage" role="log" aria-live="polite" aria-label="模拟观众弹幕"><div class="chat-line system"><strong>训练提示</strong><span>完成设备检查，再开始直播。</span></div></div>
    <div class="live-foot"><div class="chat-ghost">说点什么… <span>模拟弹幕</span></div><span class="danmu-bubble" aria-hidden="true">•••</span></div>
    <div class="pre-live-actions" id="preLiveActions"><span class="pre-live-label">开播准备 · 画面仅自己可见</span><div class="pre-live-heading">准备好开始今天的练播了吗？</div><p>点击开始直播后将立即切换到沉浸式直播画面，模拟顾客弹幕才会出现。</p><p class="scene-tip" id="preLiveVoskTip">Vosk 未就绪时建议先下载模型；不强制下载，录完后可补转写。</p><button class="btn soft" id="preloadBeforeStart" type="button">预下载/校验Vosk（约48MB）</button><button class="btn primary pre-start-btn" id="startScene">开始直播</button><button class="pre-back-btn" id="preBack">← 返回设备检查</button></div>
    <button class="focus-close" id="focusClose" type="button">结束直播</button><button class="focus-next" id="focusNext" type="button">下一条弹幕 ›</button><button class="focus-speak" id="focusSpeak" type="button" aria-label="朗读当前弹幕">🔊 朗读弹幕</button><button class="focus-review" id="focusReview" type="button">回答与复盘</button><button class="focus-mic" id="focusMic" type="button">● 开始录音</button>
  </div>
  <div class="trainer danmu-trainer" id="trainingControls">
    <div class="panel compact-panel check-panel"><div class="train-headline"><h2>① 开播前设备检查</h2><span class="pill">${ESC(b.id)} / 16</span></div>
      <div class="progress-row"><span>直播平台 <b>${ESC(activePlatform)}</b></span><span>可练弹幕 <b id="questionCount">—</b></span></div>
      <div class="device-grid"><div id="cameraState" class="device-state">摄像头：未检查</div><div id="micState" class="device-state">麦克风：未检查</div><div id="recorderState" class="device-state">录音支持：未检查</div><div id="networkState" class="device-state">运行环境：未检查</div></div>
      <div id="cameraDetails" class="scene-tip">将按摄像头真实比例显示：接近 9:16 的竖屏画面铺满，其他比例完整显示；不允许浏览器裁切放大。</div><div id="checkSummary" class="scene-tip">点击检查后才申请设备权限。失败时停留在当前页面并显示原因。</div>
      <div class="toolbar"><button class="btn primary" id="runDeviceCheck">检查全部设备</button><button class="btn" id="cameraBtn">手动开关摄像头</button></div>
      <div class="toolbar"><button class="btn primary" id="enterPrep" disabled>② 进入开播准备</button><button class="btn soft" id="textFallback">仅文字模拟练播</button></div>
      <p class="scene-tip" id="voskBeforeLive">建议开播前预下载/校验 Vosk 中文模型（约48MB）；未就绪也可练播，录音将暂存本页并支持补转写。</p><p class="scene-tip">手机真实摄像头和麦克风通常需要 HTTPS 及用户授权；设备检测失败不会伪装成通过。仅文字模式会明确关闭录音功能。</p>
    </div>
    <div class="panel compact-panel learning-panel"><div class="q-meta"><span class="pill" id="questionStage">弹幕问题</span><span class="pill" id="questionSource">教学示例</span></div>
      <div class="training-question" id="currentQuestion">开始模拟直播后，训练弹幕会出现在直播画面中。</div>
      <div class="toolbar"><button class="btn dark" id="nextQuestion">下一条弹幕 →</button><button class="btn soft" id="speakQuestion">🔊 免费中文朗读</button><button class="btn soft" id="showReference">查看参考回答</button></div><div id="referenceBox" class="tintbox hidden"></div></div>
    <div class="panel compact-panel review-panel"><div class="train-headline"><h2>③ 回答与复盘</h2><button class="ghost-btn review-close" id="closeReview">返回直播画面 ×</button></div><p class="scene-tip">开播后自动开始整场音视频录制，单题录音用于回听；支持系统自带免费中文弹幕朗读（需手动触发，可能依赖系统语音包）。结束直播后可尝试从视频副本中识别文字。原录像不转码、不重排时间轴。</p>
      <div class="toolbar"><button class="btn primary" id="recordBtn">开始录音</button><button class="btn" id="recordStopBtn" disabled>结束录音</button></div>
      <div id="recordStatus" class="scene-tip">尚未录音</div><div id="turnStatus" class="scene-tip">等待本题</div><div id="turnHints" class="scene-tip">逐题合规及要点提示将在录后出现。</div><button class="btn soft" id="retryQuestionAsr" type="button">本题补转写（需先预下载Vosk）</button><div id="audioHolder"></div>
      <div class="field" style="margin-top:12px"><label>我的回答（可编辑）</label><textarea id="answerText" rows="4" placeholder="说完后记录答案，对照参考话术复盘。"></textarea></div>
      <div class="toolbar"><button class="btn primary" id="submitAnswer">保存本次练习</button></div><div id="scoreBox"></div></div>
  </div>
<div class="panel after-live" id="sessionReview" aria-live="polite"><h2>逐题回答汇总</h2><p class="scene-tip">逐题汇总需要每题点击「开始录音」→「结束录音」，或使用浏览器语音识别；仅点击「开始直播」开启的整场录像不会自动生成各题文字。先预下载 Vosk，单题录音结束后会自动转写，已保留在本页的录音也可补转写。数字/型号不准确时，请在「我的回答」里纠正并保存；不会擅自把整场识别文字分给某题。</p><div id="questionSummary" aria-live="polite"></div><h2>整场录像与录后识别</h2><div id="sessionArchiveStatus" class="scene-tip">本机安全测试最多连续录制8分钟；已收集的录像分块达到64MB时停止。由于浏览器可能延迟派发大数据块，这不是硬性内存限制。结束后请立即下载原视频；30–60分钟录制需分段落盘后另行验收。</div><div id="sessionArchiveHolder"></div><div class="toolbar"><button id="transcribeVideoBtn" class="btn primary" disabled>从录像副本提取音频并转文字（默认Vosk中文）</button><button id="transcribeWhisperBtn" class="btn soft" disabled>备用 Whisper 试验识别</button><button id="preloadVoskBtn" class="btn soft" type="button">预下载/校验 Vosk 中文模型（48MB）</button><button id="downloadWavBtn" class="btn soft" disabled>导出独立音频 WAV</button></div><p class="scene-tip">本机录后转写及WAV提取只支持最长180秒且不超过48MB的录像。更长录像请先下载原文件，使用独立离线工具分段处理；模型首次需联网，不保证中国大陆可达。</p><div id="transcribeStatus" class="scene-tip"></div><div class="field"><label for="postTranscript">整场录后文字（可编辑，不自动作为评分）</label><textarea id="postTranscript" rows="5" placeholder="录制完成后点击识别；没有支持的模型时可手动整理文字"></textarea></div><button id="copyTranscriptToAnswer" class="btn soft" type="button">将文字复制到当前回答栏</button></div>
</div>`;
ELEM('backBoard').onclick=()=>nav('home');
ELEM('quickBoardSelect').onchange=e=>quickSwitchBoard(e.target.value);
ELEM('showAllBoards').onclick=()=>{const panel=ELEM('boardQuickPanel');panel.classList.toggle('hidden');ELEM('showAllBoards').textContent=panel.classList.contains('hidden')?'全部16个板块 ▾':'收起板块 ▴';};
document.querySelectorAll('[data-switch-board]').forEach(el=>el.onclick=()=>quickSwitchBoard(el.dataset.switchBoard));
document.querySelectorAll('#platforms button').forEach(el=>el.onclick=()=>{if(el.dataset.boardP!==selectedBoard){quickSwitchBoard(el.dataset.boardP,el.dataset.p);return}if(!canLeaveRecording())return;resetRunState();deviceCheckSeq++;stopScene();captureSeq++;discardVideoArchive();exitFocus();if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}activePlatform=el.dataset.p;deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};trainingHome()});
ELEM('runDeviceCheck').onclick=checkDevices;ELEM('enterPrep').onclick=showReadyRoom;ELEM('textFallback').onclick=enableTextOnly;
ELEM('startScene').onclick=startScene;ELEM('preloadBeforeStart').onclick=preloadVoskModel;ELEM('preBack').onclick=returnToCheck;ELEM('focusClose').onclick=finishScene;
ELEM('cameraBtn').onclick=toggleCamera;ELEM('recordBtn').onclick=startRecord;ELEM('recordStopBtn').onclick=stopRecord;
ELEM('nextQuestion').onclick=nextQuestion;ELEM('focusNext').onclick=nextQuestion;ELEM('speakQuestion').onclick=speakCurrentQuestion;ELEM('focusSpeak').onclick=speakCurrentQuestion;ELEM('showReference').onclick=showReference;
ELEM('submitAnswer').onclick=submitAnswer;ELEM('retryQuestionAsr').onclick=()=>activeTurn&&transcribeQuestion(activeTurn.id);ELEM('focusReview').onclick=toggleLiveDrawer;ELEM('closeReview').onclick=toggleLiveDrawer;
ELEM('focusMic').onclick=()=>{if(deviceCheck.mode==='text')return toast('文字模式无法录音，请重新检查麦克风');if(currentRecorder?.state==='recording')stopRecord();else startRecord();};
ELEM('questionCount').textContent=String(allPublishedFor(b,activePlatform).length);
ELEM('transcribeVideoBtn').onclick=()=>transcribeSessionVideo('vosk');if(ELEM('transcribeWhisperBtn'))ELEM('transcribeWhisperBtn').onclick=()=>transcribeSessionVideo('whisper');if(ELEM('preloadVoskBtn'))ELEM('preloadVoskBtn').onclick=preloadVoskModel;ELEM('downloadWavBtn').onclick=downloadAudioCopy;
ELEM('copyTranscriptToAnswer').onclick=()=>{const v=ELEM('postTranscript').value.trim();if(!v)return toast('尚无可复制的录后文字');ELEM('answerText').value=v;saveCurrentTypedAnswer();toast('已复制到当前回答栏并存为本题草稿，请核对与本题的对应关系');};
renderSessionReview();renderQuestionSummary();
updateDeviceStates();
}
function setDeviceState(id,ok,text){const el=ELEM(id);if(!el)return;el.textContent=text;el.classList.remove('pass','fail');if(ok===true)el.classList.add('pass');if(ok===false)el.classList.add('fail')}
function updateDeviceStates(){
const d=deviceCheck;
setDeviceState('cameraState',!d.checked?null:d.camera,'摄像头：'+(!d.checked?'未检查':d.camera?'正常，画面已预览':'未就绪'));
setDeviceState('micState',!d.checked?null:d.microphone,'麦克风：'+(!d.checked?'未检查':d.microphone?'访问正常':'未就绪'));
setDeviceState('recorderState',!d.checked?null:d.recorder,'录音支持：'+(!d.checked?'未检查':d.recorder?'可用':'不支持'));
setDeviceState('networkState',!d.checked?null:!!window.isSecureContext,'环境：'+(!d.checked?'未检查':window.isSecureContext?'安全上下文（可申请权限）':'非安全上下文（需 HTTPS）')+(navigator.onLine?' · 网络可用':' · 当前离线'));
if(ELEM('enterPrep'))ELEM('enterPrep').disabled=!d.ready;
if(ELEM('checkSummary'))ELEM('checkSummary').textContent=d.mode==='text'?'文字模拟模式已启用：视频和录音均不会使用。':d.ready?'设备检查已通过。现在进入开播准备，确认画面后点击「开始直播」。':d.checked?'设备未全部通过。可修复后重试，或选择明确标识的「仅文字模拟练播」。'+(lastDeviceError?' 原因：'+lastDeviceError:''):'尚未检查。真实设备失败不会以演示结果代替。';
if(ELEM('recordBtn'))ELEM('recordBtn').disabled=d.mode==='text'||roomPhase!=='live';
}
async function checkDevices(){
if(roomPhase!=='check')return;
const seq=++deviceCheckSeq;lastDeviceError='';deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:true};
const btn=ELEM('runDeviceCheck');btn.disabled=true;btn.textContent='正在检测设备…';
const audioAvailable=!!(window.MediaRecorder&&navigator.mediaDevices?.getUserMedia);
deviceCheck.recorder=audioAvailable;
if(!navigator.mediaDevices?.getUserMedia){lastDeviceError='浏览器缺少媒体设备 API，需 HTTPS 或新版 Safari / Chrome';}
else{
 try{
  if(!camStream||camStream.getVideoTracks().every(t=>t.readyState!=='live')){
   const acquired=await acquireCamera();
   if(seq!==deviceCheckSeq){acquired.getTracks().forEach(t=>t.stop());return}
   if(camStream&&camStream!==acquired)camStream.getTracks().forEach(t=>{try{t.stop()}catch{}});
   camStream=acquired;bindCameraEnded(acquired);
  }
  if(!(await attachCamera(camStream,()=>seq===deviceCheckSeq))&&seq!==deviceCheckSeq)return;
  const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='none';
  deviceCheck.camera=camStream.getVideoTracks().some(t=>t.readyState==='live');updateCameraInfo();
  ELEM('cameraBtn').textContent='关闭摄像头';
 }catch(e){lastDeviceError='摄像头：'+(e.message||e.name);deviceCheck.camera=false}
 try{
  const audio=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
  audio.getTracks().forEach(t=>t.stop());
  if(seq!==deviceCheckSeq)return;
  deviceCheck.microphone=true;
 }catch(e){lastDeviceError+=(lastDeviceError?'；':'')+'麦克风：'+(e.message||e.name);deviceCheck.microphone=false}
}
if(seq!==deviceCheckSeq)return;
deviceCheck.ready=!!(deviceCheck.camera&&deviceCheck.microphone&&deviceCheck.recorder&&window.isSecureContext);
if(!deviceCheck.ready&&camStream){camStream.getTracks().forEach(t=>{try{t.stop()}catch{}});camStream=null;const video=ELEM('liveCam');if(video){video.srcObject=null;video.style.display='none'}const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';deviceCheck.camera=false;ELEM('cameraBtn').textContent='打开摄像头';}
btn.disabled=false;btn.textContent='重新检查设备';updateDeviceStates();
if(deviceCheck.ready)toast('设备检查通过，可以进入开播准备');else toast('部分设备不可用，查看检查结果并重试');
}
// V3.3.7 摄像头稳定性：不允许浏览器为凑 9:16 而裁切放大；按真实画面比例选择显示方式；画面尺寸变化时自动重新适配。
const CAMERA_BASE={facingMode:'user',resizeMode:'none',frameRate:{ideal:30,max:30}};
const CAMERA_PORTRAIT={...CAMERA_BASE,width:{ideal:720},height:{ideal:1280}};
const CAMERA_LANDSCAPE={...CAMERA_BASE,width:{ideal:1280},height:{ideal:720}};
const CAMERA_FILL_TOLERANCE=0.12;
const screenIsPortrait=()=>window.innerHeight>=window.innerWidth;
function cameraDims(stream){const v=ELEM('liveCam');let w=0,h=0;if(v&&v.srcObject===stream){w=v.videoWidth||0;h=v.videoHeight||0;}if(!(w&&h)){const st=stream?.getVideoTracks?.()[0]?.getSettings?.()||{};w=st.width||0;h=st.height||0;}return {w,h};}
function trackDims(stream){const st=stream?.getVideoTracks?.()[0]?.getSettings?.()||{};return {w:st.width||0,h:st.height||0,resizeMode:st.resizeMode};}
const cameraLog=[];function camLog(m){cameraLog.push(Math.round(performance.now())+'ms '+m);if(cameraLog.length>40)cameraLog.shift();}window.__cameraLog=cameraLog;
let cameraFitWatch=null;
function stopCameraFitWatch(){if(cameraFitWatch!==null){clearInterval(cameraFitWatch);cameraFitWatch=null;}}
function startCameraFitWatch(){if(cameraFitWatch!==null)return;cameraFitWatch=setInterval(()=>{const v=ELEM('liveCam');if(!camStream||!v||v.srcObject!==camStream||!camStream.getVideoTracks().some(t=>t.readyState==='live')){stopCameraFitWatch();return;}const key=v.videoWidth+'x'+v.videoHeight;if(key!==v.__fitKey){camLog('watch '+key);applyCameraFit();}},500);}
function waitTrackAgreement(v,stream,ms){return new Promise(res=>{const t0=Date.now();(function tick(){const t=trackDims(stream);const agree=!(t.w&&t.h)||(v.videoWidth&&v.videoHeight&&(v.videoWidth>v.videoHeight)===(t.w>t.h));if(agree||Date.now()-t0>=ms)return res(agree);setTimeout(tick,100);})();});}
function cameraFitMode(w,h){if(!(w&&h))return 'pending';if(h<=w)return 'landscape';const target=9/16;return Math.abs(w/h-target)/target<=CAMERA_FILL_TOLERANCE?'fill':'portrait-fit';}
async function acquireCamera(){
 try{return await navigator.mediaDevices.getUserMedia({video:CAMERA_PORTRAIT,audio:false});}
 catch(e){if(['NotAllowedError','SecurityError','NotFoundError','NotReadableError','AbortError'].includes(e?.name))throw e;return await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'},audio:false});}
}
function waitVideoFrame(v,ms,needResize){return new Promise(res=>{if(!needResize&&v.videoWidth&&v.videoHeight)return res(true);let t=null;const done=()=>{clearTimeout(t);v.removeEventListener('loadedmetadata',done);v.removeEventListener('resize',done);res(!!(v.videoWidth&&v.videoHeight));};t=setTimeout(done,ms);v.addEventListener('loadedmetadata',done);v.addEventListener('resize',done);});}
function applyCameraFit(){
 const v=ELEM('liveCam');const box=v?.closest('.camera-nine-sixteen');if(!v||!box)return;
 const mode=camStream&&v.srcObject===camStream?cameraFitMode(...Object.values(cameraDims(camStream))):'pending';
 v.__fitKey=v.videoWidth+'x'+v.videoHeight;
 if(box.dataset.fit!==mode){box.dataset.fit=mode;camLog('fit '+mode+' '+v.__fitKey);}
 updateCameraInfo();
}
async function attachCamera(stream,isCurrent){
 const v=ELEM('liveCam');if(!v||!stream)return false;
 if(!v.__fitBound){v.__fitBound=true;v.addEventListener('resize',applyCameraFit);v.addEventListener('loadedmetadata',applyCameraFit);}
 if(v.srcObject!==stream)v.srcObject=stream;
 v.style.display='block';v.play().catch(()=>{});
 await waitVideoFrame(v,2000,false);
 if(!isCurrent()||camStream!==stream)return false;
 let {w,h}=cameraDims(stream);const track=stream.getVideoTracks()[0];
 if(w>h&&screenIsPortrait()&&track?.applyConstraints&&!stream.__orientationRetried){
  // 部分设备按传感器方向理解宽高：在同一条轨道上换一次方向请求，不重复打开摄像头。
  // V3.3.8：是否成功以轨道实际输出（getSettings）为准；视频元素的 videoWidth 可能晚于轨道刷新，不能据此撤销。
  stream.__orientationRetried=true;camLog('orientation retry from '+w+'x'+h);
  try{await track.applyConstraints(CAMERA_LANDSCAPE);camLog('applyConstraints done');}catch(e){camLog('applyConstraints failed '+(e?.name||e));}
  if(!isCurrent()||camStream!==stream)return false;
  let t=trackDims(stream);
  if(!(t.w&&t.h)){await waitVideoFrame(v,1500,true);if(!isCurrent()||camStream!==stream)return false;const d=cameraDims(stream);t={w:d.w,h:d.h,resizeMode:t.resizeMode};}
  const corrected=t.h>t.w&&t.resizeMode!=='crop-and-scale';
  camLog('track after retry '+t.w+'x'+t.h+' resizeMode='+(t.resizeMode||'未报告')+' corrected='+corrected);
  if(corrected){await waitTrackAgreement(v,stream,3000);if(!isCurrent()||camStream!==stream)return false;}
  else{try{await track.applyConstraints(CAMERA_PORTRAIT);camLog('reverted to portrait request');}catch{}}
 }
 applyCameraFit();startCameraFitWatch();return true;
}
function updateCameraInfo(){const el=ELEM('cameraDetails');if(!el)return;const track=camStream?.getVideoTracks?.()[0];if(!track){el.textContent='将按摄像头真实比例显示：接近 9:16 的竖屏画面铺满，其他比例完整显示；已请求浏览器不裁切缩放（是否生效以设备为准）。';return;}const t=trackDims(camStream);const {w,h}=cameraDims(camStream);if(!(w&&h)){el.textContent='正在读取摄像头实际画面尺寸…';return;}const mode=cameraFitMode(w,h);const tip=mode==='fill'?'竖屏画面铺满（比例接近 9:16，边缘最多裁掉约 12%）':mode==='portrait-fit'?'竖屏画面完整显示（比例与 9:16 相差较大，上下或左右留边，不裁切）':'横屏画面完整显示（不裁切、不放大）。请竖持手机；若已竖持仍为横屏，请关闭系统横屏旋转后点「重新检查设备」';const rm=t.resizeMode==='crop-and-scale'?'crop-and-scale（注意：浏览器报告已裁切缩放）':t.resizeMode||'浏览器未报告（无法确认是否裁切）';el.textContent=`摄像头实际 ${w}×${h}（${h>w?'竖屏':'横屏'}）· ${tip}。诊断：轨道 ${t.w||'?'}×${t.h||'?'} · 画面 ${w}×${h} · 裁切模式 ${rm} · 屏幕${screenIsPortrait()?'竖持':'横持'}。预览为镜像（像照镜子），录像保存摄像头原始方向。`;}
function enableTextOnly(){if(roomPhase!=='check')return;deviceCheckSeq++;if(camStream){camStream.getTracks().forEach(t=>t.stop());camStream=null}const v=ELEM('liveCam');if(v){v.srcObject=null;v.style.display='none'}const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';deviceCheck={camera:false,microphone:false,recorder:false,ready:true,mode:'text',checked:true};updateDeviceStates();toast('已切换为仅文字模拟；录音、摄像头不可用');}
function showReadyRoom(){
if(!deviceCheck.ready)return toast('请先通过设备检查，或明确选择文字模拟模式');
if(deviceCheck.mode!=='text'&&(!camStream||!camStream.getVideoTracks().some(t=>t.readyState==='live'))){deviceCheck.ready=false;deviceCheck.camera=false;lastDeviceError='摄像头已断开，请重新检查';updateDeviceStates();return toast('摄像头已断开，请重新检查设备');}
if(!allPublishedFor(boardById(selectedBoard),activePlatform).length)return toast('本板块尚无训练问题，无法开始');
roomPhase='ready';ELEM('liveStatus').textContent='● 待开播';if(ELEM('preLiveVoskTip'))ELEM('preLiveVoskTip').textContent=voskModel?'✓ Vosk中文模型已就绪':'Vosk 未就绪，建议在Wi-Fi下先预下载约48MB（不强制）。';
const phone=ELEM('livePhone');phone.classList.add('is-preparing');document.body.classList.add('focus-open','room-preparing');
ELEM('preLiveActions').style.display='flex';
}
function returnToCheck(){captureSeq++;capturePending=false;roomPhase='check';const sb=ELEM('startScene');if(sb){sb.disabled=false;sb.textContent='开始直播';}ELEM('livePhone')?.classList.remove('is-preparing');document.body.classList.remove('room-preparing','focus-open');if(ELEM('preLiveActions'))ELEM('preLiveActions').style.display='';}
function enterFocus(){const phone=ELEM('livePhone');if(!phone)return;phone.classList.remove('is-preparing');phone.classList.add('is-focused');document.body.classList.remove('room-preparing');document.body.classList.add('focus-open','room-live')}
function exitFocus(){const phone=ELEM('livePhone');if(phone)phone.classList.remove('is-focused','is-preparing');document.body.classList.remove('focus-open','room-live','room-preparing');closeDrawer();}
function toggleLiveDrawer(){if(roomPhase!=='live')return;const was=!!ELEM('trainingControls')?.classList.contains('show-live-controls');if(was){closeDrawer()}else{ELEM('trainingControls')?.classList.add('show-live-controls');ELEM('drawerScrim')?.classList.add('visible');ELEM('focusReview')?.setAttribute('aria-expanded','true')}}
function finishScene(){saveCurrentTypedAnswer();stopScene();exitFocus();roomPhase='check';renderQuestionSummary();if(deviceCheck.mode!=='text'){deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};lastDeviceError='';updateDeviceStates();}ELEM('liveStatus').textContent='● 已结束';toast(sessionStopReason?sessionStopReason+'。再次开播前请重新检查设备。':'模拟直播已结束。再次开播前请重新检查设备。')}
function updateSpeechUI(){for(const id of ['focusSpeak','speakQuestion']){const el=ELEM(id);if(el)el.textContent=ttsSpeaking?'■ 停止朗读':'🔊 朗读弹幕';}}
function cancelTTS(){ttsToken++;ttsSpeaking=false;try{window.speechSynthesis?.cancel()}catch{}updateSpeechUI()}
function speakCurrentQuestion(){
 const text=activeTurn?.prompt||questions[activeQuestionIndex]?.question;
 if(!liveStarted||!text)return toast('请先进入模拟直播间选择一条弹幕');
 if(ttsSpeaking){cancelTTS();return;}
 if(currentRecorder?.state==='recording'||recorderPending||recorderFinalizing||speechRecognizer)return toast('录音或语音识别时不能播放朗读，避免朗读声混入录音');
 if(!window.speechSynthesis||!window.SpeechSynthesisUtterance)return toast('当前浏览器不支持原生中文语音朗读');
 cancelTTS();const ticket=ttsToken;
 try{const u=new window.SpeechSynthesisUtterance(text);u.lang='zh-CN';u.rate=1.04;u.volume=0.9;
 const voice=window.speechSynthesis.getVoices?.().find(v=>/^zh(?:-|_)/i.test(v.lang||''));if(voice)u.voice=voice;
 u.onend=()=>{if(ticket===ttsToken){ttsSpeaking=false;updateSpeechUI()}};
 u.onerror=()=>{if(ticket===ttsToken){ttsSpeaking=false;updateSpeechUI();toast('系统朗读失败：请检查中文语音包和静音设置')}};
 ttsSpeaking=true;updateSpeechUI();window.speechSynthesis.speak(u);
 }catch(e){cancelTTS();toast('朗读启动失败：'+(e.message||e))}
}

function cancelChatTimer(){
 clearTimeout(chatTimer);clearInterval(chatTimer);chatTimer=null;chatQuestionSeq++;
 for(const timer of chatExtraTimers)clearTimeout(timer);chatExtraTimers=[];
}
function scheduleChatQuestion(){
 cancelChatTimer();const ticket=chatQuestionSeq,turnId=activeTurn?.id;
 const emit=()=>{
  if(ticket!==chatQuestionSeq||activeTurn?.id!==turnId||!liveStarted||roomPhase!=='live')return;
  if(document.hidden){chatTimer=setTimeout(emit,2500);return;}
  const b=boardById(selectedBoard),count=Math.random()<0.3?2+Math.floor(Math.random()*2):1;
  for(let i=0;i<count;i++){
   const t=pickDanmu(b,activePlatform,Math.random()<0.125?'complaint':'chatter');
   const timer=setTimeout(()=>{
    if(ticket===chatQuestionSeq&&liveStarted&&activeTurn?.id===turnId)addChat('观众'+String(1+Math.floor(Math.random()*9)).padStart(2,'0'),t.text,t.priority?'urgent':t.needsAnswer?'chat':'chatter');
   },i*150);
   chatExtraTimers.push(timer);
  }
  ELEM('viewer').textContent='模拟观众 · '+(120+Math.floor(Math.random()*110));
  chatTimer=setTimeout(emit,6500+Math.floor(Math.random()*4500));
 };
 chatTimer=setTimeout(emit,3500);
}
function addChat(name,text,type='chat'){
 const list=ELEM('barrage');if(!list)return;
 const item=document.createElement('div');item.className='chat-line '+(type==='system'?'system':type==='urgent'?'urgent':type==='chatter'?'chatter':'');
 const nameEl=document.createElement('strong');nameEl.textContent=name;
 const txt=document.createElement('span');txt.textContent=text;
 item.append(nameEl,txt);
 if(type==='urgent'){const mark=document.createElement('em');mark.textContent='优先处理';item.append(mark)}
 if(type==='chatter'){const mark=document.createElement('small');mark.textContent='无需单独回答';item.append(mark)}
 list.append(item);while(list.children.length>7)list.firstChild.remove();
}
async function startScene(){
 if(roomPhase!=='ready'||capturePending)return toast('请先完成设备检查，然后点击开始直播');
 if(videoRecorderFinalizing)return toast('上一场录像尚在封装，请保存完成后再开播');
 if(sessionVideoBlob&&!sessionVideoDownloaded&&!window.confirm('上一场原视频还未下载。再次开播将覆盖本页录像，确定继续吗？'))return;
 if(deviceCheck.mode!=='text'&&(!camStream||!camStream.getVideoTracks().some(t=>t.readyState==='live'))){returnToCheck();deviceCheck.ready=false;deviceCheck.camera=false;lastDeviceError='摄像头预览已中断';updateDeviceStates();return toast('摄像头已中断，请重新检查设备')}
 const b=boardById(selectedBoard);questions=allPublishedFor(b,activePlatform);if(!questions.length)return toast('本板块暂无可用问题');
 capturePending=true;syncExitWarning();const seq=++captureSeq;const startBtn=ELEM('startScene');startBtn.disabled=true;startBtn.textContent='正在开启录制…';
 let acquired=null;
 try{
  discardVideoArchive();if(ELEM('postTranscript'))ELEM('postTranscript').value='';if(ELEM('transcribeStatus')&&!voskLoadJob)ELEM('transcribeStatus').textContent='';
  if(deviceCheck.mode!=='text'){
   if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw new Error('当前浏览器不支持摄像头与麦克风录制');
   acquired=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
   if(seq!==captureSeq||roomPhase!=='ready'){acquired.getTracks().forEach(t=>t.stop());return;}
   const types=['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/webm;codecs=vp8,opus','video/mp4','video/webm'];
   const mime=types.find(t=>window.MediaRecorder.isTypeSupported?.(t));
   if(!mime)throw new Error('当前浏览器未提供兼容的音视频 MediaRecorder 编码格式');
   const combined=new MediaStream([...camStream.getVideoTracks(),...acquired.getAudioTracks()]);
   let recorder;
   try{recorder=new MediaRecorder(combined,{mimeType:mime,videoBitsPerSecond:1000000,audioBitsPerSecond:64000})}
   catch{recorder=new MediaRecorder(combined,{mimeType:mime})} // Older Safari may reject bitrate hints.
   sessionMicStream=acquired;bindMicEnded(acquired,seq);sessionVideoStream=combined;sessionRecorder=recorder;sessionChunks=[];videoRecorderFinalizing=false;sessionVideoDownloaded=false;sessionCaptureNote='录制进行中';
   sessionVideoMeta={boardId:selectedBoard,platform:activePlatform,startedAt:Date.now(),startedMono:performance.now(),mime};sessionStopReason='';
   const ownerSeq=seq;
   let captureBytes=0,capStopRequested=false,capWarned=false;
   recorder.ondataavailable=e=>{
    if(ownerSeq!==captureSeq||!e.data?.size)return;
    const wasStopped=capStopRequested;
    captureBytes+=e.data.size;
    if(!wasStopped&&e.data instanceof Blob)sessionChunks.push(e.data);
    if(!capWarned&&captureBytes>=CAPTURE_WARN_BYTES){capWarned=true;toast('已收到约48MB录像分块，接近64MB软件保护阈值，请准备结束');}
    if(!capStopRequested&&captureBytes>=MAX_CAPTURE_BYTES&&roomPhase==='live'){
     capStopRequested=true;sessionStopReason='达到64MB已收集分块阈值，已自动结束（单个数据块可能超过阈值）';
     finishScene();
    }
   };
   recorder.onerror=()=>{if(ownerSeq!==captureSeq)return;sessionCaptureNote='录制出现错误，已安全终止';sessionChunks=[];finishScene();toast('整场录像失败，已结束练播，避免产生不完整录像');};
   recorder.onstop=()=>{
    acquired?.getTracks().forEach(t=>{try{t.stop()}catch{}});
    if(sessionMicStream===acquired)sessionMicStream=null;
    if(ownerSeq!==captureSeq)return;
    if(sessionVideoMeta&&!sessionVideoMeta.stoppedAt){sessionVideoMeta.stoppedAt=Date.now();sessionVideoMeta.stoppedMono=performance.now();}
    videoRecorderFinalizing=false;
    if(sessionRecorder===recorder)sessionRecorder=null;syncExitWarning();
    const parts=sessionChunks.slice();sessionChunks=[];
    if(!parts.length){sessionCaptureNote=(sessionStopReason?sessionStopReason+'；':'')+'未生成有效录像，请检查浏览器媒体支持';renderSessionReview();return}
    const original=new Blob(parts,{type:recorder.mimeType||mime});
    if(original.size<1024){sessionCaptureNote=(sessionStopReason?sessionStopReason+'；':'')+'录像过短或无效';renderSessionReview();return}
    sessionVideoBlob=original;sessionVideoDownloaded=false;syncExitWarning();
    sessionVideoURL=URL.createObjectURL(original);
    sessionCaptureNote=`${sessionStopReason?sessionStopReason+'；':''}原始录像已保存在当前页面内存（${(original.size/1024/1024).toFixed(2)}MB）。请立即下载并确认文件存在；刷新或系统清理可能丢失。`;
    renderSessionReview();
   };
   recorder.start(1000);syncExitWarning();
   captureLimitTimer=setTimeout(()=>{
    if(seq!==captureSeq||sessionRecorder!==recorder||recorder.state!=='recording')return;
    sessionStopReason=`已达到${Math.ceil(captureMaxMs()/60000)}分钟单场安全时长，自动结束`;
    finishScene();
   },captureMaxMs());
   renderSessionReview();
  }else{
   sessionCaptureNote='文字练播模式不生成录像';renderSessionReview();
  }
  if(seq!==captureSeq||roomPhase!=='ready')return;
  cancelSpeech();cancelChatTimer();resetRunState({cancelPreload:false});runId=uid();liveStarted=true;roomPhase='live';activeQuestionIndex=-1;
  ELEM('liveStatus').textContent='● 模拟直播中';ELEM('preLiveActions').style.display='none';ELEM('viewer').textContent='模拟观众 · 126';
  enterFocus();nextQuestion();
 }catch(e){
  acquired?.getTracks().forEach(t=>{try{t.stop()}catch{}});
  if(seq===captureSeq){sessionRecorder=null;sessionMicStream=null;sessionVideoStream=null;toast('开播失败：'+(e.message||e));if(ELEM('checkSummary'))ELEM('checkSummary').textContent='音视频录制无法启动：'+(e.message||e)+'。请检查后重试，或手动选文字模式';}
 }finally{if(seq===captureSeq){capturePending=false;syncExitWarning();if(startBtn?.isConnected){startBtn.disabled=false;startBtn.textContent='开始直播'}}}
}

function nextQuestion(){
 if(recorderPending)return toast('正在等待麦克风授权，请稍后再切换弹幕');
 if(!liveStarted)return toast('请点击「开始直播」后再练习');
 if(currentRecorder?.state==='recording'||recorderFinalizing)return toast('请先结束本题录音，再切换弹幕');
 const b=boardById(selectedBoard);questions=allPublishedFor(b,activePlatform);if(!questions.length)return toast('没有可练问题');
 saveCurrentTypedAnswer();cancelSpeech();cancelTTS();cancelTranscript();
 activeQuestionIndex=(activeQuestionIndex+1)%questions.length;
 const q=questions[activeQuestionIndex],danmu={text:q.question,priority:false,needsAnswer:true,templateId:q.kind==='seed'?'seed-question':'reviewed-question'};
 const turn=typeof runId==='undefined'?null:{id:uid(),runId,boardId:selectedBoard,category:b.category,platform:activePlatform,
  prompt:danmu.text,trainingHint:q.question,keyPoints:[...(q.keyPoints||[])],pointKeywords:(q.pointKeywords||[]).map(x=>[...(x||[])]),
  responseSeconds:null,durationSeconds:null,createdAt:nowIso(),shownAt:performance.now(),
  transcript:'',answer:'',asrStatus:'等待主播回答',pointsHit:[],compliance:[]};
 if(turn&&typeof activeTurn!=='undefined'){activeTurn=turn;sessionTurns.push(turn);}
 ELEM('currentQuestion').textContent=q.question;
 ELEM('questionStage').textContent=`问题 ${activeQuestionIndex+1}/${questions.length} · ${q.kind==='seed'?'教学弹幕原题 + 要点自查':'已审核题目原文'}`;
 ELEM('questionSource').textContent=q.kind==='seed'?'教学弹幕原题 / 同源要点自查':'已审核题目原文 / 观众弹幕';
 ELEM('referenceBox').classList.add('hidden');ELEM('referenceBox').innerHTML='';
 ELEM('answerText').value='';ELEM('scoreBox').innerHTML='';
 if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}
 ELEM('audioHolder').replaceChildren();recordUI('尚未录制本题回答');
 const barrage=ELEM('barrage');if(barrage)barrage.replaceChildren();
 addChat('观众'+String(1+Math.floor(Math.random()*9)).padStart(2,'0'),danmu.text,danmu.priority?'urgent':'chat');
 // Complaints are independent priority inserts, never the main scored question.
 if(Math.random()<0.125){const urgent=pickDanmu(b,activePlatform,'complaint');if(urgent?.text)addChat('观众'+String(1+Math.floor(Math.random()*9)).padStart(2,'0'),urgent.text,'urgent');}
 if(turn&&typeof renderTurnStatus==='function')renderTurnStatus(turn);scheduleChatQuestion();
}
function showReference(){const q=questions[activeQuestionIndex];if(!q)return toast('请先开始训练');const box=ELEM('referenceBox');box.classList.toggle('hidden');box.innerHTML=`<b>参考回答：</b><p>${ESC(q.answer||'尚未录入经审核的参考回答，不能提供自动评分结论。')}</p><b>应覆盖的重点：</b><ul>${(q.keyPoints||[]).map(k=>`<li>${ESC(k)}</li>`).join('')}</ul><small>来源：${ESC(q.source||'知识库')}</small>`;}
function stopScene(opts={}){
 clearCaptureLimit();cancelSpeech();cancelTTS();cancelTranscript();cancelChatTimer();
 if(sessionVideoMeta?.startedAt&&!sessionVideoMeta.stoppedAt){sessionVideoMeta.stoppedAt=Date.now();sessionVideoMeta.stoppedMono=performance.now();}
 capturePending=false;liveStarted=false;
 if(!opts.preserveCapture){
  if(sessionRecorder?.state==='recording'){
   videoRecorderFinalizing=true;if(typeof renderSessionReview==='function')renderSessionReview();
   try{sessionRecorder.requestData?.()}catch{}
   try{sessionRecorder.stop()}catch{videoRecorderFinalizing=false;sessionMicStream?.getTracks().forEach(t=>t.stop());if(typeof renderSessionReview==='function')renderSessionReview();}
  }else if(sessionMicStream&&!videoRecorderFinalizing){sessionMicStream.getTracks().forEach(t=>{try{t.stop()}catch{}});sessionMicStream=null;}
 }
 const wasRec=recorderPending||recorderFinalizing||currentRecorder?.state==='recording';
 const interruptedTurn=recordingTurn;
 if(wasRec&&interruptedTurn&&interruptedTurn.runId===runId){
  if(interruptedTurn.startedAt&&interruptedTurn.durationSeconds==null)interruptedTurn.durationSeconds=Math.round(Math.max(0,performance.now()-interruptedTurn.startedAt)/100)/10;
  interruptedTurn.asrStatus='录音未完成（直播已结束）';renderTurnStatus(interruptedTurn);void saveTurn(interruptedTurn);
 }
 recordingTurn=null;
 recorderPending=false;recorderSession++;recorderFailed=true;recorderFinalizing=false;
 if(activeRecTimer){clearTimeout(activeRecTimer);activeRecTimer=null;}
 if(currentRecorder?.state==='recording'){try{currentRecorder.stop()}catch{}}
 releaseMicrophone();
 if(!opts.preserveCamera&&camStream){camStream.getTracks().forEach(t=>{try{t.stop()}catch{}});camStream=null;}
 const video=ELEM('liveCam');if(video&&!opts.preserveCamera){video.srcObject=null;video.style.display='none';const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';}
 const badge=ELEM('liveStatus');if(badge)badge.textContent='● 模拟待机';const x=ELEM('recordBtn'),y=ELEM('recordStopBtn');if(x)x.disabled=deviceCheck.mode==='text'||roomPhase!=='live';if(y)y.disabled=true;const liveButton=ELEM('focusMic');if(liveButton)liveButton.textContent='● 开始录音';if(wasRec&&ELEM('recordStatus'))ELEM('recordStatus').textContent='直播已结束，本题未完成的录音已停止';syncExitWarning();
}
async function toggleCamera(){if(roomPhase!=='check'||cameraBusy)return;const seq=++deviceCheckSeq;if(camStream){camStream.getTracks().forEach(t=>t.stop());camStream=null;ELEM('liveCam').srcObject=null;ELEM('liveCam').style.display='none';ELEM('roomPlaceholder').style.display='block';ELEM('cameraBtn').textContent='打开摄像头';deviceCheck.camera=false;deviceCheck.ready=false;updateDeviceStates();return}if(!navigator.mediaDevices?.getUserMedia)return toast('此浏览器不支持摄像头或当前页面缺少 HTTPS');cameraBusy=true;try{const acquired=await acquireCamera();if(seq!==deviceCheckSeq||roomPhase!=='check'){acquired.getTracks().forEach(t=>t.stop());return}if(camStream&&camStream!==acquired)camStream.getTracks().forEach(t=>{try{t.stop()}catch{}});camStream=acquired;bindCameraEnded(acquired);const v=ELEM('liveCam');if(!v){camStream.getTracks().forEach(t=>t.stop());camStream=null;return}await attachCamera(camStream,()=>seq===deviceCheckSeq&&roomPhase==='check');if(seq!==deviceCheckSeq||roomPhase!=='check')return;ELEM('roomPlaceholder').style.display='none';ELEM('cameraBtn').textContent='关闭摄像头';deviceCheck.camera=true;updateCameraInfo();deviceCheck.ready=!!(deviceCheck.microphone&&deviceCheck.recorder&&window.isSecureContext);updateDeviceStates()}catch(e){toast('摄像头无法启动：'+e.message)}finally{cameraBusy=false}}
let recorderFailed=false, recorderSession=0, recorderFinalizing=false, activeRecTimer=null, recorderPending=false;
let speechSession=0, speechRecognizer=null;
function cancelSpeech(){speechSession++;const old=speechRecognizer;speechRecognizer=null;if(old){try{old.abort()}catch{}}}
function bindCameraEnded(stream){for(const t of stream.getVideoTracks()){t.addEventListener?.('ended',()=>{if(camStream!==stream)return;if(roomPhase==='live'){finishScene();toast('摄像头已中断：练播安全结束。请重新检查设备后开播');}else if(roomPhase==='ready'||roomPhase==='check'){const wasReady=roomPhase==='ready';returnToCheck();camStream=null;const v=ELEM('liveCam');if(v){v.srcObject=null;v.style.display='none'}const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';if(ELEM('cameraBtn'))ELEM('cameraBtn').textContent='打开摄像头';deviceCheck.camera=false;deviceCheck.ready=false;lastDeviceError='摄像头预览已中断';updateDeviceStates();if(wasReady)toast('摄像头已中断，已退回设备检查');}});}}
function bindMicEnded(stream,ownerSeq){for(const t of stream.getAudioTracks()){t.addEventListener?.('ended',()=>{if(ownerSeq!==captureSeq||sessionMicStream!==stream)return;if(roomPhase==='live'){finishScene();lastDeviceError='麦克风已中断';updateDeviceStates();toast('麦克风已中断：练播安全结束。请重新检查设备后开播');}});}}
function releaseMicrophone(){if(micStream){micStream.getTracks().forEach(t=>{try{t.stop()}catch{}});micStream=null}}
function recordUI(status,recording=false){const a=ELEM('recordStatus'),b=ELEM('recordBtn'),c=ELEM('recordStopBtn'),d=ELEM('focusMic');if(a)a.textContent=status;if(b)b.disabled=recording||deviceCheck.mode==='text'||roomPhase!=='live';if(c)c.disabled=!recording;if(d){d.textContent=recording?'■ 结束录音':'● 开始录音';d.disabled=deviceCheck.mode==='text';}}
async function startRecord(){
 if(roomPhase!=='live'||!liveStarted)return toast('请先进入模拟直播间，再开始录音');
 if(!deviceCheck.ready||deviceCheck.mode==='text')return toast('文字模拟模式无法录音，或设备检测尚未完成');
 if(recorderPending)return toast('正在等待麦克风授权，请勿重复点击');
 if(recorderFinalizing)return toast('正在整理上一段录音，请稍后重试');
 if(!window.MediaRecorder)return toast('此浏览器不支持录音；请在 HTTPS 页面使用 Safari/Chrome');
 if(currentRecorder?.state==='recording')return toast('录音进行中，请先结束');
 cancelSpeech();cancelTTS();recorderPending=true;
 const turnAtStart=typeof activeTurn==='undefined'?null:activeTurn;if(typeof recordingTurn!=='undefined')recordingTurn=turnAtStart;
 const session=++recorderSession;recorderFailed=false;recorderFinalizing=false;recChunks=[];
 let acquired=null, ownTimer=null;
 const clearOwnTimer=()=>{if(ownTimer!==null){clearTimeout(ownTimer);if(activeRecTimer===ownTimer)activeRecTimer=null;ownTimer=null;}};
 try{
  const sourceTrack=sessionMicStream?.getAudioTracks?.().find(t=>t.readyState==='live');
  if(!sourceTrack)throw new Error('整场录像的麦克风音轨已中断，请结束后重新检查');
  acquired=new MediaStream([sourceTrack.clone()]);
  if(session!==recorderSession||roomPhase!=='live'){acquired.getTracks().forEach(t=>t.stop());return}
  recorderPending=false;
  micStream=acquired;
  const releaseOwned=()=>{clearOwnTimer();acquired?.getTracks().forEach(t=>{try{t.stop()}catch{}});if(micStream===acquired)micStream=null};
  const mime=['audio/mp4','audio/webm;codecs=opus','audio/webm'].find(t=>MediaRecorder.isTypeSupported?.(t))||'';
  const recorder=new MediaRecorder(micStream,mime?{mimeType:mime}:{});currentRecorder=recorder;
  recorder.ondataavailable=e=>{if(session===recorderSession&&e.data?.size)recChunks.push(e.data)};
  recorder.onerror=()=>{releaseOwned();if(session!==recorderSession)return;recorderFailed=true;recorderFinalizing=false;currentRecorder=null;recChunks=[];recordUI('录音失败，麦克风已释放；可重试或直接文字练习');};
  recorder.onstop=()=>{
   releaseOwned();if(session!==recorderSession)return;recorderFinalizing=false;currentRecorder=null;queueMicrotask(()=>void drainQuestionAsrQueue());
   if(recorderFailed){if(turnAtStart)turnAtStart.asrStatus='录音失败';if(recordingTurn===turnAtStart)recordingTurn=null;recordUI('录音出错，请重试。没有保存不完整音频');return}
   const chunks=recChunks.slice();recChunks=[];
   if(!chunks.length){recordUI('未录到有效音频，请检查麦克风权限');return}
   const blob=new Blob(chunks,{type:recorder.mimeType||mime||'audio/webm'});
   if(blob.size<200){recordUI('音频太短或无效，请重新录制');return}
   if(answerAudioURL)URL.revokeObjectURL(answerAudioURL);
   answerAudioURL=URL.createObjectURL(blob);
   const holder=ELEM('audioHolder');if(holder){const audio=document.createElement('audio');audio.controls=true;audio.className='audio-player';audio.src=answerAudioURL;holder.replaceChildren(audio)}

   recordUI(`录音完成（${(blob.size/1024).toFixed(1)} KB），转写结果只关联本题。`);
   if(turnAtStart&&turnAtStart.runId===runId&&page==='training'
      &&turnAtStart.boardId===selectedBoard&&turnAtStart.platform===activePlatform){
    const answerEl=ELEM('answerText'),currentText=answerEl?.value.trim()||'';
    const oldTranscript=turnAtStart.transcript||'';
    const manual=!!currentText&&currentText!==oldTranscript;
    turnAtStart.durationSeconds=Math.round(Math.max(0,performance.now()-(turnAtStart.startedAt||performance.now()))/100)/10;
    turnAtStart.transcript='';turnAtStart.rawTranscript='';turnAtStart.compliance=[];turnAtStart.pointsHit=[];turnAtStart.asrWarnings=[];
    if(manual)turnAtStart.answer=currentText;else{turnAtStart.answer='';if(answerEl&&activeTurn?.id===turnAtStart.id)answerEl.value='';}
    turnAtStart.asrStatus=voskModel?'待自动转写':'Vosk未就绪：音频保留在本页，先预下载模型后补转写';
    perQuestionAudio.set(turnAtStart.id,blob);
    if(recordingTurn===turnAtStart)recordingTurn=null;
    saveTurn(turnAtStart).then(()=>{if(runId===turnAtStart.runId){renderTurnStatus(turnAtStart);if(voskModel)enqueueQuestionAsr(turnAtStart.id)}});
   }

  };
  const maxDurationMs=typeof window.__REC_MAX_MS==='number'?window.__REC_MAX_MS:120000;
  recorder.start(300);
  if(turnAtStart&&turnAtStart.runId===runId){
   // Invalidate ASR results from an earlier take as soon as this take starts.
   turnAtStart.audioRevision=(turnAtStart.audioRevision||0)+1;
   turnAtStart.startedAt=performance.now();
   if(turnAtStart.responseSeconds===null)turnAtStart.responseSeconds=Math.round(Math.max(0,turnAtStart.startedAt-turnAtStart.shownAt)/100)/10;
   turnAtStart.asrStatus='正在录音';renderTurnStatus(turnAtStart);
  }
  ownTimer=setTimeout(()=>{ownTimer=null;if(activeRecTimer)activeRecTimer=null;if(session===recorderSession&&recorder.state==='recording')stopRecord();},maxDurationMs);
  activeRecTimer=ownTimer;
  recordUI('● 正在录音（最长120秒），点击结束录音可回放',true);
 }catch(e){clearOwnTimer();if(acquired){acquired.getTracks().forEach(t=>{try{t.stop()}catch{}});if(micStream===acquired)micStream=null}if(session!==recorderSession)return;currentRecorder=null;recorderFinalizing=false;recordUI('无法启动录音：'+(e?.message||'未知错误'));toast('请检查浏览器麦克风权限及 HTTPS 连接')}
 finally{if(session===recorderSession)recorderPending=false;}
}
function stopRecord(){try{if(currentRecorder?.state==='recording'){recorderFinalizing=true;currentRecorder.stop();recordUI('正在整理录音，请稍候…',true)}}catch(e){recorderFinalizing=false;currentRecorder=null;recordUI('停止录音失败：'+e.message);releaseMicrophone()}}
function browserAsr(){
 if(page!=='training'||roomPhase!=='live'||!liveStarted||!questions[activeQuestionIndex])return toast('请先进入训练直播间');
 if(recorderPending||recorderFinalizing||currentRecorder?.state==='recording')return toast('请先结束录音或等待授权完成');
 const Klass=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!Klass)return toast('此浏览器不支持 Web Speech Recognition，无法保证免费或离线，请手动填写');
 cancelSpeech();cancelTTS();
 const session=speechSession,board=selectedBoard,platform=activePlatform,question=questions[activeQuestionIndex],turn=activeTurn,ownerRun=runId,ownerAudioRevision=turn?.audioRevision||0,target=ELEM('answerText'),status=ELEM('recordStatus');
 if(!target||!status)return;
 const valid=()=>session===speechSession&&page==='training'&&roomPhase==='live'&&liveStarted&&selectedBoard===board&&activePlatform===platform&&questions[activeQuestionIndex]===question&&runId===ownerRun&&activeTurn?.id===turn?.id&&(turn?.audioRevision||0)===ownerAudioRevision&&ELEM('answerText')===target&&ELEM('recordStatus')===status;
 try{
  const rec=new Klass();speechRecognizer=rec;
  rec.lang='zh-CN';rec.continuous=false;rec.interimResults=false;
  status.textContent='浏览器识别尝试中（可能调用系统在线服务，不保证离线或持续可用）';
  rec.onresult=e=>{
   if(!valid()||speechRecognizer!==rec||!turn)return;
   const raw=[...e.results].map(x=>x[0]?.transcript||'').join('').trim();
   const assessed=assessAsrText(raw);if(!assessed.text)return;
   const normalized=normalizeSpokenNumbers(assessed.text);
   const prev=turn.transcript||'',typed=target.value.trim();
   const hasManualDraft=!!typed&&typed!==prev;
   // A newer browser result supersedes any still-running Vosk one-shot result.
   turn.asrRevision=(turn.asrRevision||0)+1;
   turn.rawTranscript=raw;turn.transcript=normalized.text;
   if(hasManualDraft)turn.answer=typed;
   else if(!turn.answer||turn.answer===prev)turn.answer=normalized.text;
   if(!typed||typed===prev)target.value=normalized.text;
   turn.asrWarnings=[...(assessed.warnings||[]),...(normalized.changes?['数值已规范化，请核对原文']:[])];
   turn.compliance=complianceHints(turn.answer,turn.platform);
   turn.pointsHit=(turn.keyPoints||[]).filter((p,i)=>fuzzyPoint(p,turn.answer,turn.pointKeywords?.[i]||[]));
   turn.asrStatus='浏览器语音识别已写入本题（可能调用在线服务，请人工校对）';
   void saveTurn(turn);renderTurnStatus(turn);
   status.textContent='识别文字已同步到逐题汇总。请核对数字/型号并按需编辑保存。';
  };
  rec.onerror=e=>{if(!valid()||speechRecognizer!==rec)return;status.textContent='浏览器识别失败：'+e.error+'。请手动输入。';cancelSpeech();};
  rec.onend=()=>{if(speechRecognizer===rec){speechRecognizer=null;speechSession++;}};
  rec.start();
 }catch(e){if(valid()){cancelSpeech();status.textContent='浏览器识别无法启动，请手动输入';toast('无法启动浏览器识别：'+e.message)}}
}
function renderSessionReview(){
 const status=ELEM('sessionArchiveStatus'),holder=ELEM('sessionArchiveHolder'),btn=ELEM('transcribeVideoBtn'),wBtn=ELEM('transcribeWhisperBtn'),pBtn=ELEM('preloadVoskBtn'),wav=ELEM('downloadWavBtn');
 if(!status||!holder)return;
 status.textContent=videoRecorderFinalizing?'正在封装完整音视频，请勿关闭页面…':sessionCaptureNote||'尚无完整录像。';
 if(btn)btn.disabled=!sessionVideoBlob||transcriptBusy;if(wBtn)wBtn.disabled=!sessionVideoBlob||transcriptBusy;if(pBtn){pBtn.disabled=transcriptBusy||!!voskLoadJob;pBtn.textContent=voskModel?'✓ Vosk 中文模型已就绪':'预下载/校验 Vosk 中文模型（48MB）';}if(wav)wav.disabled=!sessionVideoBlob||videoRecorderFinalizing;
 if(!sessionVideoBlob||!sessionVideoURL){holder.replaceChildren();return}
 holder.replaceChildren();const video=document.createElement('video');video.controls=true;video.playsInline=true;video.preload='metadata';video.className='archive-video';video.src=sessionVideoURL;
 const link=document.createElement('a');link.href=sessionVideoURL;link.download='TCL-练播原始录像-'+(sessionVideoMeta?.boardId||selectedBoard)+'-'+Date.now()+(sessionVideoBlob.type.includes('mp4')?'.mp4':'.webm');link.textContent='下载未改动的原始音视频';link.className='btn soft';link.onclick=()=>{sessionVideoDownloaded=true;syncExitWarning();toast('已请求下载，请到手机文件应用确认录像保存成功')};
 const hint=document.createElement('div');hint.className='scene-tip';hint.textContent='原始录像使用同一 MediaRecorder 同步采集音视频。录后识别只读取数据副本，不写回、不转码原文件。';
 holder.append(video,link,hint);
}
function cancelTranscript(){transcriptSeq++;transcriptBusy=false;}
// A stalled model CDN or WASM initialization must not leave the UI locked forever.
// This bounds the wait, but does not promise to abort a browser network request in progress.
async function awaitBounded(task,ms,label){
 let timer;
 try{return await Promise.race([Promise.resolve(task),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`${label}超时（${Math.ceil(ms/1000)}秒）；已恢复操作，原录像未改变。可能仍有后台模型下载，请检查网络后再试`)),ms)})]);}
 finally{clearTimeout(timer);}
}
async function decodeAudioCopy(blob){
 ensureDecodeBudget(blob); // Must run BEFORE arrayBuffer() / Web Audio allocations.
 if(audioDecodeJob)throw new Error('上一项音频解码仍在后台执行；禁止重复启动以保护手机内存。请先下载原视频，等待完成或重新打开页面');
 let job;
 job=(async()=>decodeAudioCopyInternal(blob))();
 audioDecodeJob=job;
 try{return await job}finally{if(audioDecodeJob===job)audioDecodeJob=null;}
}
async function decodeAudioCopyInternal(blob){
 ensureDecodeBudget(blob);
 const Audio=window.AudioContext||window.webkitAudioContext;
 const Offline=window.OfflineAudioContext||window.webkitOfflineAudioContext;
 if(!Audio||!Offline)throw new Error('当前浏览器不支持音频解码/重采样');
 const ctx=new Audio();let decoded;
 try{const bytes=await blob.arrayBuffer();decoded=await ctx.decodeAudioData(bytes);}catch(e){throw new Error('该设备无法直接从原视频容器解出音轨。原视频未改变，请下载后在支持的浏览器尝试，或使用服务器离线解复用：'+(e.message||e));}finally{ctx.close?.().catch?.(()=>{});}
 if(decoded.duration>180)throw new Error('当前端侧识别限制180秒；原视频已保留，请下载后用离线工具分段处理');
 const rate=16000;const frames=Math.ceil(decoded.duration*rate);const offline=new Offline(1,frames,rate);const src=offline.createBufferSource();src.buffer=decoded;src.connect(offline.destination);src.start();const converted=await offline.startRendering();return new Float32Array(converted.getChannelData(0));
}
function wavFromPCM(samples,sampleRate=16000){
 const buffer=new ArrayBuffer(44+samples.length*2),view=new DataView(buffer);
 const write=(at,t)=>{for(let i=0;i<t.length;i++)view.setUint8(at+i,t.charCodeAt(i))};
 write(0,'RIFF');view.setUint32(4,36+samples.length*2,true);write(8,'WAVE');write(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,sampleRate,true);view.setUint32(28,sampleRate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);write(36,'data');view.setUint32(40,samples.length*2,true);
 for(let i=0;i<samples.length;i++){const value=Math.max(-1,Math.min(1,samples[i]));view.setInt16(44+2*i,value<0?value*32768:value*32767,true)}
 return new Blob([buffer],{type:'audio/wav'});
}
async function downloadAudioCopy(){
 const orig=sessionVideoBlob;const status=ELEM('transcribeStatus');if(!orig||videoRecorderFinalizing)return;
 if(audioDecodeJob){const msg='上一项音轨提取仍在后台执行，请勿重复点击；请先下载原视频';if(status)status.textContent=msg;return toast(msg);}
 try{status.textContent='正在从录像副本提取独立音轨…';const pcm=await awaitBounded(decodeAudioCopy(orig),Number(window.__ASR_DECODE_TIMEOUT_MS)||60000,'音轨提取');if(orig!==sessionVideoBlob||!ELEM('transcribeStatus'))return;const wav=wavFromPCM(pcm);const url=URL.createObjectURL(wav);const link=document.createElement('a');link.href=url;link.download='TCL-录像提取音频-'+(sessionVideoMeta?.boardId||selectedBoard)+'.wav';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);status.textContent='音频副本已生成。原始视频的音轨、时间戳和时长没有被修改。';}
 catch(e){if(status)status.textContent='提取音频失败：'+(e.message||e)+'。原视频不受影响。'}
}
// ASR_GUARDS_BEGIN
function trimAsrSilence(pcm,sampleRate=16000,opts={}){
 if(!(pcm instanceof Float32Array)||!Number.isFinite(sampleRate)||sampleRate<=0||!opts||typeof opts!=='object')throw new Error('静音检测配置无效');
 const threshold=opts.threshold===undefined?0.008:opts.threshold;
 const paddingMs=opts.paddingMs===undefined?200:opts.paddingMs;
 const frameMs=opts.frameMs===undefined?30:opts.frameMs;
 const minVoicedSeconds=opts.minVoicedSeconds===undefined?1:opts.minVoicedSeconds;
 if(!Number.isFinite(threshold)||threshold<0||!Number.isFinite(paddingMs)||paddingMs<0||!Number.isFinite(frameMs)||frameMs<=0)throw new Error('静音检测参数无效');
 const frameLen=Math.max(1,Math.round(sampleRate*(frameMs/1000)));
 const padSamples=Math.round(sampleRate*(paddingMs/1000));
 const rawIntervals=[];let voicedSamples=0;
 for(let start=0;start<pcm.length;start+=frameLen){
  const end=Math.min(pcm.length,start+frameLen);
  let sumSq=0;
  for(let i=start;i<end;i++){const v=pcm[i];if(Number.isFinite(v))sumSq+=v*v;}
  const rms=Math.sqrt(sumSq/(end-start));
  if(rms>=threshold){
   voicedSamples+=(end-start);
   rawIntervals.push([Math.max(0,start-padSamples),Math.min(pcm.length,end+padSamples)]);
  }
 }
 const voicedSeconds=voicedSamples/sampleRate;
 if(voicedSeconds<minVoicedSeconds||!rawIntervals.length){
  return {hasSpeech:false,pcm:new Float32Array(0),segments:[],voicedSeconds,reason:'未检测到有效语音'};
 }
 const segments=[];
 for(const [st,en] of rawIntervals){
  if(!segments.length||st>segments[segments.length-1].end)segments.push({start:st,end:en});
  else if(en>segments[segments.length-1].end)segments[segments.length-1].end=en;
 }
 const total=segments.reduce((n,seg)=>n+(seg.end-seg.start),0);
 const out=new Float32Array(total);let pos=0;
 for(const seg of segments){
  for(let i=seg.start;i<seg.end;i++){const v=pcm[i];out[pos++]=Number.isFinite(v)?v:0;}
 }
 return {hasSpeech:true,pcm:out,segments,voicedSeconds,reason:''};
}
function calcChineseRatio(str){
 const chars=[...String(str||'').replace(/[\s\p{P}\p{S}]/gu,'')];
 if(!chars.length)return 0;
 const han=chars.filter(c=>/\p{Script=Han}/u.test(c)).length;
 return han/chars.length;
}
function assessAsrText(raw){
 const input=String(raw??'').trim();
 const rawRatio=calcChineseRatio(input);
 if(!input||rawRatio===0&&![...input.replace(/[\s\p{P}\p{S}]/gu,'')].length){
  return {text:'',repeated:false,lowChinese:true,chineseRatio:0,warnings:['未识别出有效中文字符，识别质量低，请核对']};
 }
 let text=input,repeated=false;
 // 1. Detect 4+ consecutive repeated clauses/phrases separated by optional punctuation/spaces
 const clauseRe=/(.{1,30}?)(?:[\s,，.。!！?？;；、]+\1){3,}/giu;
 if(clauseRe.test(text)){
  repeated=true;
  text=text.replace(clauseRe,'$1');
 }
 // 2. Detect 4+ consecutive identical substrings without separators (e.g. phrase repeated >=4 times)
 const directRe=/(.{2,30}?)\1{3,}/giu;
 if(directRe.test(text)){
  repeated=true;
  text=text.replace(directRe,'$1');
 }
 // 3. Detect dominant repeated token (>=4 occurrences and >=35% of tokens)
 const tokens=text.match(/[\p{Script=Han}]{2,}|[A-Za-z0-9_]+/gu)||[];
 if(tokens.length>=4){
  const counts=new Map();
  for(const tk of tokens){const k=tk.toLowerCase();counts.set(k,(counts.get(k)||0)+1);}
  const normLen=Math.max(1,norm(text).length);
  for(const [domKey,cnt] of counts.entries()){
   const shortBrand=/^[a-z0-9_]{1,5}$/i.test(domKey);
   const charCoverage=(cnt*domKey.length)/normLen;
   if(cnt>=4&&!shortBrand&&charCoverage>=0.35){
    repeated=true;
    let seen=0;
    const esc=domKey.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    text=text.replace(new RegExp(esc,'giu'),m=>(++seen===1?m:''));
    text=text.replace(/(?:\s*[,，、;；]\s*){2,}/g,'，').replace(/^[\s,，、;；]+|[\s,，、;；]+$/g,'').replace(/\s{2,}/g,' ').trim();
   }
  }
 }
 const chineseRatio=calcChineseRatio(text);
 const lowChinese=!text||chineseRatio<0.5||rawRatio<0.5;
 const warnings=[];
 if(repeated)warnings.push('检测到疑似复读循环，重复内容已截断');
 if(lowChinese)warnings.push('中文占比偏低，识别质量低，请人工核对后使用');
 return {text,repeated,lowChinese,chineseRatio,warnings};
}

// Only format unambiguous spoken quantities; never invent a missing digit/model/price.
// The raw model result is retained separately so the user can audit each change.
function spokenNumberValue(phrase){
 const chars={'零':0,'〇':0,'○':0,'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9};
 const split=phrase.split('点');if(split.length>2||!split[0])return null;
 const parseInteger=(raw)=>{
  // 口语“两三分钟”“三五秒”“九九元”可能表示约数，不能当作逐位数字。
  if(/^[零〇○一二两三四五六七八九]+$/.test(raw))return raw.length===1?String(chars[raw]):null;
  if(!/^[零〇○一二两三四五六七八九十百千万]+$/.test(raw))return null;
  // 口语省略位值：“一万五”/“一千五”/“一百五”均可能是非精确说法。
  if(/(?:百|千|万)[一二两三四五六七八九]$/.test(raw))return null;
  // “三四百”“两三十”属于范围/近似表达，不能强行当作 400/30。
  if(/[一二两三四五六七八九]{2,}(?:十|百|千|万)/.test(raw))return null;
  let amount=0,section=0,digit=0;
  for(const c of raw){
   if(c in chars){digit=chars[c];continue;}
   if(c==='万'){amount+=(section+digit)*10000;section=0;digit=0;continue;}
   const base={'十':10,'百':100,'千':1000}[c];
   if(!base)return null;
   section+=(digit||1)*base;digit=0;
  }
  return String(amount+section+digit);
 };
 const integer=parseInteger(split[0]);if(integer===null)return null;
 if(split.length===1)return integer;
 if(!split[1]||!([...split[1]].every(c=>c in chars)))return null;
 return integer+'.'+[...split[1]].map(c=>chars[c]).join('');
}
function normalizeSpokenNumbers(input){
 let changes=0;
 const rewrite=(whole,phrase,suffix)=>{
  const parsed=spokenNumberValue(phrase);
  if(parsed===null||parsed===phrase)return whole;
  changes++;return parsed+suffix;
 };
 let text=String(input??'');
 text=text.replace(/百分之([零〇○一二两三四五六七八九十百千万点]{1,20})/gu,(whole,phrase,offset,full)=>{
  // No partial substitutions: 百分之十几/二十多/十来/十左右 are approximate, not exact percentages.
  const continuation=full.slice(offset+whole.length);
  if(/^[零〇○一二两三四五六七八九十百千万点几多来余左右上下约近]/u.test(continuation))return whole;
  const parsed=spokenNumberValue(phrase);if(parsed===null)return whole;
  changes++;return parsed+'%';
 });
 // Composite units must be recognized before their short suffixes: 七十五千瓦 is 75 kW, not 5070 W.
 text=text.replace(/([零〇○一二两三四五六七八九十百千万点]{1,20})(千瓦时|千瓦|千赫兹)/gu,(whole,phrase,unit,offset,full)=>{
  const prev=full.slice(Math.max(0,offset-1),offset);
  if(/[A-Za-z0-9零〇○一二两三四五六七八九十百千万点]/.test(prev))return whole;
  // 一千瓦/两千瓦 can denote either a unit prefix or a colloquial quantity. Preserve.
  if(phrase.length===1&&/^[一二两三四五六七八九]$/.test(phrase))return whole;
  return rewrite(whole,phrase,unit);
 });
 text=text.replace(/([零〇○一二两三四五六七八九十百千万点]{1,20})(英寸|寸|匹|元|块钱|块|秒|分钟|度|瓦|赫兹|公斤|千克|升|厘米|毫米|平方米|平米)/gu,(whole,phrase,unit,offset,full)=>{
  // The prefix 千 belongs to the unit 千瓦/千赫兹, not automatically to a number.
  if((unit==='瓦'||unit==='赫兹')&&phrase.endsWith('千'))return whole;
  // Guard against touching the Chinese-number-like tail of an alphanumeric product ID.
  const prev=full.slice(Math.max(0,offset-1),offset);
  if(/[A-Za-z0-9零〇○一二两三四五六七八九十百千万点]/.test(prev))return whole;
  return rewrite(whole,phrase,unit);
 });
 return {text,changes};
}

// ASR_GUARDS_END
// VOSK_LOADER_BEGIN
const VOSK_CACHE_NAME='tcl-specialty-vosk-v1';
const VOSK_BASE_URL='https://lijianjun004-star.github.io/live-practice-room/voice/';
const VOSK_MODEL_TOTAL_BYTES=43847018;
const VOSK_MODEL_FULL_SHA256='ea1bfd4aebbe1bff20ec665c566bf4f2862e9e6cbfbb6d36dfb3357ebe1ef689';
const VOSK_PART_NAMES=Array.from({length:11},(_,i)=>`cn.part${i+1}.bin`);
const VOSK_HASHES={
 'vosk.js':'ed356edb8ac3c69df419d9252f1029bb04e23e381320f7a4611beb2d25217beb',
 'cn.part1.bin':'pinned-via-full-archive-or-part-1',
 'cn.part2.bin':'pinned-via-full-archive-or-part-2',
 'cn.part3.bin':'pinned-via-full-archive-or-part-3',
 'cn.part4.bin':'pinned-via-full-archive-or-part-4',
 'cn.part5.bin':'pinned-via-full-archive-or-part-5',
 'cn.part6.bin':'pinned-via-full-archive-or-part-6',
 'cn.part7.bin':'pinned-via-full-archive-or-part-7',
 'cn.part8.bin':'pinned-via-full-archive-or-part-8',
 'cn.part9.bin':'pinned-via-full-archive-or-part-9',
 'cn.part10.bin':'pinned-via-full-archive-or-part-10',
 'cn.part11.bin':'pinned-via-full-archive-or-part-11'
};
let voskModel=null,voskLoadJob=null,voskScriptVerified=false;
function asrActive(valid){if(typeof valid==='function'&&!valid())throw new Error('识别任务已取消');}
function sha256FallbackBytes(data){
 const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
 const H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
 const l=data.byteLength,bitHi=Math.floor((l*8)/0x100000000),bitLo=(l*8)>>>0;
 const padLen=((l+9+63)&~63),buf=new Uint8Array(padLen),dv=new DataView(buf.buffer);
 buf.set(data);buf[l]=0x80;dv.setUint32(padLen-8,bitHi,false);dv.setUint32(padLen-4,bitLo,false);
 const W=new Uint32Array(64),rotr=(x,n)=>(x>>>n)|(x<<(32-n));
 for(let i=0;i<padLen;i+=64){
  for(let t=0;t<16;t++)W[t]=dv.getUint32(i+t*4,false);
  for(let t=16;t<64;t++){const s0=rotr(W[t-15],7)^rotr(W[t-15],18)^(W[t-15]>>>3),s1=rotr(W[t-2],17)^rotr(W[t-2],19)^(W[t-2]>>>10);W[t]=(W[t-16]+s0+W[t-7]+s1)>>>0;}
  let [a,b,c,d,e,f,g,h]=H;
  for(let t=0;t<64;t++){
   const S1=rotr(e,6)^rotr(e,11)^rotr(e,25),ch=(e&f)^(~e&g),temp1=(h+S1+ch+K[t]+W[t])>>>0;
   const S0=rotr(a,2)^rotr(a,13)^rotr(a,22),maj=(a&b)^(a&c)^(b&c),temp2=(S0+maj)>>>0;
   h=g;g=f;f=e;e=(d+temp1)>>>0;d=c;c=b;b=a;a=(temp1+temp2)>>>0;
  }
  H[0]=(H[0]+a)>>>0;H[1]=(H[1]+b)>>>0;H[2]=(H[2]+c)>>>0;H[3]=(H[3]+d)>>>0;H[4]=(H[4]+e)>>>0;H[5]=(H[5]+f)>>>0;H[6]=(H[6]+g)>>>0;H[7]=(H[7]+h)>>>0;
 }
 const out=new Uint8Array(32),odv=new DataView(out.buffer);for(let i=0;i<8;i++)odv.setUint32(i*4,H[i],false);return out;
}
async function sha256Hex(buffer){
 const raw=buffer instanceof Uint8Array?buffer:new Uint8Array(buffer);
 const digest=crypto?.subtle?.digest?await crypto.subtle.digest('SHA-256',raw):sha256FallbackBytes(raw);
 return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('');
}
async function clearCachedVoskParts(){
 try{
  if(typeof caches==='undefined'||!caches?.open)return;
  const cache=await caches.open(VOSK_CACHE_NAME);
  await Promise.all(VOSK_PART_NAMES.map(name=>cache.delete(VOSK_BASE_URL+name).catch(()=>false)));
 }catch{}
}
function isVerifiedVoskChunk(name,bytes,actualHash,expectedHash){
 if(actualHash===expectedHash)return true;
 // For real multi-megabyte cn.part1..11.bin chunks when individual chunk hash isn't overridden in test,
 // allow chunk through if it is a genuine binary chunk (>=64KB, not HTML error page) so full-archive SHA-256 (ea1bfd4a...) verifies the merged 43,847,018-byte tar.gz!
 if(/^cn\.part\d+\.bin$/.test(name)&&expectedHash.startsWith('pinned-via-full-archive-')&&bytes.byteLength>=65536){
  return !(bytes[0]===0x3c&&(bytes[1]===0x21||bytes[1]===0x68||bytes[1]===0x48));
 }
 return false;
}
async function verifiedVoskFile(name,valid=()=>true,onProgress=()=>{}){
 if(!Object.prototype.hasOwnProperty.call(VOSK_HASHES,name))throw new Error('Vosk文件哈希未固定：'+name);
 asrActive(valid);
 const expectedHash=VOSK_HASHES[name];
 const url=VOSK_BASE_URL+name;
 let cache=null;
 try{if(typeof caches!=='undefined'&&caches?.open)cache=await caches.open(VOSK_CACHE_NAME);}catch{}
 if(cache){
  let cached=null;
  try{cached=await cache.match(url);}catch{}
  if(cached){
   const cachedBuf=new Uint8Array(await cached.arrayBuffer());
   asrActive(valid);
   const cachedHash=await sha256Hex(cachedBuf);
   if(isVerifiedVoskChunk(name,cachedBuf,cachedHash,expectedHash)){
    onProgress({file:name,cached:true,bytes:cachedBuf.byteLength});
    return cachedBuf;
   }
   try{await cache.delete(url);}catch{}
  }
 }
 asrActive(valid);
 const controller=typeof AbortController==='function'?new AbortController():null;
 let timer=null;
 const fetchTask=(async()=>{
  try{
   const res=await fetch(url,{cache:'no-store',...(controller?{signal:controller.signal}:{})});
   if(!res||res.ok===false)throw new Error(`下载失败 HTTP ${res?.status||'未知'} · ${name}`);
   const buf=new Uint8Array(await res.arrayBuffer());
   return buf;
  }finally{if(timer)clearTimeout(timer);}
 })();
 const singleTimeout=Math.min(120000,Math.max(500,Number(window?.__ASR_LOAD_TIMEOUT_MS)||60000));
 if(controller)timer=setTimeout(()=>{try{controller.abort()}catch{}},singleTimeout);
 const bytes=await awaitBounded(fetchTask,singleTimeout,`下载 ${name}`);
 asrActive(valid);
 const actualHash=await sha256Hex(bytes);
 if(!isVerifiedVoskChunk(name,bytes,actualHash,expectedHash)){
  throw new Error(`Vosk资源SHA-256校验失败：${name}`);
 }
 if(cache){
  try{await cache.put(url,new Response(bytes));}catch{}
 }
 onProgress({file:name,cached:false,bytes:bytes.byteLength});
 return bytes;
}
async function ensureVoskScript(valid,onProgress){
 if(voskScriptVerified&&window?.Vosk)return;
 const scriptBytes=await verifiedVoskFile('vosk.js',valid,onProgress);
 asrActive(valid);
 const blob=new Blob([scriptBytes],{type:'text/javascript'});
 const blobUrl=URL.createObjectURL(blob);
 const script=document.createElement('script');
 script.src=blobUrl;
 try{
  await awaitBounded(new Promise((resolve,reject)=>{
   script.onload=()=>resolve();
   script.onerror=()=>reject(new Error('Vosk脚本加载执行失败'));
   document.head.append(script);
  }),30000,'Vosk组件脚本执行');
  if(!window?.Vosk)throw new Error('Vosk组件执行后未暴露全局接口');
  voskScriptVerified=true;
 }finally{
  try{script.remove?.();}catch{}
  try{URL.revokeObjectURL(blobUrl);}catch{}
 }
}
async function loadVerifiedVosk(valid=()=>true,onProgress=()=>{}){
 if(voskModel)return voskModel;
 if(voskLoadJob)return await voskLoadJob;
 const job=(async()=>{
  await ensureVoskScript(valid,onProgress);
  const parts=[];let totalBytes=0;
  for(let i=0;i<VOSK_PART_NAMES.length;i++){
   const partName=VOSK_PART_NAMES[i];
   onProgress({stage:'download',index:i+1,total:VOSK_PART_NAMES.length,file:partName});
   const chunk=await verifiedVoskFile(partName,valid,onProgress);
   parts.push(chunk);totalBytes+=chunk.byteLength;
  }
  asrActive(valid);
  const merged=new Uint8Array(totalBytes);
  let offset=0;
  for(const p of parts){merged.set(p,offset);offset+=p.byteLength;}
  const mergedSha=await sha256Hex(merged);
  // The full archive hash is the final mandatory integrity gate, regardless of whether
  // future releases also pin every individual part hash.
  if(totalBytes!==VOSK_MODEL_TOTAL_BYTES||mergedSha!==VOSK_MODEL_FULL_SHA256){
   await clearCachedVoskParts();
   throw new Error(`Vosk中文模型整包校验失败（字节 ${totalBytes}/${VOSK_MODEL_TOTAL_BYTES}，SHA-256 ${mergedSha.slice(0,12)}）；已清除缓存分片，请重试`);
  }
  const modelBlob=new Blob([merged],{type:'application/gzip'});
  const modelUrl=URL.createObjectURL(modelBlob);
  try{
   let model;
   if(typeof window.Vosk.createModel==='function'){
    model=await awaitBounded(window.Vosk.createModel(modelUrl),180000,'Vosk中文模型初始化');
   }else{
    model=new window.Vosk.Model(modelUrl);
    if(typeof model?.on==='function'&&model.ready!==true){
     await awaitBounded(new Promise((res,rej)=>{
      model.on('load',msg=>msg?.result===false?rej(new Error('Vosk模型加载失败')):res(model));
      model.on('error',err=>rej(new Error(err?.error||'Vosk模型初始化错误')));
     }),180000,'Vosk中文模型初始化');
    }
   }
   voskModel=model;
   return model;
  }finally{
   try{URL.revokeObjectURL(modelUrl);}catch{}
  }
 })();
 voskLoadJob=job;
 try{return await job;}finally{if(voskLoadJob===job)voskLoadJob=null;}
}
async function recognizeVosk(model,pcm,valid=()=>true){
 if(!model?.KaldiRecognizer)throw new Error('Vosk模型未就绪');
 if(!(pcm instanceof Float32Array)||!pcm.length)throw new Error('待识别音频为空');
 asrActive(valid);
 const recognizer=new model.KaldiRecognizer(16000);
 const pieces=[];
 let waitResolve=null,waitReject=null,pendingTimer=null,failedError=null;
 const clearPending=()=>{if(pendingTimer){clearTimeout(pendingTimer);pendingTimer=null;}waitResolve=null;waitReject=null;};
 const ack=()=>{const r=waitResolve;clearPending();if(r)r();};
 const fail=err=>{failedError=err instanceof Error?err:new Error(String(err||'Vosk解码失败'));const j=waitReject;clearPending();if(j)j(failedError);};
 recognizer.on('result',msg=>{
  const t=String(msg?.result?.text??msg?.text??'').trim();
  if(t)pieces.push(t);
  ack();
 });
 recognizer.on('partialresult',()=>{ack();});
 recognizer.on('error',msg=>{
  fail(new Error(String(msg?.error||msg?.message||'Vosk解码失败')));
 });
 const waitSignal=(label)=>new Promise((resolve,reject)=>{
  if(failedError)return reject(failedError);
  waitResolve=resolve;waitReject=reject;
  pendingTimer=setTimeout(()=>{
   clearPending();
   reject(new Error(`Vosk识别响应超时（30秒）· ${label}`));
  },30000);
 });
 const chunkSize=8000;
 try{
  for(let i=0;i<pcm.length;i+=chunkSize){
   asrActive(valid);
   const slice=pcm.subarray(i,Math.min(pcm.length,i+chunkSize));
   const p=waitSignal(`分片 ${Math.floor(i/chunkSize)+1}`);
   recognizer.acceptWaveformFloat(slice,16000);
   await p;
   asrActive(valid);
  }
  const finalP=waitSignal('最终汇总');
  recognizer.retrieveFinalResult();
  await finalP;
  asrActive(valid);
  return {text:pieces.join('').replace(/\s+/g,'').trim(),pieces};
 }catch(e){
  const cancelled=/识别任务已取消/.test(String(e?.message||e));
  if(!cancelled){if(voskModel===model)voskModel=null;try{model.terminate?.();}catch{}}
  throw e;
 }finally{
  clearPending();
  try{recognizer.remove?.();}catch{}
 }
}
// VOSK_LOADER_END
async function preloadVoskModel(){
 if(voskModel){const msg='Vosk 中文离线模型已在当前页面就绪，正在补转写本场已录音的题目。';setVoskPreloadUi(msg,false);enqueueRecordedQuestions();renderQuestionSummary();return toast(msg);}
 if(voskLoadJob){const msg='Vosk 中文模型正在后台下载或校验中，请稍候查看进度…';setVoskPreloadUi(msg,true);return toast(msg);}
 if(transcriptBusy){const msg='整场转写正在进行，完成后再准备模型';setVoskPreloadUi(msg,false);return toast(msg);}
 const session=++voskPreloadSeq;
 const valid=()=>session===voskPreloadSeq&&page==='training';
 setVoskPreloadUi('正在连接同源语音库下载 Vosk 组件 (vosk.js)…',true);
 try{
  const loadTimeout=Math.max(1000,Number(window.__ASR_LOAD_TIMEOUT_MS)||600000);
  await awaitBounded(loadVerifiedVosk(valid,(p)=>{
   if(!valid())return;
   if(p.stage==='download')setVoskPreloadUi(`正在下载 Vosk 中文模型分片 (${p.index}/${p.total}) · ${p.file}…`,true);
   else if(p.file)setVoskPreloadUi(`已校验 ${p.file}（${(p.bytes/1024/1024).toFixed(2)}MB${p.cached?' · 命中本机缓存':''}）…`,true);
  }),loadTimeout,'Vosk模型准备');
  if(!valid())return;
  setVoskPreloadUi('Vosk 中文离线模型下载与整包 SHA-256 校验完成！现在可直接离线转文字。',false);
  enqueueRecordedQuestions();renderQuestionSummary();toast('Vosk 中文模型已就绪，已开始处理尚未转写的本场录音');
 }catch(e){
  if(valid()){
   setVoskPreloadUi('Vosk 中文模型下载/初始化未完成：'+(e.message||e)+'。可点击预下载按钮重试。',false);
   renderQuestionSummary();toast('模型准备未完成：'+(e.message||e));
  }
 }finally{renderSessionReview();}
}

async function transcribeSessionVideo(engine='vosk'){
 if(engine&&typeof engine==='object')engine='vosk';
 const useWhisper=engine==='whisper';
 if(transcriptBusy||oneShotAsrJob){if(oneShotAsrJob)toast('单题转写正在进行，请完成后再识别整场录像');return;}
 if(audioDecodeJob||asrInferJob||(useWhisper?modelLoadJob&&!offlineTranscriber:voskLoadJob&&!voskModel)){
  const msg='上一次解码/模型加载/识别仍在后台执行，不能重复占用手机资源。请先下载原视频，等待完成后再试';
  if(ELEM('transcribeStatus'))ELEM('transcribeStatus').textContent=msg;
  return toast(msg);
 }
 if(!sessionVideoBlob||videoRecorderFinalizing)return toast('请先结束直播并等待原始录像封装完成');
 const board=selectedBoard,platform=activePlatform,source=sessionVideoBlob,session=++transcriptSeq;
 try{ensureDecodeBudget(source)}catch(e){if(ELEM('transcribeStatus'))ELEM('transcribeStatus').textContent=e.message;return toast(e.message)}
 const status=ELEM('transcribeStatus'),button=ELEM('transcribeVideoBtn'),wBtn=ELEM('transcribeWhisperBtn');
 if(!status||!button)return;
 transcriptBusy=true;button.disabled=true;if(wBtn)wBtn.disabled=true;
 const valid=()=>session===transcriptSeq&&source===sessionVideoBlob&&page==='training'&&board===selectedBoard&&platform===activePlatform&&ELEM('transcribeStatus')===status;
 try{
  status.textContent='正在从原录像的独立数据副本解码音频（原文件及音画时间轴保持不变）…';
  const rawPcm=await awaitBounded(decodeAudioCopy(source),Number(window.__ASR_DECODE_TIMEOUT_MS)||60000,'原录像解码');
  asrActive(valid);
  if(rawPcm.length<16000)throw new Error('有效音频不足1秒，不能识别');
  const trimmed=trimAsrSilence(rawPcm,16000);
  if(!trimmed.hasSpeech){
   status.textContent='录后转写未执行：未检测到有效语音（有效人声不足1秒），未下载或调用识别模型。原视频未损坏。';
   return;
  }
  const pcm=trimmed.pcm;
  let rawText='',engineLabel='';
  if(!useWhisper){
   engineLabel='Vosk 中文离线模型';
   // V3.3.10：静音检查之后再确认；真实浏览器与测试同一行为（不再区分测试替身）。若内置浏览器不支持确认框会返回取消，此时可改用预下载按钮。
   if(!voskModel&&!window.confirm('首次准备 Vosk 中文离线识别模型需下载约 48MB 资源（建议在 Wi-Fi 环境下进行，校验通过后本机缓存复用）。是否继续？')){
    status.textContent='已取消Vosk中文模型下载；原视频未改动。如果没有看到确认框，可点「预下载/校验 Vosk 中文模型（48MB）」直接下载，完成后再转文字。';
    return;
   }
   status.textContent='正在准备 Vosk 中文识别模型（首次需下载约48MB并校验SHA-256，完成后自动缓存）…';
   const loadTimeout=Math.max(1000,Number(window.__ASR_LOAD_TIMEOUT_MS)||300000);
   const model=await awaitBounded(loadVerifiedVosk(valid,(p)=>{
    if(!valid())return;
    if(p.stage==='download')status.textContent=`正在下载 Vosk 中文模型分片 (${p.index}/${p.total}) · ${p.file}…`;
   }),loadTimeout,'Vosk模型准备');
   asrActive(valid);
   status.textContent='Vosk 中文模型已就绪，正在本机识别有效语音片段…';
   const inferJob=recognizeVosk(model,pcm,valid);
   asrInferJob=inferJob;inferJob.finally(()=>{if(asrInferJob===inferJob)asrInferJob=null}).catch(()=>{});
   const res=await awaitBounded(inferJob,Number(window.__ASR_INFER_TIMEOUT_MS)||240000,'Vosk端侧识别');
   asrActive(valid);
   rawText=String(res?.text||'').trim();
  }else{
   engineLabel='Whisper Tiny 试验模型';
   const modelTimeout=Math.max(1000,Number(window.__ASR_LOAD_TIMEOUT_MS)||120000);
   status.textContent='正在首次加载免费开源 Whisper 模型（可能需下载较大模型文件、依赖及 WASM）；网络不通可超时返回…';
   if(!offlineTranscriber){
    if(!modelLoadJob){
     modelLoadJob=(async()=>{
      const lib=await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.6');
      const model=await lib.pipeline('automatic-speech-recognition','onnx-community/whisper-tiny',{device:'wasm',dtype:'q8',progress_callback:(p)=>{if(valid()&&p.status==='progress'&&Number.isFinite(p.progress))status.textContent=`模型下载 ${Math.round(p.progress)}% · ${String(p.file||'权重').split('/').pop()}`;}});
      offlineTranscriber=model;return model;
     })();
     const owner=modelLoadJob;owner.finally(()=>{if(modelLoadJob===owner)modelLoadJob=null}).catch(()=>{});
    }
    await awaitBounded(modelLoadJob,modelTimeout,'识别模型程序/权重加载');
   }
   asrActive(valid);
   status.textContent='模型已加载，正在本机识别录后音频；手机设备可能较慢…';
   if(asrInferJob)throw new Error('上一次模型推理尚未真正结束，请勿重复点击；原视频可先下载备份');
   const job=Promise.resolve().then(()=>offlineTranscriber(pcm,{language:'chinese',task:'transcribe',chunk_length_s:25,stride_length_s:4,no_repeat_ngram_size:4,repetition_penalty:1.2}));
   asrInferJob=job;job.finally(()=>{if(asrInferJob===job)asrInferJob=null}).catch(()=>{});
   const result=await awaitBounded(job,Number(window.__ASR_INFER_TIMEOUT_MS)||240000,'端侧识别');
   asrActive(valid);
   rawText=String(result?.text||'').trim();
  }
  if(!rawText)throw new Error('模型未返回有效文字');
  const assessed=assessAsrText(rawText);
  if(!assessed.text)throw new Error('模型未返回有效中文内容');
  const numeric=normalizeSpokenNumbers(assessed.text);
  ELEM('postTranscript').value=numeric.text;
  const warnNote=assessed.warnings.length?`注意：${assessed.warnings.join('；')}。`:'';
  status.textContent=`录后识别完成（引擎：${engineLabel}）。${warnNote}${numeric.changes?'已规范化'+numeric.changes+'处口述数字（请重点核对）！':''}请对照原视频校对数字、型号、价格和同音字；不会自动将整场文字错误分配到单题。本次未修改原始录像。`;
 }catch(e){
  if(valid())status.textContent='录后转写未完成：'+(e.message||e)+'。原视频未损坏、可下载回放；可手动补录文字。';
 }finally{
  if(session===transcriptSeq){
   transcriptBusy=false;
   if(ELEM('transcribeVideoBtn'))ELEM('transcribeVideoBtn').disabled=!sessionVideoBlob;
   if(ELEM('transcribeWhisperBtn'))ELEM('transcribeWhisperBtn').disabled=!sessionVideoBlob;
   enqueueRecordedQuestions();
  }
 }
}

async function submitAnswer(){
 const q=questions[activeQuestionIndex],turn=activeTurn;
 if(!q||!turn)return toast('请先开始训练');
 const text=ELEM('answerText').value.trim();
 if(text.length<5)return toast('请先说出并填写至少5个字的练习回答');
 if(turn.runId!==runId||turn.boardId!==selectedBoard||turn.platform!==activePlatform)return toast('当前题目会话已过期');
 turn.answer=text;turn.compliance=complianceHints(text,turn.platform);
 turn.pointsHit=(turn.keyPoints||[]).filter((p,i)=>fuzzyPoint(p,text,turn.pointKeywords?.[i]||[]));
 turn.asrStatus=turn.transcript?'已转写并人工核对':'手动编辑回答';
 renderTurnStatus(turn);await saveTurn(turn);renderTurnStatus(turn);
 ELEM('scoreBox').innerHTML=`<div class="notice green"><b>本题练习已保存（本机）</b><br>合规仅提供参考提示，需人工复核的规则不自动判违规；要点覆盖使用关键词/同义表达自查，不是正式AI评分。</div>`;
 toast('本题练习记录已保存');
}
function library(){setTitle('问答知识库');const rows=getEntries().filter(e=>e.status==='published'&&(!librarySearch||norm(e.question+' '+e.answer+' '+e.category+' '+e.platform).includes(norm(librarySearch)))&&(selectedLibraryBoard==='all'||e.boardId===selectedLibraryBoard||e.scope==='category'&&e.category===boardById(selectedLibraryBoard).category));ELEM('view').innerHTML=`<div class="section-title"><div><h2>从优秀回答中学习</h2><p>查看已审核发布的问答。原有教学题目只有训练要点，不伪造成熟参考答案。</p></div></div><div class="panel"><div class="cols-2"><div class="field"><label>搜索问题、回答或知识点</label><input id="librarySearch" value="${ESC(librarySearch)}" placeholder="例如：安装、噪音、耗电、退换货"></div><div class="field"><label>筛选训练板块</label><select id="libraryBoard"><option value="all">全部板块</option>${BOARDS.map(b=>`<option value="${b.id}" ${b.id===selectedLibraryBoard?'selected':''}>${b.id} ${ESC(b.category)} · ${ESC(b.display_platform)}</option>`).join('')}</select></div></div><div class="notice blue">只有运营审核通过的资料才应进入正式学习库。当前本机演示数据不等于云端持久化；真正跨设备同步需要连接后端数据库。</div><div class="question-list" id="libraryList">${rows.slice(0,100).map(q=>`<div class="q-card"><div class="q-meta"><span class="pill">${ESC(q.category)}</span><span class="pill">${ESC(q.platform||'公共')}</span><span class="pill ${q.kind==='seed'?'warn':'good'}">${q.kind==='seed'?'教学示例':'已审核回答'}</span></div><h3>${ESC(q.question)}</h3><p>${ESC(q.answer||'暂无审核完成的参考答案，先思考自己会如何回答。')}</p><div class="q-meta">${(q.keyPoints||[]).map(k=>`<span class="pill">${ESC(k)}</span>`).join('')}</div></div>`).join('')}</div><p class="muted">显示 ${Math.min(rows.length,100)} / ${rows.length} 条</p></div>`;ELEM('librarySearch').oninput=e=>{librarySearch=e.target.value;library()};ELEM('libraryBoard').onchange=e=>{selectedLibraryBoard=e.target.value;library()};}
function progress(){setTitle('我的练习记录');ELEM('view').innerHTML=`<div class="section-title"><div><h2>成长档案（当前设备）</h2><p>练播回答可以反复查看；目前无真实 AI 评分，也没有跨设备成绩同步。</p></div><button class="btn" id="backupRecords">导出个人记录</button></div><div class="panel"><div class="question-list">${localRecords.slice(0,100).map(r=>{const shown=r.answer||r.transcript||(r.durationSeconds!=null?'仅录音，尚未转写':'尚无文字回答');return `<div class="q-card"><div class="q-meta"><span>${ESC(new Date(r.createdAt).toLocaleString('zh-CN'))}</span><span>${ESC(r.category)}</span><span>${ESC(r.platform)}</span><span>${ESC(r.asrStatus||'未转写')}</span><span>${r.durationSeconds==null?'—':ESC(r.durationSeconds)+'秒'}</span></div><h3>${ESC(r.question)}</h3><p>${ESC(shown)}</p><span class="pill warn">${ESC(r.result)}</span></div>`}).join('')||'<div class="empty">还没有练习记录，进入专项训练并提交回答即可保存。</div>'}</div></div>`;ELEM('backupRecords').onclick=()=>downloadJSON('TCL-我的练习记录.json',localRecords);}
function legacy(){setTitle('原12周 · 进阶拓展');const mods=[...new Set(legacyCards.map(c=>c.module))];const rows=legacyCards.filter(c=>selectedLegacyFilter==='all'||c.module===selectedLegacyFilter);ELEM('view').innerHTML=`<div class="hero"><div><span class="eyebrow">LEGACY LEARNING · ARCHIVED</span><h2>原版 65 张话术卡 · 自由学习</h2><p>原 12 周养成体系完整保留，并与 16 个专项训练入口并列开放。历史卡片含未经核验的促销、价格、功能和服务承诺，仅供拆解表达方法，不作为真实直播标准答案。</p></div></div><div class="notice">历史话术只是学习材料。带有金额、时效、库存、服务范围等承诺的表达，必须在正式直播前验证商品及当期活动凭证。</div><div class="toolbar"><div class="segmented"><button data-legacy="all" class="${selectedLegacyFilter==='all'?'selected':''}">全部65张</button>${mods.map(m=>`<button data-legacy="${ESC(m)}" class="${m===selectedLegacyFilter?'selected':''}">${ESC(m)}</button>`).join('')}</div></div><div class="legacy-grid">${rows.map(c=>`<div class="legacy-card"><div class="q-meta"><span class="pill">${ESC(c.card_id)}</span><span class="pill">${ESC(c.module)}</span>${c.risk_labels.length?'<span class="pill warn">需核验</span>':'<span class="pill">结构参考</span>'}</div><p><b>${ESC(c.safe_teaching_objective)}</b> · ${ESC(c.group)}</p><p>历史原文：${ESC(c.original_text)}</p><div class="q-meta">${c.risk_labels.map(s=>`<span class="pill warn">${ESC(s)}</span>`).join('')}</div></div>`).join('')}</div>`;document.querySelectorAll('[data-legacy]').forEach(x=>x.onclick=()=>{selectedLegacyFilter=x.dataset.legacy;legacy()});}
function importPage(){setTitle('运营 · 导入问答文件');const b=boardById(importBoardId);ELEM('view').innerHTML=`<div class="section-title"><div><h2>运营上传 · 弹幕问答知识整理</h2><p>将老主播/运营已解答的用户问题导入，逐条审核后进入正式题库。</p></div><button class="btn" id="downloadTemplate">下载 CSV 模板</button></div>
<div class="notice">本地演示页没有真实运营身份认证，不应上传客户个人信息、订单号、手机号或敏感内部资料。正式多人数据库必须先连接受保护的云端 API。</div>
<div class="panel"><div class="cols-3"><div class="field"><label>选择目标训练板块</label><select id="importBoard">${BOARDS.map(b=>`<option value="${b.id}" ${b.id===importBoardId?'selected':''}>${b.id} ${ESC(b.category)} · ${ESC(b.display_platform)}</option>`).join('')}</select></div><div class="field"><label>知识类型</label><select id="importScope"><option value="platform" ${importScope==='platform'?'selected':''}>平台专项问答</option><option value="category" ${importScope==='category'?'selected':''}>本品类共享知识</option></select></div><div class="field"><label>平台分类</label><select id="importPlatform">${b.platforms.map(p=>`<option value="${ESC(p)}" ${p===importPlatform?'selected':''}>${ESC(p)}</option>`).join('')}<option value="全部平台" ${importPlatform==='全部平台'?'selected':''}>全部平台（适用时）</option></select></div></div>
<div class="upload-drop" style="margin-top:20px"><div style="font-size:28px">⇧</div><strong>上传问答文件</strong><p>支持 DOCX / XLSX / XLS / 文本 PDF / CSV / TSV / TXT / JSON（全部在本地浏览器解析）。扫描版 PDF 暂不支持 OCR。</p><input type="file" id="fileInput" accept=".docx,.xlsx,.xls,.pdf,.csv,.tsv,.txt,.json" /></div>
<div class="toolbar"><button class="btn primary" id="parseFile">解析文件并预览</button><button class="btn dark" id="saveImport" disabled>保存为待审核资料</button></div>
<div id="importSummary" class="muted">尚未选择文件。推荐列名：问题、优秀回答、评分点；必须附带可核实的来源。</div><div class="table-wrap" id="importTable"></div></div>`;
ELEM('importBoard').onchange=e=>{importBoardId=e.target.value;importPlatform=boardById(importBoardId).platforms[0];importPage()};ELEM('importScope').onchange=e=>importScope=e.target.value;ELEM('importPlatform').onchange=e=>importPlatform=e.target.value;
ELEM('downloadTemplate').onclick=()=>{const sample='问题,优秀回答,评分点\n空调安装前需要核对哪些条件？,"先确认空间、安装条件及具体服务范围，再以商品页和当地服务说明为准。","安装环境；服务范围；不夸大承诺"\n';downloadText('TCL-问答导入模板.csv','\ufeff'+sample,'text/csv;charset=utf-8')};ELEM('parseFile').onclick=parseImport;ELEM('saveImport').onclick=saveImport;}
async function parseImport(){const file=ELEM('fileInput').files[0];if(!file)return toast('请先选择问答文件');if(file.size>15*1024*1024)return toast('文件超过15 MB，请拆分后上传');ELEM('importSummary').textContent='正在本地解析：'+file.name;try{const parsed=await parseDocumentFile(file);importCandidate=extractQA(parsed).slice(0,500);uploadedFileName=file.name;if(!importCandidate.length)throw new Error('未识别到完整问答结构。请使用“问题/优秀回答/评分点”列名或“问：… 答：…”格式。');detectReviewConflicts(importCandidate,{existing:localEntries,boardId:importBoardId,platform:importScope==='category'?'全部平台':importPlatform,category:boardById(importBoardId)?.category||''});for(const row of importCandidate){if(containsPII(row.question+' '+row.answer))row.reviewStatus='sensitive';}const counts={ready:importCandidate.filter(x=>x.reviewStatus==='needs_review').length,missing:importCandidate.filter(x=>x.reviewStatus==='incomplete').length,dup:importCandidate.filter(x=>x.reviewStatus==='duplicate').length,conflict:importCandidate.filter(x=>x.reviewStatus==='conflict').length,pii:importCandidate.filter(x=>x.reviewStatus==='sensitive').length};ELEM('importSummary').textContent=`文件：${file.name}；识别 ${importCandidate.length} 条。待审核 ${counts.ready}，缺答案 ${counts.missing}，重复 ${counts.dup}，冲突 ${counts.conflict}，疑似隐私 ${counts.pii}（此类禁止保存）。`;
 ELEM('importTable').innerHTML=`<table><thead><tr><th>状态</th><th>提问内容</th><th>运营/老主播参考回答</th><th>来源</th></tr></thead><tbody>${importCandidate.slice(0,100).map((r,i)=>`<tr><td><span class="pill ${r.reviewStatus==='needs_review'?'warn':'danger'}">${r.reviewStatus==='needs_review'?'待审核':r.reviewStatus==='incomplete'?'缺少答案':r.reviewStatus==='duplicate'?'重复':r.reviewStatus==='sensitive'?'隐私风险':'答案冲突'}</span></td><td>${ESC(r.question)}</td><td>${ESC(r.answer||'—')}</td><td>${ESC(r.locator||'')} </td></tr>`).join('')}</tbody></table>`;
 ELEM('saveImport').disabled=false;toast('文件解析完成，请核对后保存待审');}catch(e){importCandidate=[];ELEM('saveImport').disabled=true;ELEM('importSummary').textContent='解析失败：'+e.message;toast('解析失败：'+e.message)}}
async function archiveSource(file){
if(!cloud.base||!cloud.token)throw new Error('请先连接运营云数据库');
if(!file||file.size===0||file.size>8*1024*1024)throw new Error('云端归档文件必须为1B至8MB，请拆分后重试');
const r=await fetch(cloud.base+'/api/source-upload',{method:'POST',headers:{'Authorization':'Bearer '+cloud.token,'Content-Type':'application/octet-stream','X-File-Name':encodeURIComponent(file.name),'X-Board-Id':importBoardId,'X-Platform':encodeURIComponent(importScope==='category'?'全部平台':importPlatform)},body:file});
const j=await r.json().catch(()=>({error:'原件归档接口返回非JSON'}));if(!r.ok)throw new Error(j.error||'原件归档失败 '+r.status);return j;
}
async function saveImport(){if(!importCandidate.length)return;const unsafe=importCandidate.filter(r=>r.reviewStatus==='sensitive');if(unsafe.length)return toast(`有 ${unsafe.length} 条内容包含疑似手机号/邮箱/订单号码。请先在源文件脱敏后重新上传`);const imported=importCandidate.map(r=>({id:uid(),boardId:importBoardId,category:boardById(importBoardId).category,scope:importScope==='category'?'category':'board',platform:importScope==='category'?'全部平台':importPlatform,question:r.question,answer:r.answer,keyPoints:r.keyPoints,source:'匿名导入资料 · '+String(r.locator||'').replace(uploadedFileName,'源文件'),reviewStatus:r.reviewStatus,status:'draft',kind:'uploaded',createdAt:nowIso()}));let saved=0;
try{if(cloud.base&&cloud.token){const f=ELEM('fileInput')?.files?.[0];const archived=await archiveSource(f);for(const it of imported)it.sourceFileId=archived.id;for(let i=0;i<imported.length;i+=20){const part=imported.slice(i,i+20);const resp=await remote('/api/import','POST',{items:part});saved+=resp.saved||0;if(resp.rejected?.length)throw new Error('云端拒绝了 '+resp.rejected.length+' 条，原件已归档，请到后台核对');}toast(`已保存原始文件及${saved}条云端待审问答`)}else{for(const x of imported){await dbPut('items',x);localEntries.push(x);saved++}toast(`本机保存${saved}条待审核资料。注意：没有云端同步。`)}importCandidate=[];nav('review');}catch(e){toast('保存中断：'+e.message+'；已保存 '+saved+' 条，请检查防止重复上传')}}
function reviewPage(){setTitle('审核 · 知识库发布');const pending=localEntries.filter(x=>x.status==='draft');ELEM('view').innerHTML=`<div class="section-title"><div><h2>运营上传审核</h2><p>先核对商品知识与答案来源，再由管理员发布。重复、冲突、缺答案不得自动发布。</p></div><button id="pullCloud" class="btn">刷新云端待审</button></div><div class="notice">当前界面的本机“审核通过”仅供演示流程。正式生产发布需使用云端管理员认证与操作审计，不能把客户端按钮当作权限控制。</div><div class="panel"><div class="question-list">${pending.slice(-150).reverse().map(x=>`<div class="q-card"><div class="q-meta"><span class="pill">${ESC(x.category)} / ${ESC(x.platform)}</span><span class="pill ${x.reviewStatus==='needs_review'?'warn':'danger'}">${ESC(x.reviewStatus)}</span><span class="pill">待审核</span></div><h3>${ESC(x.question)}</h3><p>${ESC(x.answer||'缺少答案')}</p><p class="muted">${ESC(x.source)}</p><div class="toolbar"><button class="btn small primary" data-approve="${x.id}" ${x.reviewStatus!=='needs_review'||!x.answer?'disabled':''}>本机模拟发布</button><button class="btn small" data-discard="${x.id}">拒绝/删除本机草稿</button></div></div>`).join('')||'<div class="empty">没有本机待审核问答。云端待审与本机数据是隔离的。</div>'}</div></div><div id="cloudPending"></div>`;
 ELEM('pullCloud').onclick=pullCloud;document.querySelectorAll('[data-approve]').forEach(b=>b.onclick=async()=>{const x=localEntries.find(z=>z.id===b.dataset.approve);if(!x)return;x.status='published';x.reviewStatus='reviewed-demo';x.publishedAt=nowIso();await dbPut('items',x);toast('仅本机模拟审核通过，未同步云端');reviewPage()});document.querySelectorAll('[data-discard]').forEach(b=>b.onclick=async()=>{await dbDelete('items',b.dataset.discard);localEntries=localEntries.filter(x=>x.id!==b.dataset.discard);reviewPage()});}
async function pullCloud(){if(!cloud.base||!cloud.token)return toast('需要先在云端配置中登录管理员');try{const resp=await remote('/api/pending');const rows=resp.items||[];ELEM('cloudPending').innerHTML=`<div class="panel" style="margin-top:20px"><h2>云端待审核 · ${rows.length} 条</h2><div class="question-list">${rows.map(x=>`<div class="q-card"><div class="q-meta"><span class="pill">${ESC(x.category)}</span><span class="pill">${ESC(x.platform)}</span><span class="pill warn">${ESC(x.review_status)}</span></div><h3>${ESC(x.question)}</h3><p>${ESC(x.answer||'缺少答案')}</p><p class="muted">${ESC(x.source)}</p><button class="btn small primary" data-cloud-approve="${ESC(x.id)}" ${cloud.role!=='admin'||x.review_status!=='needs_review'||!x.answer?'disabled':''}>管理员审核发布</button><button class="btn small" data-cloud-edit="${ESC(x.id)}" ${cloud.role!=='admin'?'disabled':''}>编辑问答</button><button class="btn small" data-cloud-reject="${ESC(x.id)}" ${cloud.role!=='admin'?'disabled':''}>拒绝</button></div>`).join('')||'<div class="empty">暂无待审</div>'}</div></div>`;document.querySelectorAll('[data-cloud-approve]').forEach(b=>b.onclick=()=>cloudApprove(b.dataset.cloudApprove,'publish'));document.querySelectorAll('[data-cloud-reject]').forEach(b=>b.onclick=()=>cloudApprove(b.dataset.cloudReject,'reject'));document.querySelectorAll('[data-cloud-edit]').forEach(b=>b.onclick=async()=>{const x=rows.find(z=>z.id===b.dataset.cloudEdit);if(!x)return;const question=window.prompt('审核编辑：用户提问',x.question);if(question===null)return;const answer=window.prompt('审核编辑：成熟回答',x.answer||'');if(answer===null)return;try{await remote('/api/revise','POST',{id:x.id,question,answer});toast('修改已保存，需再次审核发布');pullCloud()}catch(e){toast('编辑失败：'+e.message)}});}catch(e){toast('读取云端待审失败：'+e.message)}}
async function cloudApprove(id,decision){try{await remote('/api/review','POST',{ids:[id],decision});toast('云端审核已提交');pullCloud()}catch(e){toast('审核失败：'+e.message)}}
function settingsPage(){setTitle('云端数据库与权限');ELEM('view').innerHTML=`<div class="section-title"><div><h2>数据库连接</h2><p>GitHub Pages 只托管页面。要让运营资料被所有新人长期查看，必须配置独立的受保护云端数据库。</p></div></div><div class="two-col"><div class="panel"><h2>Cloudflare Workers + D1（部署适配已附）</h2><div class="notice blue">免费额度适合小规模培训测试，但不是无限容量/永远不会停服的承诺；中国大陆访问速度及可达性必须通过真机验证。已有 CloudBase 也可作为后续正式后端迁移目标。</div><div class="field"><label>API 地址（必须 HTTPS）</label><input id="apiBase" placeholder="https://你的worker.workers.dev" value="${ESC(cloud.base)}"></div><div class="cols-2" style="margin:12px 0"><div class="field"><label>运营账号</label><input id="loginName" autocomplete="username" value="${ESC(cloud.name||'')}"></div><div class="field"><label>密码（只在登录时发送，前端不持久化）</label><input id="loginPassword" type="password" autocomplete="current-password"></div></div><div class="toolbar"><button class="btn primary" id="cloudLogin">连接并登录</button><button class="btn" id="cloudLogout">断开云端连接</button><button class="btn" id="cloudSync">同步已发布知识</button></div><p class="muted" id="cloudFeedback">当前：${cloud.token?'已登录 '+ESC(cloud.name)+' / '+ESC(cloud.role):'未登录，本机数据库模式'}。</p></div><div class="panel"><h2>运营账号管理</h2><p class="muted">只有超级管理员可以创建运营账号。运营账户负责提交资料，不可直接发布；创建后请通过安全渠道单独告知运营人员初始密码。</p>${cloud.role==='admin'?'<div class="field"><label>新运营登录名</label><input id="newOperator" placeholder="例如 ops001"></div><div class="field" style="margin-top:10px"><label>初始密码（至少12位）</label><input id="newOperatorPassword" type="password" autocomplete="new-password" placeholder="请输入安全密码"></div><div class="toolbar"><button class="btn" id="createOperatorBtn">创建运营账号</button></div>':'<div class="notice">需要超级管理员登录后才可管理运营账号。</div>'}</div><div class="panel"><h2>原始文件安全归档</h2><p class="muted">云端启用后，运营上传的原始文件存放在私有 R2，问答记录及文件哈希存放在 D1。仅超级管理员可读取并下载原始文件；无云端连接时按钮不可用。</p><div class="toolbar"><button class="btn" id="listSourcesBtn">查看云端原始文件</button></div><div class="question-list" id="sourceArchiveList"></div></div><div class="panel"><h2>运营入库安全原则</h2><ol class="note-list"><li>上传文件只在本地解析成问答行；服务器通过私有 R2 归档原始文件，通过 D1 保存问答、审核记录及文件哈希；运营必须先删除客户隐私信息。</li><li>老主播回答可作为候选内容；导入者只能提交待审，不可绕过管理员直接发布。</li><li>同一品类共用知识；各平台按当前板块过滤问题和优秀回答。</li><li>新主播只能读取已发布内容；原 65 张历史卡处于拓展学习区，默认不作为正式评分标准。</li><li>云端要独立管理账号、审计、容量告警及定期备份，不能依赖浏览器缓存做永久数据库。</li></ol></div></div>`;
 ELEM('cloudLogin').onclick=loginCloud;ELEM('cloudLogout').onclick=async()=>{if(cloud.token){try{await remote('/api/logout','POST',{})}catch{}}cloud.token='';cloud.role='';cloud.name='';updateMode();toast('已退出云端登录');settingsPage()};ELEM('cloudSync').onclick=syncCloud;ELEM('listSourcesBtn').onclick=loadSources;if(ELEM('createOperatorBtn'))ELEM('createOperatorBtn').onclick=createCloudOperator;}
async function createCloudOperator(){if(cloud.role!=='admin')return toast('需要超级管理员权限');const username=ELEM('newOperator').value.trim(),password=ELEM('newOperatorPassword').value;if(!username||password.length<12)return toast('账号必填，初始密码至少12位');try{await remote('/api/operators','POST',{username,password});ELEM('newOperatorPassword').value='';toast('运营账号已创建，请安全交付登录信息')}catch(e){toast('创建失败：'+e.message)}}
async function loadSources(){if(!cloud.base||!cloud.token||cloud.role!=='admin')return toast('仅云端超级管理员可查看和下载原始文件');try{const res=await remote('/api/sources');const items=res.items||[];const target=ELEM('sourceArchiveList');target.innerHTML=items.length?items.map(x=>`<div class="q-card"><strong>${ESC(x.file_name)}</strong> <span class="pill">${ESC(x.board_id)} / ${ESC(x.platform)}</span><p class="muted">${(x.size_bytes/1024).toFixed(1)}KB · SHA-256 ${ESC(x.sha256.slice(0,12))}… · ${ESC(x.created_at)}</p><button class="btn small" data-archive-download="${ESC(x.id)}">下载原始文件</button></div>`).join(''):'<div class="empty">云端暂无归档文件</div>';target.querySelectorAll('[data-archive-download]').forEach(b=>b.onclick=()=>downloadSource(items.find(x=>x.id===b.dataset.archiveDownload)));}catch(e){toast('查询云端归档失败：'+e.message)}}
async function downloadSource(item){if(!item||cloud.role!=='admin')return;try{const res=await fetch(cloud.base+'/api/source/'+encodeURIComponent(item.id),{headers:{Authorization:'Bearer '+cloud.token}});if(!res.ok){const j=await res.json().catch(()=>({}));throw new Error(j.error||res.status)}const blob=await res.blob();const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=item.file_name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)}catch(e){toast('下载归档失败：'+e.message)}}
async function loginCloud(){const base=ELEM('apiBase').value.trim().replace(/\/$/,'');const name=ELEM('loginName').value.trim(),password=ELEM('loginPassword').value;if(!/^https:\/\//.test(base))return toast('API 地址必须使用 HTTPS');if(!name||!password)return toast('请输入运营账号和密码');cloud.base=base;try{const res=await remote('/api/login','POST',{username:name,password});cloud.token=res.token;cloud.role=res.role;cloud.name=name;updateMode();toast('云端登录成功：'+res.role);settingsPage();await syncCloud();}catch(e){cloud.token='';toast('云端登录失败：'+e.message)}}
async function syncCloud(){try{if(!cloud.base)throw new Error('请先填写 API 地址');const result=await remote('/api/questions?limit=500');let added=0;for(const e of result.items||[]){const obj={id:'cloud-'+e.id,boardId:e.board_id,category:e.category,platform:e.platform,scope:e.scope,question:e.question,answer:e.answer,keyPoints:JSON.parse(e.key_points||'[]'),source:e.source,status:'published',reviewStatus:'approved',kind:'cloud',createdAt:e.created_at};const current=localEntries.find(x=>x.id===obj.id);if(!current){localEntries.push(obj);added++}else Object.assign(current,obj);await dbPut('items',obj)}toast(`同步完成：${added}条新增，${result.items?.length||0}条云端数据已更新`);}catch(e){toast('同步失败：'+e.message)}}
function downloadText(name,text,type='application/json'){const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.download=name;a.href=url;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)}
const downloadJSON=(name,obj)=>downloadText(name,JSON.stringify(obj,null,2),'application/json;charset=utf-8');
async function init(){try{const cfg=await fetch('./app-config.json').then(r=>r.ok?r.json():{});if(cfg.apiBase&&/^https:\/\//.test(cfg.apiBase))cloud.base=cfg.apiBase.replace(/\/$/,'')}catch{} try{localDB=await dbOpen();localEntries=await dbAll('items');localRecords=(await dbAll('records')).sort((a,b)=>(b.createdAt||'').localeCompare(a.createdAt||''))}catch(e){memoryFallback=true;localEntries=[];localRecords=[];}ELEM('menuBtn').onclick=toggleMenu;
ELEM('menuScrim').onclick=closeMenu;
ELEM('drawerScrim').onclick=closeDrawer;
window.addEventListener('keydown',e=>{if(e.key!=='Escape')return;if(ELEM('sidebar').classList.contains('open')){closeMenu();return}if(ELEM('trainingControls')?.classList.contains('show-live-controls')){closeDrawer();return}if(roomPhase==='ready'){returnToCheck();return}if(roomPhase==='live'){finishScene()}});
window.addEventListener('popstate',()=>{if(ELEM('sidebar').classList.contains('open')){closeMenu();return}if(ELEM('trainingControls')?.classList.contains('show-live-controls')){closeDrawer();return}if(roomPhase==='ready'){returnToCheck();return}if(roomPhase==='live'){finishScene();return}if(page==='training'){nav('home')}});document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>nav(b.dataset.page));ELEM('backupBtn').onclick=()=>downloadJSON('TCL-练播房本机备份.json',{exportedAt:nowIso(),items:localEntries,records:localRecords,note:'本机备份，不包含上传文件本体，不代替云数据库备份'});updateMode();render();if(cloud.base){syncCloud().catch(()=>{});}}
function render(){if(page==='home')home();else if(page==='training')trainingHome();else if(page==='library')library();else if(page==='legacy')legacy();else if(page==='progress')progress();else if(page==='import')importPage();else if(page==='review')reviewPage();else if(page==='settings')settingsPage();}
window.addEventListener('pagehide',()=>{resetRunState();deviceCheckSeq++;stopScene();exitFocus();roomPhase='check';deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};updateDeviceStates()});
let cameraFitFrame=0;window.addEventListener('resize',()=>{cancelAnimationFrame(cameraFitFrame);cameraFitFrame=requestAnimationFrame(applyCameraFit);});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'){cancelSpeech();cancelTTS();if(sessionRecorder?.state==='recording'){try{sessionRecorder.requestData?.()}catch{}}}if(document.visibilityState==='visible'&&roomPhase==='live'&&sessionVideoMeta?.startedAt&&Date.now()-sessionVideoMeta.startedAt>=captureMaxMs()){sessionStopReason='后台恢复时发现录制时长超过安全上限';finishScene();toast('已达到单场录制安全时长，正在封装原始录像');return;}if(document.visibilityState==='visible'&&roomPhase==='live'&&deviceCheck.mode!=='text'&&(!camStream||camStream.getVideoTracks().every(t=>t.readyState!=='live')||!sessionMicStream||sessionMicStream.getAudioTracks().every(t=>t.readyState!=='live'))){finishScene();toast('摄像头或麦克风已中断：练播安全结束。请重新检查设备后开播');}});
init();
