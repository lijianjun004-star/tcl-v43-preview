import { parseDocumentFile } from './lib/parser.js';
import { extractQA, detectReviewConflicts } from './lib/qa-import.js';

const STORE_NAME='tcl-specialty-v3';
const BOARDS_RAW=await (await fetch('./training-boards.json')).json();
const LEGACY_RAW=await (await fetch('./legacy-65.json')).json();
const BOARDS=BOARDS_RAW.boards;
const ELEM=(id)=>document.getElementById(id);
const ESC=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>crypto?.randomUUID?.()||'id-'+Date.now()+'-'+Math.random().toString(16).slice(2);
const norm=(s)=>String(s||'').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
const containsPII=(s)=>/(?:1[3-9]\d{9})|(?:\b\d{16,19}\b)|(?:[\w.+-]+@[\w.-]+\.[a-z]{2,})/i.test(String(s||''));
const boardById=(id)=>BOARDS.find(x=>x.id===String(id))||BOARDS[0];
const iconFor=(s)=>/电视/.test(s)?'▣':/空调/.test(s)?'❄':/冰箱/.test(s)?'▤':/洗衣/.test(s)?'◎':/显示器/.test(s)?'▥':/门锁/.test(s)?'⌘':/生活/.test(s)?'⌖':'◈';
const nowIso=()=>new Date().toISOString();
let page='home', selectedBoard='01', activePlatform='京东', activeQuestionIndex=0, questions=[], recChunks=[], currentRecorder=null, micStream=null, camStream=null, answerAudioURL='', chatTimer=null, liveStarted=false, importCandidate=[], localEntries=[], localRecords=[], legacyCards=LEGACY_RAW.cards, cloud={base:'',token:'',role:'',name:''}, librarySearch='', importBoardId='01', importScope='platform', importPlatform='京东', selectedLibraryBoard='all', selectedLegacyFilter='all', uploadedFileName='';
let roomPhase='check', deviceCheckSeq=0, deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false}, lastDeviceError='';
let localDB=null, memoryFallback=false, cameraBusy=false;
const memStores={items:new Map(),records:new Map(),prefs:new Map()};
const dbOpen=()=>new Promise((resolve,reject)=>{
 if(!('indexedDB' in window))return reject(new Error('IndexedDB unavailable'));
 let settled=false;
 const timeoutMs=typeof window.__IDB_TIMEOUT_MS==='number'?window.__IDB_TIMEOUT_MS:10000;
 const timer=setTimeout(()=>{if(!settled){settled=true;reject(new Error('IndexedDB open timeout'));}},timeoutMs);
 const done=(fn,val)=>{if(!settled){settled=true;clearTimeout(timer);fn(val);}};
 try{
  const req=indexedDB.open(STORE_NAME,1);
  req.onupgradeneeded=()=>{const db=req.result;for(const name of ['items','records','prefs'])if(!db.objectStoreNames.contains(name))db.createObjectStore(name,{keyPath:'id'});};
  req.onsuccess=()=>{if(settled){try{req.result?.close?.();}catch{}return;}done(resolve,req.result);};
  req.onerror=()=>done(reject,req.error||new Error('IDB open error'));
  req.onblocked=()=>done(reject,new Error('IDB open blocked'));
 }catch(e){done(reject,e);}
});
const dbAll=(store)=>memoryFallback?Promise.resolve([...(memStores[store]?.values()||[])]):new Promise((resolve,reject)=>{const req=localDB.transaction(store,'readonly').objectStore(store).getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
const dbPut=(store,obj)=>memoryFallback?(memStores[store]?.set(obj.id,obj),Promise.resolve(obj.id)):new Promise((resolve,reject)=>{const req=localDB.transaction(store,'readwrite').objectStore(store).put(obj);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
const dbDelete=(store,id)=>memoryFallback?(memStores[store]?.delete(id),Promise.resolve()):new Promise((resolve,reject)=>{const req=localDB.transaction(store,'readwrite').objectStore(store).delete(id);req.onsuccess=()=>resolve();req.onerror=()=>reject(req.error);});
const toast=(message)=>{const el=ELEM('toast');el.textContent=message;el.classList.add('show');clearTimeout(toast.tm);toast.tm=setTimeout(()=>el.classList.remove('show'),3400)};
const categoryType=(b)=>b.category;
const platformOptions=(b)=>b.platforms;
const matchEntry=(entry,board,platform)=>entry.status==='published' && ((entry.scope==='category' && entry.category===board.category)||(entry.boardId===board.id && (entry.platform==='全部平台'||entry.platform===platform||entry.platform==='京东/天猫'&&['京东','天猫'].includes(platform))));
function defaultEntries(){const rows=[];for(const b of BOARDS){for(const [index,e] of b.exercises.entries()){rows.push({id:`seed-${b.id}-${index}`,boardId:b.id,category:b.category,scope:'board',platform:'全部平台',question:e.question,answer:'',keyPoints:e.semantic_points||[],source:'16板块研究底稿 · 教学示例（不作为正式标准答案）',status:'published',kind:'seed',reviewStatus:'教学示例 · 缺少经核准的标准答案',createdAt:nowIso()});}}return rows;}
const getEntries=()=>[...defaultEntries(),...localEntries];
const allPublishedFor=(board,platform)=>getEntries().filter(e=>matchEntry(e,board,platform));
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
function setTitle(t){ELEM('pageTitle').textContent=t;document.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));ELEM('sidebar').classList.remove('open');}
function updateMode(){const online=!!cloud.base&&!!cloud.token;ELEM('modeDot').classList.toggle('online',online);ELEM('modeText').textContent=online?'已连接云端（需查询同步）':memoryFallback?'本机内存临时预览（受浏览器限制未持久化）':'本机独立预览 · 未云同步';}
async function remote(path,method='GET',body){if(!cloud.base)throw new Error('尚未配置云端 API');const res=await fetch(cloud.base+path,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(cloud.token?{'Authorization':'Bearer '+cloud.token}:{})},...(body?{body:JSON.stringify(body)}:{})});let j;try{j=await res.json()}catch{throw new Error(`服务器返回非JSON（HTTP ${res.status}）`)}if(!res.ok)throw new Error(j.error||`请求失败：${res.status}`);return j;}
function nav(to){deviceCheckSeq++;stopScene();exitFocus();if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}roomPhase='check';deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};page=to;render();window.scrollTo({top:0,behavior:'instant'});}
function home(){setTitle('品类专项训练');const total=localEntries.filter(x=>x.status==='published').length;ELEM('view').innerHTML=`
<section class="hero"><div><span class="eyebrow">NEW STREAMER PRACTICE STUDIO</span><h2>从真实弹幕出发，练出你的直播应答能力</h2><p>按品类与平台进入专项训练；运营上传顾客真实提问及优秀回答，审核后进入知识库。直播间只保留竖屏画面和模拟用户弹幕，摄像头可选，训练结果单独保存。</p></div><button class="btn primary" id="startFirst">开始专项训练 →</button></section>
<section class="stats"><div class="stat"><span>专项训练板块</span><b>16</b><small>结构固定 · 无真人姓名</small></div><div class="stat"><span>基础训练场景</span><b>48</b><small>教学提纲，不冒充正式答案</small></div><div class="stat"><span>已审核新增问答（本机）</span><b>${total}</b><small>开启云端后需单独同步</small></div><div class="stat"><span>历史拓展话术卡</span><b>65</b><small>保留原文 · 未获合规审核</small></div></section>
<section class="section-title"><div><h2>选择训练品类与平台</h2><p>16 个板块全部开放，不限定完成顺序。雷鸟显示器为单独入口，内部切换三个平台。</p></div></section>
<div class="board-grid">${BOARDS.map(b=>`<button class="board-card" data-open-board="${b.id}"><span class="count">NO. ${b.id}</span><span class="mini-icon">${iconFor(b.category)}</span><strong>${ESC(b.category)}</strong><small>${ESC(b.display_platform)}</small><span class="enter">进入训练 →</span></button>`).join('')}</div>
<section class="section-title"><h2>进阶拓展中心</h2></section><div class="panel"><strong>原 12 周养成 · 65 张历史话术卡</strong><p class="muted">与专项训练并列开放，保留原始卡片和学习结构。涉及价格、政策、赠品、时限及产品参数的历史内容未审核，不作为直接直播或正式自动评分答案。</p><button class="btn dark" id="toLegacy">进入拓展学习</button></div>
<p class="footer-note">当前为独立测试站。原站没有改动；模拟弹幕仅来自训练资料，不与任何真实直播间、账号或互动数据连接。</p>`;
ELEM('startFirst').onclick=()=>openBoard('01');ELEM('toLegacy').onclick=()=>nav('legacy');document.querySelectorAll('[data-open-board]').forEach(b=>b.onclick=()=>openBoard(b.dataset.openBoard));}
function openBoard(id){if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}selectedBoard=id;activePlatform=boardById(id).platforms[0];roomPhase='check';deviceCheckSeq++;deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};page='training';render();}
function trainingHome(){
const b=boardById(selectedBoard);
setTitle(`${b.category} · 开播准备`);
ELEM('view').innerHTML=`
<div class="intro-block slim-intro"><button class="ghost-btn" id="backBoard">← 返回16个板块</button><h2>${ESC(b.category)} · 直播训练</h2><p class="muted">先检查设备，进入开播准备，再点击「开始直播」切换到真正的竖屏模拟直播间。不连接抖音，不会推流。</p></div>
<div class="toolbar"><div class="segmented" id="platforms">${platformOptions(b).map(p=>`<button data-p="${ESC(p)}" class="${p===activePlatform?'selected':''}">${ESC(p)}</button>`).join('')}</div></div>
<div class="live-layout danmu-layout room-flow">
  <div class="live-phone danmu-phone" id="livePhone" aria-label="竖屏模拟直播间">
    <div class="live-bg"></div><video class="live-video" muted autoplay playsinline webkit-playsinline id="liveCam"></video>
    <div class="room-placeholder" id="roomPlaceholder"><div class="room-icon">◎</div><strong>主播画面预览</strong><p>设备检测后显示摄像头画面<br>仅模拟练播，不会真实开播</p></div>
    <div class="live-head"><div class="live-profile"><span class="live-avatar">T</span><span><strong>模拟训练直播间</strong><small>${ESC(b.category)} · ${ESC(activePlatform)}</small></span></div><span class="live-badge" id="liveStatus">● 开播前</span><span class="viewer" id="viewer">模拟观众 · 0</span></div>
    <span class="room-live-mark">训练模拟 · 非真实开播</span>
    <div class="barrage" id="barrage" role="log" aria-live="polite" aria-label="模拟观众弹幕"><div class="chat-line system"><strong>训练提示</strong><span>完成设备检查，再开始直播。</span></div></div>
    <div class="live-foot"><div class="chat-ghost">说点什么… <span>模拟弹幕</span></div><span class="danmu-bubble" aria-hidden="true">•••</span></div>
    <div class="pre-live-actions" id="preLiveActions"><span class="pre-live-label">开播准备 · 画面仅自己可见</span><div class="pre-live-heading">准备好开始今天的练播了吗？</div><p>点击开始直播后将立即切换到沉浸式直播画面，模拟顾客弹幕才会出现。</p><button class="btn primary pre-start-btn" id="startScene">开始直播</button><button class="pre-back-btn" id="preBack">← 返回设备检查</button></div>
    <button class="focus-close" id="focusClose" type="button">结束直播</button><button class="focus-next" id="focusNext" type="button">下一条弹幕 ›</button><button class="focus-review" id="focusReview" type="button">回答与复盘</button><button class="focus-mic" id="focusMic" type="button">● 开始录音</button>
  </div>
  <div class="trainer danmu-trainer" id="trainingControls">
    <div class="panel compact-panel check-panel"><div class="train-headline"><h2>① 开播前设备检查</h2><span class="pill">${ESC(b.id)} / 16</span></div>
      <div class="progress-row"><span>直播平台 <b>${ESC(activePlatform)}</b></span><span>可练弹幕 <b id="questionCount">—</b></span></div>
      <div class="device-grid"><div id="cameraState" class="device-state">摄像头：未检查</div><div id="micState" class="device-state">麦克风：未检查</div><div id="recorderState" class="device-state">录音支持：未检查</div><div id="networkState" class="device-state">运行环境：未检查</div></div>
      <div id="checkSummary" class="scene-tip">点击检查后才申请设备权限。失败时停留在当前页面并显示原因。</div>
      <div class="toolbar"><button class="btn primary" id="runDeviceCheck">检查全部设备</button><button class="btn" id="cameraBtn">手动开关摄像头</button></div>
      <div class="toolbar"><button class="btn primary" id="enterPrep" disabled>② 进入开播准备</button><button class="btn soft" id="textFallback">仅文字模拟练播</button></div>
      <p class="scene-tip">手机真实摄像头和麦克风通常需要 HTTPS 及用户授权；设备检测失败不会伪装成通过。仅文字模式会明确关闭录音功能。</p>
    </div>
    <div class="panel compact-panel learning-panel"><div class="q-meta"><span class="pill" id="questionStage">弹幕问题</span><span class="pill" id="questionSource">教学示例</span></div>
      <div class="training-question" id="currentQuestion">开始模拟直播后，训练弹幕会出现在直播画面中。</div>
      <div class="toolbar"><button class="btn dark" id="nextQuestion">下一条弹幕 →</button><button class="btn soft" id="showReference">查看参考回答</button></div><div id="referenceBox" class="tintbox hidden"></div></div>
    <div class="panel compact-panel review-panel"><div class="train-headline"><h2>③ 回答与复盘</h2><button class="ghost-btn review-close" id="closeReview">返回直播画面 ×</button></div><p class="scene-tip">先口头回答；可录制并回听。暂未接入真实语音转文字模型，不会伪造转写结果。</p>
      <div class="toolbar"><button class="btn primary" id="recordBtn">开始录音</button><button class="btn" id="recordStopBtn" disabled>结束录音</button></div>
      <div id="recordStatus" class="scene-tip">尚未录音</div><div id="audioHolder"></div>
      <div class="field" style="margin-top:12px"><label>我的回答（可编辑）</label><textarea id="answerText" rows="4" placeholder="说完后记录答案，对照参考话术复盘。"></textarea></div>
      <div class="toolbar"><button class="btn primary" id="submitAnswer">保存本次练习</button></div><div id="scoreBox"></div></div>
  </div>
</div>`;
ELEM('backBoard').onclick=()=>nav('home');
document.querySelectorAll('#platforms button').forEach(el=>el.onclick=()=>{deviceCheckSeq++;stopScene();exitFocus();if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}activePlatform=el.dataset.p;deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};trainingHome()});
ELEM('runDeviceCheck').onclick=checkDevices;ELEM('enterPrep').onclick=showReadyRoom;ELEM('textFallback').onclick=enableTextOnly;
ELEM('startScene').onclick=startScene;ELEM('preBack').onclick=returnToCheck;ELEM('focusClose').onclick=finishScene;
ELEM('cameraBtn').onclick=toggleCamera;ELEM('recordBtn').onclick=startRecord;ELEM('recordStopBtn').onclick=stopRecord;
ELEM('nextQuestion').onclick=nextQuestion;ELEM('focusNext').onclick=nextQuestion;ELEM('showReference').onclick=showReference;
ELEM('submitAnswer').onclick=submitAnswer;ELEM('focusReview').onclick=toggleLiveDrawer;ELEM('closeReview').onclick=toggleLiveDrawer;
ELEM('focusMic').onclick=()=>{if(deviceCheck.mode==='text')return toast('文字模式无法录音，请重新检查麦克风');if(currentRecorder?.state==='recording')stopRecord();else startRecord();};
ELEM('questionCount').textContent=String(allPublishedFor(b,activePlatform).length);
updateDeviceStates();
}
function setDeviceState(id,ok,text){const el=ELEM(id);if(!el)return;el.textContent=text;el.classList.remove('pass','fail');if(ok===true)el.classList.add('pass');if(ok===false)el.classList.add('fail')}
function updateDeviceStates(){
const d=deviceCheck;
setDeviceState('cameraState',!d.checked?null:d.camera,'摄像头：'+(!d.checked?'未检查':d.camera?'正常，画面已预览':'未就绪'));
setDeviceState('micState',!d.checked?null:d.microphone,'麦克风：'+(!d.checked?'未检查':d.microphone?'访问正常':'未就绪'));
setDeviceState('recorderState',!d.checked?null:d.recorder,'录音支持：'+(!d.checked?'未检查':d.recorder?'可用':'不支持'));
setDeviceState('networkState',!d.checked?null:!!window.isSecureContext,'环境：'+(!d.checked?'未检查':window.isSecureContext?'安全上下文（可申请权限）':'非安全上下文（需 HTTPS）')+(navigator.onLine?' · 网络可用':' · 当前离线'));
if(ELEM('enterPrep'))ELEM('enterPrep').disabled=!d.ready;
if(ELEM('checkSummary'))ELEM('checkSummary').textContent=d.mode==='text'?'文字模拟模式已启用：视频和录音均不会使用。':d.ready?'设备检查已通过。现在进入开播准备，确认画面后点击「开始直播」。':d.checked?'设备未全部通过。可修复后重试，或选择明确标识的「仅文字模拟练播」。'+(lastDeviceError?' 原因：'+lastDeviceError:''):'尚未检查。真实设备失败不会以演示结果代替。';
if(ELEM('recordBtn'))ELEM('recordBtn').disabled=d.mode==='text'||roomPhase!=='live';
}
async function checkDevices(){
if(roomPhase!=='check')return;
const seq=++deviceCheckSeq;lastDeviceError='';deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:true};
const btn=ELEM('runDeviceCheck');btn.disabled=true;btn.textContent='正在检测设备…';
const audioAvailable=!!(window.MediaRecorder&&navigator.mediaDevices?.getUserMedia);
deviceCheck.recorder=audioAvailable;
if(!navigator.mediaDevices?.getUserMedia){lastDeviceError='浏览器缺少媒体设备 API，需 HTTPS 或新版 Safari / Chrome';}
else{
 try{
  if(!camStream||camStream.getVideoTracks().every(t=>t.readyState!=='live')){
   const acquired=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:720},height:{ideal:1280}},audio:false});
   if(seq!==deviceCheckSeq){acquired.getTracks().forEach(t=>t.stop());return}
   if(camStream&&camStream!==acquired)camStream.getTracks().forEach(t=>{try{t.stop()}catch{}});
   camStream=acquired;bindCameraEnded(acquired);
  }
  const v=ELEM('liveCam');if(v){v.srcObject=camStream;v.style.display='block';v.play().catch(()=>{})}
  const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='none';
  deviceCheck.camera=camStream.getVideoTracks().some(t=>t.readyState==='live');
  ELEM('cameraBtn').textContent='关闭摄像头';
 }catch(e){lastDeviceError='摄像头：'+(e.message||e.name);deviceCheck.camera=false}
 try{
  const audio=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
  audio.getTracks().forEach(t=>t.stop());
  if(seq!==deviceCheckSeq)return;
  deviceCheck.microphone=true;
 }catch(e){lastDeviceError+=(lastDeviceError?'；':'')+'麦克风：'+(e.message||e.name);deviceCheck.microphone=false}
}
if(seq!==deviceCheckSeq)return;
deviceCheck.ready=!!(deviceCheck.camera&&deviceCheck.microphone&&deviceCheck.recorder&&window.isSecureContext);
if(!deviceCheck.ready&&camStream){camStream.getTracks().forEach(t=>{try{t.stop()}catch{}});camStream=null;const video=ELEM('liveCam');if(video){video.srcObject=null;video.style.display='none'}const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';deviceCheck.camera=false;ELEM('cameraBtn').textContent='打开摄像头';}
btn.disabled=false;btn.textContent='重新检查设备';updateDeviceStates();
if(deviceCheck.ready)toast('设备检查通过，可以进入开播准备');else toast('部分设备不可用，查看检查结果并重试');
}
function enableTextOnly(){if(roomPhase!=='check')return;deviceCheckSeq++;if(camStream){camStream.getTracks().forEach(t=>t.stop());camStream=null}const v=ELEM('liveCam');if(v){v.srcObject=null;v.style.display='none'}const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';deviceCheck={camera:false,microphone:false,recorder:false,ready:true,mode:'text',checked:true};updateDeviceStates();toast('已切换为仅文字模拟；录音、摄像头不可用');}
function showReadyRoom(){
if(!deviceCheck.ready)return toast('请先通过设备检查，或明确选择文字模拟模式');
if(deviceCheck.mode!=='text'&&(!camStream||!camStream.getVideoTracks().some(t=>t.readyState==='live'))){deviceCheck.ready=false;deviceCheck.camera=false;lastDeviceError='摄像头已断开，请重新检查';updateDeviceStates();return toast('摄像头已断开，请重新检查设备');}
if(!allPublishedFor(boardById(selectedBoard),activePlatform).length)return toast('本板块尚无训练问题，无法开始');
roomPhase='ready';ELEM('liveStatus').textContent='● 待开播';
const phone=ELEM('livePhone');phone.classList.add('is-preparing');document.body.classList.add('focus-open','room-preparing');
ELEM('preLiveActions').style.display='flex';
}
function returnToCheck(){roomPhase='check';ELEM('livePhone')?.classList.remove('is-preparing');document.body.classList.remove('room-preparing','focus-open');ELEM('preLiveActions').style.display='';}
function enterFocus(){const phone=ELEM('livePhone');if(!phone)return;phone.classList.remove('is-preparing');phone.classList.add('is-focused');document.body.classList.remove('room-preparing');document.body.classList.add('focus-open','room-live')}
function exitFocus(){const phone=ELEM('livePhone');if(phone)phone.classList.remove('is-focused','is-preparing');document.body.classList.remove('focus-open','room-live','room-preparing');ELEM('trainingControls')?.classList.remove('show-live-controls')}
function toggleLiveDrawer(){if(roomPhase!=='live')return;ELEM('trainingControls')?.classList.toggle('show-live-controls')}
function finishScene(){stopScene();exitFocus();roomPhase='check';if(deviceCheck.mode!=='text'){deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};lastDeviceError='';updateDeviceStates();}ELEM('liveStatus').textContent='● 已结束';toast('模拟直播已结束。再次开播前请重新检查设备。')}
function addChat(name,text,type='chat'){const list=ELEM('barrage');if(!list)return;const item=document.createElement('div');item.className='chat-line '+(type==='system'?'system':'');const nameEl=document.createElement('strong');nameEl.textContent=name;const txt=document.createElement('span');txt.textContent=text;item.append(nameEl,txt);list.append(item);while(list.children.length>7)list.firstChild.remove();}
function startScene(){
if(roomPhase!=='ready')return toast('请完成设备检查，并从开播准备页点击开始直播');
if(deviceCheck.mode!=='text'&&(!camStream||!camStream.getVideoTracks().some(t=>t.readyState==='live'))){returnToCheck();deviceCheck.ready=false;deviceCheck.camera=false;lastDeviceError='摄像头预览已中断';updateDeviceStates();return toast('摄像头已中断，请重新检查设备');}
const b=boardById(selectedBoard);questions=allPublishedFor(b,activePlatform);if(!questions.length)return toast('本板块暂无可用问题');
stopScene({preserveCamera:true});liveStarted=true;roomPhase='live';activeQuestionIndex=-1;
ELEM('liveStatus').textContent='● 模拟直播中';ELEM('preLiveActions').style.display='none';ELEM('viewer').textContent='模拟观众 · 126';
enterFocus();addChat('训练系统','模拟直播已开始。弹幕来源：专项训练问答库。','system');nextQuestion();
chatTimer=setInterval(()=>{if(!liveStarted||document.hidden)return;const q=questions[Math.floor(Math.random()*questions.length)];addChat('模拟观众'+(Math.floor(Math.random()*8)+1),q.question);ELEM('viewer').textContent='模拟观众 · '+(120+Math.floor(Math.random()*110));},11000);
}
function nextQuestion(){if(recorderPending)return toast('正在等待麦克风授权，请稍后再切换弹幕');if(!liveStarted)return toast('请点击「开始直播」后再练习');if(currentRecorder?.state==='recording'||recorderFinalizing)return toast('请先结束本题录音，再切换弹幕');const b=boardById(selectedBoard);questions=allPublishedFor(b,activePlatform);if(!questions.length)return toast('没有可练问题');cancelSpeech();activeQuestionIndex=(activeQuestionIndex+1)%questions.length;const q=questions[activeQuestionIndex];ELEM('currentQuestion').textContent=q.question;ELEM('questionStage').textContent=`问题 ${activeQuestionIndex+1}/${questions.length}`;ELEM('questionSource').textContent=q.kind==='seed'?'教学示例':'已审核知识库';ELEM('referenceBox').classList.add('hidden');ELEM('referenceBox').innerHTML='';ELEM('answerText').value='';ELEM('scoreBox').innerHTML='';if(answerAudioURL){URL.revokeObjectURL(answerAudioURL);answerAudioURL=''}ELEM('audioHolder').replaceChildren();recordUI('尚未录制本题回答');addChat('模拟顾客',q.question);}
function showReference(){const q=questions[activeQuestionIndex];if(!q)return toast('请先开始训练');const box=ELEM('referenceBox');box.classList.toggle('hidden');box.innerHTML=`<b>参考回答：</b><p>${ESC(q.answer||'尚未录入经审核的参考回答，不能提供自动评分结论。')}</p><b>应覆盖的重点：</b><ul>${(q.keyPoints||[]).map(k=>`<li>${ESC(k)}</li>`).join('')}</ul><small>来源：${ESC(q.source||'知识库')}</small>`;}
function stopScene(opts={}){cancelSpeech();recorderPending=false;liveStarted=false;recorderSession++;recorderFailed=true;recorderFinalizing=false;if(activeRecTimer){clearTimeout(activeRecTimer);activeRecTimer=null;}clearInterval(chatTimer);chatTimer=null;if(currentRecorder&&currentRecorder.state==='recording'){try{currentRecorder.stop()}catch{}}releaseMicrophone();if(!opts.preserveCamera&&camStream){camStream.getTracks().forEach(t=>t.stop());camStream=null;}const video=ELEM('liveCam');if(video&&!opts.preserveCamera){video.srcObject=null;video.style.display='none';const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';}const badge=ELEM('liveStatus');if(badge)badge.textContent='● 模拟待机';const b=ELEM('recordBtn'),s=ELEM('recordStopBtn');if(b)b.disabled=deviceCheck.mode==='text'||roomPhase!=='live';if(s)s.disabled=true;const liveButton=ELEM('focusMic');if(liveButton)liveButton.textContent='● 开始录音';}
async function toggleCamera(){if(roomPhase!=='check'||cameraBusy)return;const seq=++deviceCheckSeq;if(camStream){camStream.getTracks().forEach(t=>t.stop());camStream=null;ELEM('liveCam').srcObject=null;ELEM('liveCam').style.display='none';ELEM('roomPlaceholder').style.display='block';ELEM('cameraBtn').textContent='打开摄像头';deviceCheck.camera=false;deviceCheck.ready=false;updateDeviceStates();return}if(!navigator.mediaDevices?.getUserMedia)return toast('此浏览器不支持摄像头或当前页面缺少 HTTPS');cameraBusy=true;try{const acquired=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'},audio:false});if(seq!==deviceCheckSeq||roomPhase!=='check'){acquired.getTracks().forEach(t=>t.stop());return}if(camStream&&camStream!==acquired)camStream.getTracks().forEach(t=>{try{t.stop()}catch{}});camStream=acquired;bindCameraEnded(acquired);const v=ELEM('liveCam');if(!v){camStream.getTracks().forEach(t=>t.stop());camStream=null;return}v.srcObject=camStream;v.style.display='block';v.play().catch(()=>{});ELEM('roomPlaceholder').style.display='none';ELEM('cameraBtn').textContent='关闭摄像头';deviceCheck.camera=true;deviceCheck.ready=!!(deviceCheck.microphone&&deviceCheck.recorder&&window.isSecureContext);updateDeviceStates()}catch(e){toast('摄像头无法启动：'+e.message)}finally{cameraBusy=false}}
let recorderFailed=false, recorderSession=0, recorderFinalizing=false, activeRecTimer=null, recorderPending=false;
let speechSession=0, speechRecognizer=null;
function cancelSpeech(){speechSession++;const old=speechRecognizer;speechRecognizer=null;if(old){try{old.abort()}catch{}}}
function bindCameraEnded(stream){for(const t of stream.getVideoTracks()){t.addEventListener?.('ended',()=>{if(camStream!==stream)return;if(roomPhase==='live'){finishScene();toast('摄像头已中断：练播安全结束。请重新检查设备后开播');}else if(roomPhase==='ready'||roomPhase==='check'){const wasReady=roomPhase==='ready';returnToCheck();camStream=null;const v=ELEM('liveCam');if(v){v.srcObject=null;v.style.display='none'}const ph=ELEM('roomPlaceholder');if(ph)ph.style.display='block';if(ELEM('cameraBtn'))ELEM('cameraBtn').textContent='打开摄像头';deviceCheck.camera=false;deviceCheck.ready=false;lastDeviceError='摄像头预览已中断';updateDeviceStates();if(wasReady)toast('摄像头已中断，已退回设备检查');}});}}
function releaseMicrophone(){if(micStream){micStream.getTracks().forEach(t=>{try{t.stop()}catch{}});micStream=null}}
function recordUI(status,recording=false){const a=ELEM('recordStatus'),b=ELEM('recordBtn'),c=ELEM('recordStopBtn'),d=ELEM('focusMic');if(a)a.textContent=status;if(b)b.disabled=recording||deviceCheck.mode==='text'||roomPhase!=='live';if(c)c.disabled=!recording;if(d){d.textContent=recording?'■ 结束录音':'● 开始录音';d.disabled=deviceCheck.mode==='text';}}
async function startRecord(){
 if(roomPhase!=='live'||!liveStarted)return toast('请先进入模拟直播间，再开始录音');
 if(!deviceCheck.ready||deviceCheck.mode==='text')return toast('文字模拟模式无法录音，或设备检测尚未完成');
 if(recorderPending)return toast('正在等待麦克风授权，请勿重复点击');
 if(recorderFinalizing)return toast('正在整理上一段录音，请稍后重试');
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)return toast('此浏览器或访问环境不支持录音；请在 HTTPS 页面使用 Safari/Chrome');
 if(currentRecorder?.state==='recording')return toast('录音进行中，请先结束');
 cancelSpeech();recorderPending=true;
 const session=++recorderSession;recorderFailed=false;recorderFinalizing=false;recChunks=[];
 let acquired=null, ownTimer=null;
 const clearOwnTimer=()=>{if(ownTimer!==null){clearTimeout(ownTimer);if(activeRecTimer===ownTimer)activeRecTimer=null;ownTimer=null;}};
 try{
  acquired=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
  if(session!==recorderSession||roomPhase!=='live'){acquired.getTracks().forEach(t=>t.stop());return}
  recorderPending=false;
  micStream=acquired;
  const releaseOwned=()=>{clearOwnTimer();acquired?.getTracks().forEach(t=>{try{t.stop()}catch{}});if(micStream===acquired)micStream=null};
  const mime=['audio/mp4','audio/webm;codecs=opus','audio/webm'].find(t=>MediaRecorder.isTypeSupported?.(t))||'';
  const recorder=new MediaRecorder(micStream,mime?{mimeType:mime}:{});currentRecorder=recorder;
  recorder.ondataavailable=e=>{if(session===recorderSession&&e.data?.size)recChunks.push(e.data)};
  recorder.onerror=()=>{releaseOwned();if(session!==recorderSession)return;recorderFailed=true;recorderFinalizing=false;currentRecorder=null;recChunks=[];recordUI('录音失败，麦克风已释放；可重试或直接文字练习');};
  recorder.onstop=()=>{
   releaseOwned();if(session!==recorderSession)return;recorderFinalizing=false;currentRecorder=null;
   if(recorderFailed){recordUI('录音出错，请重试。没有保存不完整音频');return}
   const chunks=recChunks.slice();recChunks=[];
   if(!chunks.length){recordUI('未录到有效音频，请检查麦克风权限');return}
   const blob=new Blob(chunks,{type:recorder.mimeType||mime||'audio/webm'});
   if(blob.size<200){recordUI('音频太短或无效，请重新录制');return}
   if(answerAudioURL)URL.revokeObjectURL(answerAudioURL);
   answerAudioURL=URL.createObjectURL(blob);
   const holder=ELEM('audioHolder');if(holder){const audio=document.createElement('audio');audio.controls=true;audio.className='audio-player';audio.src=answerAudioURL;holder.replaceChildren(audio)}
   recordUI(`录音完成（${(blob.size/1024).toFixed(1)} KB）。可回放，尚不能自动转文字。`);
  };
  const maxDurationMs=typeof window.__REC_MAX_MS==='number'?window.__REC_MAX_MS:120000;
  recorder.start(300);
  ownTimer=setTimeout(()=>{ownTimer=null;if(activeRecTimer)activeRecTimer=null;if(session===recorderSession&&recorder.state==='recording')stopRecord();},maxDurationMs);
  activeRecTimer=ownTimer;
  recordUI('● 正在录音（最长120秒），点击结束录音可回放',true);
 }catch(e){clearOwnTimer();if(acquired){acquired.getTracks().forEach(t=>{try{t.stop()}catch{}});if(micStream===acquired)micStream=null}if(session!==recorderSession)return;currentRecorder=null;recorderFinalizing=false;recordUI('无法启动录音：'+(e?.message||'未知错误'));toast('请检查浏览器麦克风权限及 HTTPS 连接')}
 finally{if(session===recorderSession)recorderPending=false;}
}
function stopRecord(){try{if(currentRecorder?.state==='recording'){recorderFinalizing=true;currentRecorder.stop();recordUI('正在整理录音，请稍候…',true)}}catch(e){recorderFinalizing=false;currentRecorder=null;recordUI('停止录音失败：'+e.message);releaseMicrophone()}}
function browserAsr(){
 if(page!=='training'||roomPhase!=='live'||!liveStarted||!questions[activeQuestionIndex])return toast('请先进入训练直播间');
 if(recorderPending||recorderFinalizing||currentRecorder?.state==='recording')return toast('请先结束录音或等待授权完成');
 const Klass=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!Klass)return toast('此浏览器不支持 Web Speech Recognition，无法保证免费或离线，请手动填写');
 cancelSpeech();
 const session=speechSession,board=selectedBoard,platform=activePlatform,question=questions[activeQuestionIndex],target=ELEM('answerText'),status=ELEM('recordStatus');
 if(!target||!status)return;
 const valid=()=>session===speechSession&&page==='training'&&roomPhase==='live'&&liveStarted&&selectedBoard===board&&activePlatform===platform&&questions[activeQuestionIndex]===question&&ELEM('answerText')===target&&ELEM('recordStatus')===status;
 try{
  const rec=new Klass();speechRecognizer=rec;
  rec.lang='zh-CN';rec.continuous=false;rec.interimResults=false;
  status.textContent='浏览器识别尝试中（可能调用系统在线服务，不保证离线或持续可用）';
  rec.onresult=e=>{if(!valid()||speechRecognizer!==rec)return;target.value=[...e.results].map(x=>x[0]?.transcript||'').join('');status.textContent='已将浏览器识别结果填入文本框，请核对';};
  rec.onerror=e=>{if(!valid()||speechRecognizer!==rec)return;status.textContent='浏览器识别失败：'+e.error+'。请手动输入。';cancelSpeech();};
  rec.onend=()=>{if(speechRecognizer===rec){speechRecognizer=null;speechSession++;}};
  rec.start();
 }catch(e){if(valid()){cancelSpeech();status.textContent='浏览器识别无法启动，请手动输入';toast('无法启动浏览器识别：'+e.message)}}
}
async function submitAnswer(){const q=questions[activeQuestionIndex];if(!q)return toast('请先开始训练');const text=ELEM('answerText').value.trim();if(text.length<5)return toast('请先说出并填写至少5个字的练习回答');const points=q.keyPoints||[],hit=points.filter(p=>{const w=norm(p).slice(0,5);return !!w&&norm(text).includes(w)});const rec={id:uid(),boardId:selectedBoard,category:boardById(selectedBoard).category,platform:activePlatform,question:q.question,answer:text,createdAt:nowIso(),result:'已练习（待人工/真实AI复核）',matchedKeywords:hit.length,keywordTotal:points.length};await dbPut('records',rec);localRecords.unshift(rec);ELEM('scoreBox').innerHTML=`<div class="notice green"><b>练习已保存（本机）</b><br>这是训练记录，不是正式AI评分。参考覆盖项仅供自检，不因为未匹配关键词就判定错误。<br>可对照参考回答修正表达，下次继续练习。</div>`;toast('本机训练记录已保存，可在“我的练习”查看');}
function library(){setTitle('问答知识库');const rows=getEntries().filter(e=>e.status==='published'&&(!librarySearch||norm(e.question+' '+e.answer+' '+e.category+' '+e.platform).includes(norm(librarySearch)))&&(selectedLibraryBoard==='all'||e.boardId===selectedLibraryBoard||e.scope==='category'&&e.category===boardById(selectedLibraryBoard).category));ELEM('view').innerHTML=`<div class="section-title"><div><h2>从优秀回答中学习</h2><p>查看已审核发布的问答。原有教学题目只有训练要点，不伪造成熟参考答案。</p></div></div><div class="panel"><div class="cols-2"><div class="field"><label>搜索问题、回答或知识点</label><input id="librarySearch" value="${ESC(librarySearch)}" placeholder="例如：安装、噪音、耗电、退换货"></div><div class="field"><label>筛选训练板块</label><select id="libraryBoard"><option value="all">全部板块</option>${BOARDS.map(b=>`<option value="${b.id}" ${b.id===selectedLibraryBoard?'selected':''}>${b.id} ${ESC(b.category)} · ${ESC(b.display_platform)}</option>`).join('')}</select></div></div><div class="notice blue">只有运营审核通过的资料才应进入正式学习库。当前本机演示数据不等于云端持久化；真正跨设备同步需要连接后端数据库。</div><div class="question-list" id="libraryList">${rows.slice(0,100).map(q=>`<div class="q-card"><div class="q-meta"><span class="pill">${ESC(q.category)}</span><span class="pill">${ESC(q.platform||'公共')}</span><span class="pill ${q.kind==='seed'?'warn':'good'}">${q.kind==='seed'?'教学示例':'已审核回答'}</span></div><h3>${ESC(q.question)}</h3><p>${ESC(q.answer||'暂无审核完成的参考答案，先思考自己会如何回答。')}</p><div class="q-meta">${(q.keyPoints||[]).map(k=>`<span class="pill">${ESC(k)}</span>`).join('')}</div></div>`).join('')}</div><p class="muted">显示 ${Math.min(rows.length,100)} / ${rows.length} 条</p></div>`;ELEM('librarySearch').oninput=e=>{librarySearch=e.target.value;library()};ELEM('libraryBoard').onchange=e=>{selectedLibraryBoard=e.target.value;library()};}
function progress(){setTitle('我的练习记录');ELEM('view').innerHTML=`<div class="section-title"><div><h2>成长档案（当前设备）</h2><p>练播回答可以反复查看；目前无真实 AI 评分，也没有跨设备成绩同步。</p></div><button class="btn" id="backupRecords">导出个人记录</button></div><div class="panel"><div class="question-list">${localRecords.slice(0,100).map(r=>`<div class="q-card"><div class="q-meta"><span>${ESC(new Date(r.createdAt).toLocaleString('zh-CN'))}</span><span>${ESC(r.category)}</span><span>${ESC(r.platform)}</span></div><h3>${ESC(r.question)}</h3><p>${ESC(r.answer)}</p><span class="pill warn">${ESC(r.result)}</span></div>`).join('')||'<div class="empty">还没有练习记录，进入专项训练并提交回答即可保存。</div>'}</div></div>`;ELEM('backupRecords').onclick=()=>downloadJSON('TCL-我的练习记录.json',localRecords);}
function legacy(){setTitle('原12周 · 进阶拓展');const mods=[...new Set(legacyCards.map(c=>c.module))];const rows=legacyCards.filter(c=>selectedLegacyFilter==='all'||c.module===selectedLegacyFilter);ELEM('view').innerHTML=`<div class="hero"><div><span class="eyebrow">LEGACY LEARNING · ARCHIVED</span><h2>原版 65 张话术卡 · 自由学习</h2><p>原 12 周养成体系完整保留，并与 16 个专项训练入口并列开放。历史卡片含未经核验的促销、价格、功能和服务承诺，仅供拆解表达方法，不作为真实直播标准答案。</p></div></div><div class="notice">历史话术只是学习材料。带有金额、时效、库存、服务范围等承诺的表达，必须在正式直播前验证商品及当期活动凭证。</div><div class="toolbar"><div class="segmented"><button data-legacy="all" class="${selectedLegacyFilter==='all'?'selected':''}">全部65张</button>${mods.map(m=>`<button data-legacy="${ESC(m)}" class="${m===selectedLegacyFilter?'selected':''}">${ESC(m)}</button>`).join('')}</div></div><div class="legacy-grid">${rows.map(c=>`<div class="legacy-card"><div class="q-meta"><span class="pill">${ESC(c.card_id)}</span><span class="pill">${ESC(c.module)}</span>${c.risk_labels.length?'<span class="pill warn">需核验</span>':'<span class="pill">结构参考</span>'}</div><p><b>${ESC(c.safe_teaching_objective)}</b> · ${ESC(c.group)}</p><p>历史原文：${ESC(c.original_text)}</p><div class="q-meta">${c.risk_labels.map(s=>`<span class="pill warn">${ESC(s)}</span>`).join('')}</div></div>`).join('')}</div>`;document.querySelectorAll('[data-legacy]').forEach(x=>x.onclick=()=>{selectedLegacyFilter=x.dataset.legacy;legacy()});}
function importPage(){setTitle('运营 · 导入问答文件');const b=boardById(importBoardId);ELEM('view').innerHTML=`<div class="section-title"><div><h2>运营上传 · 弹幕问答知识整理</h2><p>将老主播/运营已解答的用户问题导入，逐条审核后进入正式题库。</p></div><button class="btn" id="downloadTemplate">下载 CSV 模板</button></div>
<div class="notice">本地演示页没有真实运营身份认证，不应上传客户个人信息、订单号、手机号或敏感内部资料。正式多人数据库必须先连接受保护的云端 API。</div>
<div class="panel"><div class="cols-3"><div class="field"><label>选择目标训练板块</label><select id="importBoard">${BOARDS.map(b=>`<option value="${b.id}" ${b.id===importBoardId?'selected':''}>${b.id} ${ESC(b.category)} · ${ESC(b.display_platform)}</option>`).join('')}</select></div><div class="field"><label>知识类型</label><select id="importScope"><option value="platform" ${importScope==='platform'?'selected':''}>平台专项问答</option><option value="category" ${importScope==='category'?'selected':''}>本品类共享知识</option></select></div><div class="field"><label>平台分类</label><select id="importPlatform">${b.platforms.map(p=>`<option value="${ESC(p)}" ${p===importPlatform?'selected':''}>${ESC(p)}</option>`).join('')}<option value="全部平台" ${importPlatform==='全部平台'?'selected':''}>全部平台（适用时）</option></select></div></div>
<div class="upload-drop" style="margin-top:20px"><div style="font-size:28px">⇧</div><strong>上传问答文件</strong><p>支持 DOCX / XLSX / XLS / 文本 PDF / CSV / TSV / TXT / JSON（全部在本地浏览器解析）。扫描版 PDF 暂不支持 OCR。</p><input type="file" id="fileInput" accept=".docx,.xlsx,.xls,.pdf,.csv,.tsv,.txt,.json" /></div>
<div class="toolbar"><button class="btn primary" id="parseFile">解析文件并预览</button><button class="btn dark" id="saveImport" disabled>保存为待审核资料</button></div>
<div id="importSummary" class="muted">尚未选择文件。推荐列名：问题、优秀回答、评分点；必须附带可核实的来源。</div><div class="table-wrap" id="importTable"></div></div>`;
ELEM('importBoard').onchange=e=>{importBoardId=e.target.value;importPlatform=boardById(importBoardId).platforms[0];importPage()};ELEM('importScope').onchange=e=>importScope=e.target.value;ELEM('importPlatform').onchange=e=>importPlatform=e.target.value;
ELEM('downloadTemplate').onclick=()=>{const sample='问题,优秀回答,评分点\n空调安装前需要核对哪些条件？,"先确认空间、安装条件及具体服务范围，再以商品页和当地服务说明为准。","安装环境；服务范围；不夸大承诺"\n';downloadText('TCL-问答导入模板.csv','\ufeff'+sample,'text/csv;charset=utf-8')};ELEM('parseFile').onclick=parseImport;ELEM('saveImport').onclick=saveImport;}
async function parseImport(){const file=ELEM('fileInput').files[0];if(!file)return toast('请先选择问答文件');if(file.size>15*1024*1024)return toast('文件超过15 MB，请拆分后上传');ELEM('importSummary').textContent='正在本地解析：'+file.name;try{const parsed=await parseDocumentFile(file);importCandidate=extractQA(parsed).slice(0,500);uploadedFileName=file.name;if(!importCandidate.length)throw new Error('未识别到完整问答结构。请使用“问题/优秀回答/评分点”列名或“问：… 答：…”格式。');detectReviewConflicts(importCandidate,{existing:localEntries,boardId:importBoardId,platform:importPlatform});for(const row of importCandidate){if(containsPII(row.question+' '+row.answer))row.reviewStatus='sensitive';}const counts={ready:importCandidate.filter(x=>x.reviewStatus==='needs_review').length,missing:importCandidate.filter(x=>x.reviewStatus==='incomplete').length,dup:importCandidate.filter(x=>x.reviewStatus==='duplicate').length,conflict:importCandidate.filter(x=>x.reviewStatus==='conflict').length,pii:importCandidate.filter(x=>x.reviewStatus==='sensitive').length};ELEM('importSummary').textContent=`文件：${file.name}；识别 ${importCandidate.length} 条。待审核 ${counts.ready}，缺答案 ${counts.missing}，重复 ${counts.dup}，冲突 ${counts.conflict}，疑似隐私 ${counts.pii}（此类禁止保存）。`;
 ELEM('importTable').innerHTML=`<table><thead><tr><th>状态</th><th>提问内容</th><th>运营/老主播参考回答</th><th>来源</th></tr></thead><tbody>${importCandidate.slice(0,100).map((r,i)=>`<tr><td><span class="pill ${r.reviewStatus==='needs_review'?'warn':'danger'}">${r.reviewStatus==='needs_review'?'待审核':r.reviewStatus==='incomplete'?'缺少答案':r.reviewStatus==='duplicate'?'重复':r.reviewStatus==='sensitive'?'隐私风险':'答案冲突'}</span></td><td>${ESC(r.question)}</td><td>${ESC(r.answer||'—')}</td><td>${ESC(r.locator||'')} </td></tr>`).join('')}</tbody></table>`;
 ELEM('saveImport').disabled=false;toast('文件解析完成，请核对后保存待审');}catch(e){importCandidate=[];ELEM('saveImport').disabled=true;ELEM('importSummary').textContent='解析失败：'+e.message;toast('解析失败：'+e.message)}}
async function archiveSource(file){
if(!cloud.base||!cloud.token)throw new Error('请先连接运营云数据库');
if(!file||file.size===0||file.size>8*1024*1024)throw new Error('云端归档文件必须为1B至8MB，请拆分后重试');
const r=await fetch(cloud.base+'/api/source-upload',{method:'POST',headers:{'Authorization':'Bearer '+cloud.token,'Content-Type':'application/octet-stream','X-File-Name':encodeURIComponent(file.name),'X-Board-Id':importBoardId,'X-Platform':encodeURIComponent(importScope==='category'?'全部平台':importPlatform)},body:file});
const j=await r.json().catch(()=>({error:'原件归档接口返回非JSON'}));if(!r.ok)throw new Error(j.error||'原件归档失败 '+r.status);return j;
}
async function saveImport(){if(!importCandidate.length)return;const unsafe=importCandidate.filter(r=>r.reviewStatus==='sensitive');if(unsafe.length)return toast(`有 ${unsafe.length} 条内容包含疑似手机号/邮箱/订单号码。请先在源文件脱敏后重新上传`);const imported=importCandidate.map(r=>({id:uid(),boardId:importBoardId,category:boardById(importBoardId).category,scope:importScope==='category'?'category':'board',platform:importScope==='category'?'全部平台':importPlatform,question:r.question,answer:r.answer,keyPoints:r.keyPoints,source:'匿名导入资料 · '+String(r.locator||'').replace(uploadedFileName,'源文件'),reviewStatus:r.reviewStatus,status:'draft',kind:'uploaded',createdAt:nowIso()}));let saved=0;
try{if(cloud.base&&cloud.token){const f=ELEM('fileInput')?.files?.[0];const archived=await archiveSource(f);for(const it of imported)it.sourceFileId=archived.id;for(let i=0;i<imported.length;i+=20){const part=imported.slice(i,i+20);const resp=await remote('/api/import','POST',{items:part});saved+=resp.saved||0;if(resp.rejected?.length)throw new Error('云端拒绝了 '+resp.rejected.length+' 条，原件已归档，请到后台核对');}toast(`已保存原始文件及${saved}条云端待审问答`)}else{for(const x of imported){await dbPut('items',x);localEntries.push(x);saved++}toast(`本机保存${saved}条待审核资料。注意：没有云端同步。`)}importCandidate=[];nav('review');}catch(e){toast('保存中断：'+e.message+'；已保存 '+saved+' 条，请检查防止重复上传')}}
function reviewPage(){setTitle('审核 · 知识库发布');const pending=localEntries.filter(x=>x.status==='draft');ELEM('view').innerHTML=`<div class="section-title"><div><h2>运营上传审核</h2><p>先核对商品知识与答案来源，再由管理员发布。重复、冲突、缺答案不得自动发布。</p></div><button id="pullCloud" class="btn">刷新云端待审</button></div><div class="notice">当前界面的本机“审核通过”仅供演示流程。正式生产发布需使用云端管理员认证与操作审计，不能把客户端按钮当作权限控制。</div><div class="panel"><div class="question-list">${pending.slice(-150).reverse().map(x=>`<div class="q-card"><div class="q-meta"><span class="pill">${ESC(x.category)} / ${ESC(x.platform)}</span><span class="pill ${x.reviewStatus==='needs_review'?'warn':'danger'}">${ESC(x.reviewStatus)}</span><span class="pill">待审核</span></div><h3>${ESC(x.question)}</h3><p>${ESC(x.answer||'缺少答案')}</p><p class="muted">${ESC(x.source)}</p><div class="toolbar"><button class="btn small primary" data-approve="${x.id}" ${x.reviewStatus!=='needs_review'||!x.answer?'disabled':''}>本机模拟发布</button><button class="btn small" data-discard="${x.id}">拒绝/删除本机草稿</button></div></div>`).join('')||'<div class="empty">没有本机待审核问答。云端待审与本机数据是隔离的。</div>'}</div></div><div id="cloudPending"></div>`;
 ELEM('pullCloud').onclick=pullCloud;document.querySelectorAll('[data-approve]').forEach(b=>b.onclick=async()=>{const x=localEntries.find(z=>z.id===b.dataset.approve);if(!x)return;x.status='published';x.reviewStatus='reviewed-demo';x.publishedAt=nowIso();await dbPut('items',x);toast('仅本机模拟审核通过，未同步云端');reviewPage()});document.querySelectorAll('[data-discard]').forEach(b=>b.onclick=async()=>{await dbDelete('items',b.dataset.discard);localEntries=localEntries.filter(x=>x.id!==b.dataset.discard);reviewPage()});}
async function pullCloud(){if(!cloud.base||!cloud.token)return toast('需要先在云端配置中登录管理员');try{const resp=await remote('/api/pending');const rows=resp.items||[];ELEM('cloudPending').innerHTML=`<div class="panel" style="margin-top:20px"><h2>云端待审核 · ${rows.length} 条</h2><div class="question-list">${rows.map(x=>`<div class="q-card"><div class="q-meta"><span class="pill">${ESC(x.category)}</span><span class="pill">${ESC(x.platform)}</span><span class="pill warn">${ESC(x.review_status)}</span></div><h3>${ESC(x.question)}</h3><p>${ESC(x.answer||'缺少答案')}</p><p class="muted">${ESC(x.source)}</p><button class="btn small primary" data-cloud-approve="${x.id}" ${cloud.role!=='admin'||x.review_status!=='needs_review'||!x.answer?'disabled':''}>管理员审核发布</button><button class="btn small" data-cloud-edit="${x.id}" ${cloud.role!=='admin'?'disabled':''}>编辑问答</button><button class="btn small" data-cloud-reject="${x.id}" ${cloud.role!=='admin'?'disabled':''}>拒绝</button></div>`).join('')||'<div class="empty">暂无待审</div>'}</div></div>`;document.querySelectorAll('[data-cloud-approve]').forEach(b=>b.onclick=()=>cloudApprove(b.dataset.cloudApprove,'publish'));document.querySelectorAll('[data-cloud-reject]').forEach(b=>b.onclick=()=>cloudApprove(b.dataset.cloudReject,'reject'));document.querySelectorAll('[data-cloud-edit]').forEach(b=>b.onclick=async()=>{const x=rows.find(z=>z.id===b.dataset.cloudEdit);if(!x)return;const question=window.prompt('审核编辑：用户提问',x.question);if(question===null)return;const answer=window.prompt('审核编辑：成熟回答',x.answer||'');if(answer===null)return;try{await remote('/api/revise','POST',{id:x.id,question,answer});toast('修改已保存，需再次审核发布');pullCloud()}catch(e){toast('编辑失败：'+e.message)}});}catch(e){toast('读取云端待审失败：'+e.message)}}
async function cloudApprove(id,decision){try{await remote('/api/review','POST',{ids:[id],decision});toast('云端审核已提交');pullCloud()}catch(e){toast('审核失败：'+e.message)}}
function settingsPage(){setTitle('云端数据库与权限');ELEM('view').innerHTML=`<div class="section-title"><div><h2>数据库连接</h2><p>GitHub Pages 只托管页面。要让运营资料被所有新人长期查看，必须配置独立的受保护云端数据库。</p></div></div><div class="two-col"><div class="panel"><h2>Cloudflare Workers + D1（部署适配已附）</h2><div class="notice blue">免费额度适合小规模培训测试，但不是无限容量/永远不会停服的承诺；中国大陆访问速度及可达性必须通过真机验证。已有 CloudBase 也可作为后续正式后端迁移目标。</div><div class="field"><label>API 地址（必须 HTTPS）</label><input id="apiBase" placeholder="https://你的worker.workers.dev" value="${ESC(cloud.base)}"></div><div class="cols-2" style="margin:12px 0"><div class="field"><label>运营账号</label><input id="loginName" autocomplete="username" value="${ESC(cloud.name||'')}"></div><div class="field"><label>密码（只在登录时发送，前端不持久化）</label><input id="loginPassword" type="password" autocomplete="current-password"></div></div><div class="toolbar"><button class="btn primary" id="cloudLogin">连接并登录</button><button class="btn" id="cloudLogout">断开云端连接</button><button class="btn" id="cloudSync">同步已发布知识</button></div><p class="muted" id="cloudFeedback">当前：${cloud.token?'已登录 '+ESC(cloud.name)+' / '+ESC(cloud.role):'未登录，本机数据库模式'}。</p></div><div class="panel"><h2>运营账号管理</h2><p class="muted">只有超级管理员可以创建运营账号。运营账户负责提交资料，不可直接发布；创建后请通过安全渠道单独告知运营人员初始密码。</p>${cloud.role==='admin'?'<div class="field"><label>新运营登录名</label><input id="newOperator" placeholder="例如 ops001"></div><div class="field" style="margin-top:10px"><label>初始密码（至少12位）</label><input id="newOperatorPassword" type="password" autocomplete="new-password" placeholder="请输入安全密码"></div><div class="toolbar"><button class="btn" id="createOperatorBtn">创建运营账号</button></div>':'<div class="notice">需要超级管理员登录后才可管理运营账号。</div>'}</div><div class="panel"><h2>原始文件安全归档</h2><p class="muted">云端启用后，运营上传的原始文件存放在私有 R2，问答记录及文件哈希存放在 D1。仅超级管理员可读取并下载原始文件；无云端连接时按钮不可用。</p><div class="toolbar"><button class="btn" id="listSourcesBtn">查看云端原始文件</button></div><div class="question-list" id="sourceArchiveList"></div></div><div class="panel"><h2>运营入库安全原则</h2><ol class="note-list"><li>上传文件只在本地解析成问答行；服务器通过私有 R2 归档原始文件，通过 D1 保存问答、审核记录及文件哈希；运营必须先删除客户隐私信息。</li><li>老主播回答可作为候选内容；导入者只能提交待审，不可绕过管理员直接发布。</li><li>同一品类共用知识；各平台按当前板块过滤问题和优秀回答。</li><li>新主播只能读取已发布内容；原 65 张历史卡处于拓展学习区，默认不作为正式评分标准。</li><li>云端要独立管理账号、审计、容量告警及定期备份，不能依赖浏览器缓存做永久数据库。</li></ol></div></div>`;
 ELEM('cloudLogin').onclick=loginCloud;ELEM('cloudLogout').onclick=async()=>{if(cloud.token){try{await remote('/api/logout','POST',{})}catch{}}cloud.token='';cloud.role='';cloud.name='';updateMode();toast('已退出云端登录');settingsPage()};ELEM('cloudSync').onclick=syncCloud;ELEM('listSourcesBtn').onclick=loadSources;if(ELEM('createOperatorBtn'))ELEM('createOperatorBtn').onclick=createCloudOperator;}
async function createCloudOperator(){if(cloud.role!=='admin')return toast('需要超级管理员权限');const username=ELEM('newOperator').value.trim(),password=ELEM('newOperatorPassword').value;if(!username||password.length<12)return toast('账号必填，初始密码至少12位');try{await remote('/api/operators','POST',{username,password});ELEM('newOperatorPassword').value='';toast('运营账号已创建，请安全交付登录信息')}catch(e){toast('创建失败：'+e.message)}}
async function loadSources(){if(!cloud.base||!cloud.token||cloud.role!=='admin')return toast('仅云端超级管理员可查看和下载原始文件');try{const res=await remote('/api/sources');const items=res.items||[];const target=ELEM('sourceArchiveList');target.innerHTML=items.length?items.map(x=>`<div class="q-card"><strong>${ESC(x.file_name)}</strong> <span class="pill">${ESC(x.board_id)} / ${ESC(x.platform)}</span><p class="muted">${(x.size_bytes/1024).toFixed(1)}KB · SHA-256 ${ESC(x.sha256.slice(0,12))}… · ${ESC(x.created_at)}</p><button class="btn small" data-archive-download="${ESC(x.id)}">下载原始文件</button></div>`).join(''):'<div class="empty">云端暂无归档文件</div>';target.querySelectorAll('[data-archive-download]').forEach(b=>b.onclick=()=>downloadSource(items.find(x=>x.id===b.dataset.archiveDownload)));}catch(e){toast('查询云端归档失败：'+e.message)}}
async function downloadSource(item){if(!item||cloud.role!=='admin')return;try{const res=await fetch(cloud.base+'/api/source/'+encodeURIComponent(item.id),{headers:{Authorization:'Bearer '+cloud.token}});if(!res.ok){const j=await res.json().catch(()=>({}));throw new Error(j.error||res.status)}const blob=await res.blob();const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=item.file_name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)}catch(e){toast('下载归档失败：'+e.message)}}
async function loginCloud(){const base=ELEM('apiBase').value.trim().replace(/\/$/,'');const name=ELEM('loginName').value.trim(),password=ELEM('loginPassword').value;if(!/^https:\/\//.test(base))return toast('API 地址必须使用 HTTPS');if(!name||!password)return toast('请输入运营账号和密码');cloud.base=base;try{const res=await remote('/api/login','POST',{username:name,password});cloud.token=res.token;cloud.role=res.role;cloud.name=name;updateMode();toast('云端登录成功：'+res.role);settingsPage();await syncCloud();}catch(e){cloud.token='';toast('云端登录失败：'+e.message)}}
async function syncCloud(){try{if(!cloud.base)throw new Error('请先填写 API 地址');const result=await remote('/api/questions?limit=500');let added=0;for(const e of result.items||[]){const obj={id:'cloud-'+e.id,boardId:e.board_id,category:e.category,platform:e.platform,scope:e.scope,question:e.question,answer:e.answer,keyPoints:JSON.parse(e.key_points||'[]'),source:e.source,status:'published',reviewStatus:'approved',kind:'cloud',createdAt:e.created_at};const current=localEntries.find(x=>x.id===obj.id);if(!current){localEntries.push(obj);added++}else Object.assign(current,obj);await dbPut('items',obj)}toast(`同步完成：${added}条新增，${result.items?.length||0}条云端数据已更新`);}catch(e){toast('同步失败：'+e.message)}}
function downloadText(name,text,type='application/json'){const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.download=name;a.href=url;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)}
const downloadJSON=(name,obj)=>downloadText(name,JSON.stringify(obj,null,2),'application/json;charset=utf-8');
async function init(){try{const cfg=await fetch('./app-config.json').then(r=>r.ok?r.json():{});if(cfg.apiBase&&/^https:\/\//.test(cfg.apiBase))cloud.base=cfg.apiBase.replace(/\/$/,'')}catch{} try{localDB=await dbOpen();localEntries=await dbAll('items');localRecords=(await dbAll('records')).sort((a,b)=>(b.createdAt||'').localeCompare(a.createdAt||''))}catch(e){memoryFallback=true;localEntries=[];localRecords=[];}ELEM('menuBtn').onclick=()=>ELEM('sidebar').classList.toggle('open');document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>nav(b.dataset.page));ELEM('backupBtn').onclick=()=>downloadJSON('TCL-练播房本机备份.json',{exportedAt:nowIso(),items:localEntries,records:localRecords,note:'本机备份，不包含上传文件本体，不代替云数据库备份'});updateMode();render();if(cloud.base){syncCloud().catch(()=>{});}}
function render(){if(page==='home')home();else if(page==='training')trainingHome();else if(page==='library')library();else if(page==='legacy')legacy();else if(page==='progress')progress();else if(page==='import')importPage();else if(page==='review')reviewPage();else if(page==='settings')settingsPage();}
window.addEventListener('pagehide',()=>{deviceCheckSeq++;stopScene();exitFocus();roomPhase='check';deviceCheck={camera:false,microphone:false,recorder:false,ready:false,mode:'hardware',checked:false};updateDeviceStates()});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')cancelSpeech();if(document.visibilityState==='visible'&&roomPhase==='live'&&deviceCheck.mode!=='text'&&(!camStream||camStream.getVideoTracks().every(t=>t.readyState!=='live'))){finishScene();toast('摄像头已中断：练播安全结束。请重新检查设备后开播');}});
init();
