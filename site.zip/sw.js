// Service Worker for TCL Streamer V4.3 (TASK004 Section 3.6 & Section 4).
// - Caches lightweight HTML/CSS/JS shell ONLY (`tcl-v43-preview-shell-v4.3.14-pages-r6.1`).
// - NEVER bundles 80MB+ WASM/ONNX models into the Service Worker `install` event!
// - Preserves `tcl-v43-preview-model-*` caches and IndexedDB data across shell upgrades.

const CACHE = 'tcl-v43-preview-shell-v4.3.14-pages-r6.1';
const FILES = [
  './',
  './index.html',
  
  
  './style.css',
  './app.js',
  './core.js',
  './storage.js',
  './media.js',
  './recording.js',
  './training.js',
  './knowledge.js',
  './actions.js',
  './app-cache.js',
  './audio-input.js',
  './feedback.js',
  './file-save.js',
  './manifest.webmanifest',
  './icon.svg',
  './src/app/app.js',
  './src/app/r5-safety.js',
  './src/app/actions.js',
  './src/app/app-cache.js',
  './src/app/feedback.js',
  './src/app/operators.js',
  './src/files/zip.js',
  './src/files/xls.js',
  './src/files/pdf.js',
  './src/files/parser.js',
  './src/files/question-set.js',
  './src/training/core.js',
  './src/training/state-machine.js',
  './src/training/training.js',
  './src/media/audio-input.js',
  './src/media/recording.js',
  './src/media/file-save.js',
  './src/media/barrage-overlay.js',
  './src/media/media.js',
  './src/speech/speech.js',
  './src/speech/local-asr/audio-preprocess.js',
  './src/speech/local-asr/model-manifest.js',
  './src/speech/local-asr/asr-results.js',
  './src/assessment/schema.js',
  './src/assessment/scorer-client.js',
  './src/storage/storage.js'
];

self.addEventListener('install', e =>
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(FILES.map(file => new Request(new URL(file, self.registration.scope), { cache: 'reload' }))))
      .then(() => self.skipWaiting())
  )
);

self.addEventListener('activate', e =>
  e.waitUntil((async () => {
    // Only remove outdated shell caches (`tcl-v43-preview-shell-*`);
    // NEVER delete `tcl-v43-preview-model-*` caches or IndexedDB user data!
    for (const name of await caches.keys()) {
      if (name.startsWith('tcl-v43-preview-shell-') && name !== CACHE) {
        await caches.delete(name);
      }
    }
    await self.clients.claim();
  })())
);

self.addEventListener('message', e => {
  if (e.data === 'ACTIVATE_UPDATE') self.skipWaiting();
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  const scope = new URL(self.registration.scope);
  // Never intercept /api/ai/* or model streaming downloads (/models/) in shell cache!
  if (url.pathname.startsWith('/api/') || url.pathname.includes('/models/')) return;
  if (e.request.method !== 'GET' || url.origin !== scope.origin || !url.pathname.startsWith(scope.pathname)) return;
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(e.request, { ignoreSearch: true });
    if (cached) return cached;
    try {
      return await fetch(e.request);
    } catch {
      return new Response('当前无法联网：R6 浏览器语音识别需要联网且不保证离线可用；历史记录与原有录像保留。', {
        status: 503,
        headers: { 'Content-Type': 'text/plain;charset=utf-8' }
      });
    }
  })());
});
